% Influence of sigma_r and sigma_u on the source separation score
% Code by Paul Magron, September 2015

clear all; clc; close all;
Fs = 11025; Nfft = 512; Nw = 512; hop = Nw/4; TF_type = 'STFT';
Ncnmf = 10; Nnmf = 30; 
Npieces = 30;

% Phase Parameters vectors
Sigma_r = 10.^(-4:-3); Nr = length(Sigma_r);
Sigma_u = 10.^(-4:-3); Nu = length(Sigma_u);
cnmf_wiener = 0;

% Dataset
sces = {'SYNTH_OL','PIANO_RAND'}; Nsc = length(sces);
res_files = strcat('phase constrained CNMF/influence_sigma/results_r_u_',sces,'.mat');

% Loop over the datasets
for sc = 1:Nsc
    source_type = sces{sc};
    
    % Run the simulation
    run_simul_CNMFph;
    
    % Save scores
    res.SDR_av = SDR_av; res.SIR_av = SIR_av; res.SAR_av = SDR_av;
    res.Sigma_r = Sigma_r; res.Sigma_u = Sigma_u;
    save(res_files{sc},'res');
end

% Visualize scores
aux_synth = load(res_files{1}); aux_piano = load(res_files{2});
res_synth = aux_synth.res; res_piano = aux_piano.res;
image_sigma_r_u(res_synth,res_piano);