% Procedure that perform source separation with phase-constrained CNMF, CNMF and Wiener filtering over mixtures
% and compute the score (BSS eval)

% Scores initialization
SDR = zeros(Nr,Nu,Npieces); SIR = zeros(Nr,Nu,Npieces); SAR = zeros(Nr,Nu,Npieces);
if (cnmf_wiener)
    SDR_cnmf = zeros(1,Npieces); SIR_cnmf = zeros(1,Npieces); SAR_cnmf = zeros(1,Npieces);
    SDR_wiener = zeros(1,Npieces); SIR_wiener = zeros(1,Npieces); SAR_wiener = zeros(1,Npieces);
end  

    
% Loop over mixtures
for it=1:Npieces
    
    % Source generation and onset frames
    gen_sources_time; gen_sources_TF;
    UN = zeros(K,T);
    switch source_type
        case 'SYNTH_OL'
            UN(1,[16 220]) = 1; UN(2,[118 220])=1;
        case 'PIANO_RAND'
             UN(1,[5 177]) = 1; UN(2,[91 177])=1;
        case 'PIANO_E-B'
             UN(1,[5 177]) = 1; UN(2,[91 177])=1;
        case 'PIANO_C-G'
             UN(1,[5 177]) = 1; UN(2,[91 177])=1;
        case 'PIANO_H_THREE'
             UN(1,[5 177]) = 1; UN(2,[91 177])=1; UN(3,[5 91])=1;
    end

    % Sparsity parameters
    p = 1;
    sigma_s = (norm(X)^2)/(K^(1-p/2))*10^(-5);

    % Loop over sigma parameters
    for index_r = 1:Nr
        sigma_r = Sigma_r(index_r); 
        for index_u = 1:Nu
            sigma_u = Sigma_u(index_u);
            
            clc;
            fprintf(strcat(source_type,' - Source %.1d / %.1d'),it,Npieces);  
            fprintf(' \n sigma r - %.1d / %.1d',index_r,Nr);
            fprintf(' \n sigma u - %.1d / %.1d \n',index_u,Nu);
            
            % Complex NMF with phase constraint
            Wini = rand(F,K); Hini = rand(K,T);
            [Xhat,~,~,~,~,err]=cnmf_ph_constrained(X,Wini,Hini,Ncnmf,Nnmf,p,sigma_s,sigma_u,sigma_r,UN,Nfft,hop);
            
            % Time-domain signal synthesis
            se = zeros(size(sm));
            for k=1:K
                se(k,:) = iSTFT(Xhat(:,:,k),Nfft,w,hop);
            end
            
            % Bss Eval
            [sdraux,siraux,saraux] = bss_eval_sources(sm,se);
            SDR(index_r,index_u,it) = mean(sdraux);
            SIR(index_r,index_u,it) = mean(siraux);
            SAR(index_r,index_u,it) = mean(saraux);
        end
    end
    
    if (cnmf_wiener)
    clc;
    fprintf(strcat(source_type,' - Source %.1d / %.1d'),it,Npieces);  
    fprintf('\n NMF + Wiener and CNMF without constraint \n');
    
    % Wiener and complex nMF without constrain
    [W_wien,H_wien] = KL_nmf(abs(X),Wini,Hini,Nnmf);
    Xhat_wiener = wiener(X,W_wien,H_wien);
    [Xhat_cnmf,~,~,~,~,~]=cnmf_ph_constrained(X,Wini,Hini,Ncnmf,0,p,sigma_s,0,0,UN,Nfft,hop);
    
    % Time-domain signal synthesis
    se_cnmf = zeros(size(sm)); se_wiener = zeros(size(sm));
    for k=1:K
    	se_cnmf(k,:) = iSTFT(Xhat_cnmf(:,:,k),Nfft,w,hop);
        se_wiener(k,:) = iSTFT(Xhat_wiener(:,:,k),Nfft,w,hop);
    end
    
    % Bss Eval
    [sdraux,siraux,saraux] = bss_eval_sources(sm,se_cnmf);
    SDR_cnmf(it) = mean(sdraux); SIR_cnmf(it) = mean(siraux); SAR_cnmf(it) = mean(saraux);
    [sdraux,siraux,saraux] = bss_eval_sources(sm,se_wiener);
    SDR_wiener(it) = mean(sdraux); SIR_wiener(it) = mean(siraux); SAR_wiener(it) = mean(saraux);
    end
    
%     %Sort
%     [Xhat] = sort_sources(Sm,Xhat);
%     [Xhat_cnmf] = sort_sources(Sm,Xhat_cnmf);
%     [Xhat_wiener] = sort_sources(Sm,Xhat_wiener);
end

% Record sounds
if rec
    for k=1:K
        audiowrite(strcat('phase constrained CNMF/sounds/',source_type,'_orig',int2str(k),'.wav'),0.999*scaling(sm(k,:)),Fs);
        audiowrite(strcat('phase constrained CNMF/sounds/',source_type,'_Wiener',int2str(k),'.wav'),0.999*scaling(se_wiener(k,:)),Fs);
        audiowrite(strcat('phase constrained CNMF/sounds/',source_type,'_CNMF',int2str(k),'.wav'),0.999*scaling(se_cnmf(k,:)),Fs);
        audiowrite(strcat('phase constrained CNMF/sounds/',source_type,'_CNMFph',int2str(k),'.wav'),0.999*scaling(se(k,:)),Fs);
    end
end


% Average scores
SDR_av = mean(SDR,3); SIR_av = mean(SIR,3); SAR_av = mean(SAR,3);
if (cnmf_wiener)
    SDR_cnmf_av = mean(SDR_cnmf); SIR_cnmf_av = mean(SIR_cnmf); SAR_cnmf_av = mean(SAR_cnmf);
    SDR_wiener_av = mean(SDR_wiener); SIR_wiener_av = mean(SIR_wiener); SAR_wiener_av = mean(SAR_wiener);
end

