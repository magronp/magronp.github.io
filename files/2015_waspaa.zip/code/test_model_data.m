% Testing the repeating phase model estimation on model-built data
% Paul Magron, April 2015

clear all; close all; clc;
Niter = 100;
Ndata = 30;
sigma = [0 0.01 0.1 0.2 0.3 0.5 1 10 100];
Lsig = length(sigma);
costWiener = zeros(Ndata,Lsig,2); 
costStrict = zeros(Ndata,Lsig,2);
costRelax = zeros(Ndata,Lsig,2);

F = 200; T = 3; K = 2;
ff = (0:(F-1))';

for it=1:Ndata
    fprintf('Iteration %d / %d',it,Ndata);
    % Magnitudes
    A= zeros(F,T,K);
    A(:,:,1) = [ff+1 zeros(F,1) ff+1];
    A(:,:,2) = abs([zeros(F,1) sin(ff+1)*3 sin(ff+1)*5]);

    % Fundamental phases and offsets
    chis = exp(1i * [ff*pi/3 ff*pi/2]);
    mus = exp (1i * [ 0 0 randn ; 0 0 randn]);

    % Lambda and Psi matrices
    psis = zeros(F,F,K);
    lambdas = zeros(F,T,K);
    for k=1:K
        psis(:,:,k) = diag(chis(:,k));
        lambdas(:,:,k) = exp(1i * angle(vandermonde(mus(k,:),F)));
    end

    % Sources and mixture
    Sm = zeros(F,T,K);
    for k=1:K
        Sm(:,:,k) = psis(:,:,k)*lambdas(:,:,k) .* A(:,:,k);
    end
    X = sum(Sm,3);

    % Init and estimate phase
    mu0 = exp (1i * randn(K,T));
    chi0 = exp (1i * randn(F,K));
    
    % Phase estimation - relaxed
    for it_sig=1:Lsig
        [Yr,Ymixr,psir,lambdar,chir,mur,errr]=onset_reco_relax(X,A,chi0,mu0,Niter,sigma(it_sig));
        costRelax(it,it_sig,1) = norm(Sm(:,:,1)-Yr(:,:,1));
        costRelax(it,it_sig,2) = norm(Sm(:,:,2)-Yr(:,:,2));
    end
    
    % Phase estimation - strict
    [Ys,Ymixs,psis,lambdas,chis,mus,errs]=onset_reco_strict(X,A,chi0,mu0,Niter);
    costStrict(it,:,1) = norm(Sm(:,:,1)-Ys(:,:,1)) *ones(1,Lsig);
    costStrict(it,:,2) = norm(Sm(:,:,2)-Ys(:,:,2)) *ones(1,Lsig);
    
    % Phase estimation - Wiener
    costWiener(it,:,1) = norm(Sm(:,:,1)- (A(:,:,1)./sum(A,3)).^2 .* X ) *ones(1,Lsig);
    costWiener(it,:,2) = norm(Sm(:,:,2)- (A(:,:,2)./sum(A,3)).^2 .* X ) *ones(1,Lsig);
    
    clc;
end

% Average results over sources and iterations
costS = mean(sum(costStrict,3),1);
costR = mean(sum(costRelax,3),1);
costW = mean(sum(costWiener,3),1);

% Comparison with mixture phase
figure;
plot(1:Lsig,20*log10(costW),'b--',1:Lsig,20*log10(costS),'g-',1:Lsig,20*log10(costR),'r+');
p=xlabel('\sigma'); set(p,'FontSize',16);
set(gca,'XTickLabel',sigma);
p=ylabel('Error (dB)'); set(p,'FontSize',16);
p=legend('Wiener filtering','Strict constraint','Relaxed constraint'); set(p,'FontSize',16);
