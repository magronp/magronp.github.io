function X = vandermonde(v,N)

M = length(v);
X = ones(N,M);

for n=2:N
    X(n,:) = v .^ (n-1);
end

end