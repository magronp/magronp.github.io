function n = normTsquare(X)

S = size(X,3);
n = 0;

for  s=1:S
    n = n + norm(X(:,:,s))^2;
end

end