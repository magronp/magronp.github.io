function bool = ismultiple(v)

bool = false;
vtest = v(1);
vaux = v(2:end);

while ((~bool)&&(~isempty(vaux)))
   btest = sum(ismember(vaux,vtest));
   bool = ~(btest==0);
   vtest = vaux(1);
   vaux = vaux(2:end);
end

end