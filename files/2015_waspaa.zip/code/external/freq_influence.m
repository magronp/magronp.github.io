function [f_inf] = freq_influence(v)

% Central peaks
[~,f_centr] = findpeaks(v);
Nfreq = length(f_centr);

if (Nfreq >0)
    % Quadratic interpolation of frequencies
    f_harm = zeros(1,Nfreq);
    for ind = 1:Nfreq
        f = f_centr(ind);
        f_harm(ind) = qint(20*log10(v(f-1)),20*log10(v(f)),20*log10(v(f+1)))+f;
    end

    % Frequencies in Regions of influence
    f_inf = zeros(length(v),1);
    deb = 1;

    for ind = 1:(Nfreq-1)
        f = f_centr(ind);
        fp = f_centr(ind+1);
        fin = floor((v(fp)*f+v(f)*fp)/(v(fp)+v(f)));
        f_inf(deb:fin) = f_harm(ind);
        deb = fin+1;
    end

    f_inf(deb:end) = f_harm(end);
    
else
    f_inf = (1:length(v))'-1;
end

end