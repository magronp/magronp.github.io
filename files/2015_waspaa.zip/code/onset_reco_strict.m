% Onset Phase estimation - strict
% Paul Magron, April 2015
%
% Inputs:
%     X : F*T complex matrix
%     A : F*T*K magnitude matrix
%     chi = exp(i*psi) : F*K fundamental phases matrix
%     mu = exp(i*lambda) : K*T onset delays matrix
%     Niter : number of iterations
% Outputs:
%     Y : F*T estimated mix
%     Ymix : F*T*K estimated complex components
%     psi, lambda, chi, mu : matrices with phase parameters
%     err : cost function

function [Y,Ymix,psi,lambda,chi,mu,err]=onset_reco_strict(X,A,chi,mu,Niter)

[F,T,K] = size(A);

% Initialize parameters, components and mixture
Y = zeros(F,T,K);
lambda = zeros(F,T,K);
psi = zeros(F,F,K);
for k=1:K
     lambda(:,:,k) = exp(1i * angle(vandermonde(mu(k,:),F)));
     psi(:,:,k) = diag(chi(:,k));
     Y(:,:,k) = psi(:,:,k)*lambda(:,:,k) .* A(:,:,k);
end
Ymix = sum(Y,3);
B = (repmat(X - Ymix,[1,1,K]) + Y);

% Error
err = zeros(1,Niter+1);
err(1) = norm(X-Ymix)^2;

% Estimation
for it = 1:Niter
    
    % Update mu
    for k=1:K
        for t=1:T
            beta = B(:,t,k) .* conj(chi(:,k));
            mu(k,t) =  beta(1:end-1)' * beta(2:end) ;
            mu(k,t) = (mu(k,t)+eps) ./ (abs(mu(k,t))+eps) ;
        end
    end
    
    % Complex components and mixture
    for k=1:K
        lambda(:,:,k) = exp(1i * angle(vandermonde(mu(k,:),F)));
        Y(:,:,k) = psi(:,:,k)*lambda(:,:,k) .* A(:,:,k);
    end
    Ymix = sum(Y,3);
    B = (repmat(X - Ymix,[1,1,K]) + Y);
    
    % Update chi and then psi (fundamental phases)
    chi = squeeze(sum(B .* A .* conj(lambda),2));
    chi = (chi+eps) ./ abs(chi+eps);

    % Update complex components and mixture
    for k=1:K
        psi(:,:,k) = diag(chi(:,k));
        Y(:,:,k) = psi(:,:,k)*lambda(:,:,k) .* A(:,:,k);
    end
    Ymix = sum(Y,3);
    B = (repmat(X - Ymix,[1,1,K]) + Y);
    
    err(it+1) = norm(X-Ymix)^2;

end

end