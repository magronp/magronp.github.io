% Onset Phase estimation - relaxed
% Paul Magron, April 2015
%
% Inputs:
%     X : F*T complex matrix
%     A : F*T*K magnitude matrix
%     chi = exp(i*psi) : F*K fundamental phases matrix
%     mu = exp(i*lambda) : K*T onset delays matrix
%     sigma : relaxation parameter (positive)
%     Niter : number of iterations
% Outputs:
%     Y : F*T estimated mix
%     Ymix : F*T*K estimated complex components
%     psi, lambda, chi, mu : matrices with phase parameters
%     err : cost function

function [Y,Ymix,psi,lambda,chi,mu,err]=onset_reco_relax(X,A,chi,mu,Niter,sigma)

[F,T,K] = size(A);

% Initialize parameters, components and mixture
Y = zeros(F,T,K);
Yapprox = zeros(F,T,K);
phi = zeros(F,T,K);
lambda = zeros(F,T,K);
psi = zeros(F,F,K);
for k=1:K
    lambda(:,:,k) = exp(1i * angle(vandermonde(mu(k,:),F)));
    psi(:,:,k) = diag(chi(:,k));
    Y(:,:,k) = exp(1i * phi(:,:,k)) .* A(:,:,k) ;
    Yapprox(:,:,k) = psi(:,:,k)*lambda(:,:,k) .* A(:,:,k);
end
Ymix = sum(Y,3);
B = (repmat(X - Ymix,[1,1,K]) + Y);

% Error
err = zeros(1,Niter+1);
err(1) = norm(X-Ymix)^2 + sigma * normTsquare(Yapprox - Y) ;

% Estimation
for it = 1:Niter
    
    % Update phi
    for k=1:K
        for f=1:F
            for t=1:T
                C = A(f,t,k) .* ( B(f,t,k) + sigma * Yapprox(f,t,k)  ) ;
                phi(f,t,k) = angle(C);
            end
        end
    end
    
    % Update mu
    for k=1:K
        for t=1:T
            beta = A(:,t,k) .* exp(1i * phi(:,t,k)) .* conj(chi(:,k)) ;
            mu(k,t) = (beta(1:end-1)' * beta(2:end)) ;
            mu(k,t) = (mu(k,t)+eps) ./ (abs(mu(k,t))+eps) ;
        end
    end
   
    % Update Y
    for k=1:K
        lambda(:,:,k) = exp(1i * angle(vandermonde(mu(k,:),F)));
        Y(:,:,k) = exp(1i * phi(:,:,k)) .* A(:,:,k) ;
    end
    Ymix = sum(Y,3);
    B = (repmat(X - Ymix,[1,1,K]) + Y);
    
    % Update chi 
    for k=1:K
        for f=1:F
            aux = sum( A(f,:,k) .* Y(f,:,k) .* conj(lambda(f,:,k)) );
            chi(f,k) = (aux+eps) ./ (abs(aux)+eps) ;
        end
    end
    
    % Update psi and Yapprox
    for k=1:K
        psi(:,:,k) = diag(chi(:,k));
        Yapprox(:,:,k) = psi(:,:,k)*lambda(:,:,k) .* A(:,:,k);
    end
    
    err(it+1) = norm(X-Ymix)^2 + sigma * normTsquare(Yapprox - Y) ;
end

end