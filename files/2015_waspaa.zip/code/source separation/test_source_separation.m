% Testing the phase invariant based source separation
% Paul Magron, April 2015

clc; clear all; close all;
Niter = 100;
Ndata = 1;
alpha = 0.01;

% Data
Fs = 11025; Nw = 512; Nfft = 512; hop = Nw/4;
source_type = 'PIANO_H'; TF_type = 'STFT'; num_piece = 1;
%t0 = [17 119 220]; T0 = length(t0); % synth attack frames
t0 = [6 92 178]; T0 = length(t0); % piano-2 attack frames
%t0 = [1 15 37 63 88 111]; T0 = length(t0); % midi attack frames
direc = 'phase repetitions/source separation/sounds/';
algos = {'Wiener','RePU'}; Nal = length(algos);

for it=1:Ndata
    fprintf('Iteration %d / %d',it,Ndata);
    
    % Gen sources
    gen_sources_time; gen_sources_TF; delta = ones(F,T);
    xest = zeros(Nal,K,length(x));
    Xe = abs(Sm);
    phi = zeros(F,T,K);
    Xw = zeros(F,T,K);

    % Select attack frames
    X0 = X(:,t0);
    Sm0 = Sm(:,t0,:);
    A = abs(Sm0);

    % Phase estimation : attacks
    chi0 = exp (1i * randn(F,K));
    mu0 = exp(1i * rand(K,T0));
    Y = onset_reco_relax(X0,A,chi0,mu0,Niter,alpha);
    Xe(:,t0,:) = Y;
    
    % Phase estimation : horizontal
    for k=1:K
        % Wiener
        Xw(:,:,k) = abs(Sm(:,:,k)) .* exp(1i*angle(X));
        xest(1,k,:) = iSTFT(Xw(:,:,k),Nfft,w,hop);
        
        % Unwrapping
        phi(:,:,k) = phase_unwrapping(Xe(:,:,k),Fs,w,hop,delta,0,t0);
        Xe(:,:,k) = abs(Sm(:,:,k)) .* exp(1i*phi(:,:,k));
        xest(2,k,:) = iSTFT(Xe(:,:,k),Nfft,w,hop);
    end
    
    wo = score_separation_PEASS(sm,xest,direc,source_type,algos,Fs);
    score(it) = wo;
    clc;

end

% Average PEASS scores
SDR = zeros(Ndata,Nal); SIR = zeros(Ndata,Nal); SAR = zeros(Ndata,Nal);
for it=1:Ndata
   SDR(it,:) = score(it).SDR;
   SIR(it,:) = score(it).SIR;
   SAR(it,:) = score(it).SAR;
end
