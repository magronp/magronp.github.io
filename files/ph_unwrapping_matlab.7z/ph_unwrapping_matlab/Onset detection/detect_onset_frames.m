% Onset frames detection from a spectrogram
%
% Inputs :
%     V : spectrogram (F*T matrix)
%     Fs : sample rate
%     w : analysis window
%     hop : hop size
%
% Output :
%     tonset : vector of onset frames

function [tonset] = detect_onset_frames(V,Fs,w,hop)

F = size(V,1);
Nfft = 2*(F-1);

parameter.win_len = Nfft;
parameter.fs = Fs;
parameter.stepsize = hop;
parameter.StftWindow = w;

[v0,~] = audio_to_noveltyCurve(V, parameter);
[~,ind] = findpeaks(v0,'MINPEAKHEIGHT',max(v0)*0.1);
t0 = ind'; t0 = t0(1:end);
tonset = t0;

end