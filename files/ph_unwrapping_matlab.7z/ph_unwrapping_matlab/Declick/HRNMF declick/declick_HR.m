% Restauration of a dammaged signal part with HRNMF model
% Code by Paul Magron, Jan. 2015
%
% Inputs :
%     X : corrupted STFT (F*T matrix)
%     K : number of sources
%     delta : F*T mask
%     nHR : number of iterations
%
% Output :
%     XHR : restaured STFT

function XHR  = declick_HR(X,K,delta,nHR)

mask = abs(delta-1);

[F,T] = size(X);
M=1;
maskHR = zeros(F,T,M);
for m=1:M
    maskHR(:,:,m) = mask;
end

% HR parameters
Qa = 1; Qb = 0;
Qz = max(Qa,Qb);
Pa = 0; Pb = 0;
mz = zeros(F,Qz,K);
qz = 1e5*ones(F,Qz,K);
a = .1*randn(F,2*Pa+1,Qa,K);
b = ones(F,2*Pb+1,Qb+1,M,K);
%b(:,1,1,1,:) = wNMF;
%sigma2x = hNMF';
sigma2x = ones(T,K);
sigma2w = 1;

% VBEM HRNMF
[c,~,~,~,~,~,~,~] = VBEM(X+eps,maskHR,mz,qz,a,b,sigma2x,sigma2w,nHR,nHR,true,false);

cHR = zeros(F,T,K);
for k=1:K
    cHR(:,:,k) = squeeze(c(:,:,1,k));
end

% Synthesis
XHR = sum(cHR,3);

end