function [e,sqrtS,c,L] = Estep4f(x,delta,sigma2,a,P,w,h)
% E-step of the EM algorithm for estimating the HR-NMF model

% Recovering dimensions
T = length(x);
K = size(h,1);
Lg = sum(P);
Lc = sum(P>0);

% Initialization of Kalman filtering
L = 0;
gamma = zeros(Lg,1);
sqrtR = 1e-3*eye(Lg);
Phi = zeros(Lg,Lc,T);
sqrtPsi = zeros(Lc,Lc,T);
phi = zeros(Lc,T);
A = zeros(Lg);
P = P(:)';
for k = find(P),
    A(1+sum(P(1:k-1)),1+sum(P(1:k-1)):sum(P(1:k))) = a(1:P(k),k).';
    A(2+sum(P(1:k-1)):sum(P(1:k)),1+sum(P(1:k-1)):sum(P(1:k))-1) = eye(P(k)-1);
end;
J1 = zeros(Lg,Lc);
l = 0;
for k = find(P),
    l = l + 1;
    J1(sum(P(1:k)),l) = 1;
end;
J2 = zeros(Lg,Lc);
l = 0;
for k = find(P),
    l = l + 1;
    J2(1+sum(P(1:k-1)),l) = 1;
end;
Abar = [A;J1'];
u = J2 * ones(Lc,1);
J2 = [J2;zeros(Lc)];
sigma2t = zeros(1,T);
for t = 1:T,
    v = w .* h(:,t);
    sigma2t(t) = max(0,real(sigma2 + sum(v(P==0))));
end;

% Forward pass
for t = 1:T,
    % Predict phase    
    sqrtv = sqrt(w) .* sqrt(h(:,t));
    sqrtv = diag(sqrtv(P>0));
    sqrtRbar = LT([Abar*sqrtR, J2*sqrtv]);
    tmp_Phi = pinv(sqrtRbar(1:Lg,:)')*sqrtRbar(Lg+1:end,:)';  
    Phi(:,:,t) = tmp_Phi;
    sqrtPsi(:,:,t) = LT([-tmp_Phi;eye(Lc)]'*sqrtRbar);
    sqrtR = LT(sqrtRbar(1:Lg,:));
    d = J1' * gamma;
    gamma = A * gamma;
    phi(:,t) = d - tmp_Phi' * gamma;
    % Update phase
    mu = sqrtR'*u;
    epsilon = sigma2t(t) + norm(mu)^2;
    lambda = delta(t)/ epsilon * (sqrtR*mu);
    sqrtR = sqrtR - lambda * (mu'/(1+sqrt(sigma2t(t)/epsilon)));
    eps = x(t) - u' * gamma;
    gamma = gamma + lambda * eps;
    L = L - delta(t) * (log(epsilon) + abs(eps)^2 / epsilon);
end;

% Initialization of Kalman smoothing
e = 0;
sqrtS = zeros(size(a,1)+1,size(a,1)+1,K,T);
c = zeros(K,T);
for k = find(P),
    c(k,T:-1:T-P(k)+1) = gamma(1+sum(P(1:k-1)):sum(P(1:k))).';
end;

% Backward pass
for t = T:-1:1,
    % Wiener filtering phase
    v = w .* h(:,t);
    v = v(P==0);
    eps = x(t) - u'*gamma;
    c(P==0,t) = delta(t)/ sigma2t(t) * v * eps;
    mu = sqrtR'*u;
    ep = delta(t) * (abs(eps)^2 + norm(mu)^2);
    e = e + delta(t)*sigma2/sigma2t(t) * (max(0,sigma2t(t)-sigma2) + sigma2/sigma2t(t)*ep);
    l = 0;
    for k = find(P==0),
        l = l + 1;     
        sqrtS(1,1,k,t) =  sqrt(v(l)/sigma2t(t)) * sqrt(max(0,sigma2t(t)-delta(t)*v(l)) + v(l)/sigma2t(t)*ep);
    end;
    % Smoothing phase
    full_sqrtR = zeros(Lg+Lc);
    new_sqrtR = zeros(Lg);
    l1 = 0;
    for k1 = find(P),
        l1 = l1 +1;
        l2 = 0;
        for k2 = find(P),
            l2 = l2+1;
            index1 = sum(P(1:k1-1)) + (1:P(k1));
            index2 = sum(P(1:k2-1)) + (1:P(k2));
            full_index1 = k1 + sum(P(1:k1-1)) + (0:P(k1));                           
            full_index2 = k2 + sum(P(1:k2-1)) + (0:P(k2));
            tmp_sqrtR = [sqrtR(index1,index2),zeros(P(k1),1);Phi(:,l1,t)'*sqrtR(:,index2),sqrtPsi(l1,l2,t)];
            full_sqrtR(full_index1,full_index2) = tmp_sqrtR;
            new_sqrtR(index1,full_index2) = tmp_sqrtR(2:end,1:end);
        end;
    end;
    sqrtR = LT(new_sqrtR);
    d = phi(:,t) + Phi(:,:,t)' * gamma;
    l = 0;
    for k = find(P),
        l = l + 1;
        if t-P(k) > 0,
            c(k,t-P(k)) = d(l);
        end;
    end;
    full_gamma = zeros(Lg+Lc,1);
    new_gamma = zeros(Lg,1);
    l = 0;
    for k = find(P),
        l = l +1;
        index = sum(P(1:k-1)) + (1:P(k));
        full_index = l + sum(P(1:k-1)) + (0:P(k));
        tmp_gamma = [gamma(index);d(l)];
        full_gamma(full_index) = tmp_gamma;
        new_gamma(index) = tmp_gamma(2:end);
        sqrtS(1:P(k)+1,1:P(k)+1,k,t) = LT(conj([full_sqrtR(full_index,:),tmp_gamma]));
    end;
    gamma = new_gamma;
end;