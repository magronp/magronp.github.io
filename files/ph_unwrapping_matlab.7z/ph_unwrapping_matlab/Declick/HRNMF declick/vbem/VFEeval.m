function VFE = VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)
% Computation of the variational free energy

F = size(ex,1);
T = size(ex,2);
S = size(ex,3);
Qz = size(z,2)-T;
gz2 = gz(:,1:Qz,:);
ez = z(:,1:Qz,:)-mz;
ratio = zeros(F,T,S);
for s = 0:S-1,
    ratio(:,:,1+s) = (gex(:,:,1+s)+abs(ex(:,:,1+s)).^2) .* (ones(F,1)*(1./sigma2x(:,1+s).'));
end;

VFE = D*log(2*pi)-S*F*(T+Qz) ...
    + D*log(sigma2y) + sum(gey(:) + abs(ey(:)).^2)/sigma2y ...
	- sum(log(qz(:))) + sum(qz(:).*(gz2(:)+abs(ez(:)).^2)) ...
	+ F*sum(log(sigma2x(:))) - sum(log(gz(:))) + sum(ratio(:));
VFE = - VFE / 2;