function L = LT(M)
% Lower triangularization of a square matrix

[~,S,V] = svd(M',0);
L = V*S;