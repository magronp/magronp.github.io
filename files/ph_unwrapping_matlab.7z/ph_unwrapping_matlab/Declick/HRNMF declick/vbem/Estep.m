function [e,sqrtS,c,L] = Estep(x,delta,sigma2,a,P,w,h)
% E-step of the EM algorithm for estimating the HR-NMF model

% Initialization
T = size(x,1);
F = size(x,2);
K = size(h,1);

% Memory allocation
e = zeros(1,F);
c = zeros(K,T,F);
sqrtS = zeros(size(a,1)+1,size(a,1)+1,K,T,F);
L = zeros(1,F);

% Parallel loop for f
for f = 1:F,
    [e(f),sqrtS(:,:,:,:,f),c(:,:,f),L(f)] = Estep4f(x(:,f),delta(:,f),sigma2,a(:,:,f),P(:,f),w(:,f),h);
end; % for f

e = sum(e) / sum(sum(delta));
L = sum(L);