% Estimation of the parameters of an AR model
% Code by Paul Magron, May 2014
%
% Inputs :
%     x : signal
%     P : order of the model
% 
% Outputs :
%     a = [1 a1 a2 ... aP] : AR parameters
%     sigma2 : power of the excitation white noise

function [a,sigma2]=eval_AR(x,P)

L = length(x);

% x expected as a column - center
x=x(:)-mean(x);

% Low variance estimator (with bias)
cov = zeros(1,P+2);
for k=1:P+2
    cov(k) = x(k:L)'*x(1:L-k+1) / L;
end

% Auto correlation matrix
Rcov = toeplitz(cov(1:end-1));
vaux = Rcov\eye(P+1,1);
a = vaux/vaux(1);
sigma2 = 1/vaux(1);
end
