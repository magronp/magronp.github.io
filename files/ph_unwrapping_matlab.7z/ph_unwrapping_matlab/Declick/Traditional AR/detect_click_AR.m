function [ind] = detect_click_AR(x,P,a,sigma2,lambda)
% D�tection des craquements par blanchiment puis filtrage adapt�

x_blanc=filter(a,1,x);  %blanchiment
a_adapt=fliplr(a')';
x_adapt=filter(a_adapt,1,x_blanc); %filtrage adapt�

%figure; plot(x); figure; plot(x_blanc); figure; plot(x_adapt);

nu=lambda*sqrt(sigma2)*norm(a);  %Determination du seuil
[~,ind]=findpeaks(abs(x_adapt((P+1):end)),'THRESHOLD',nu);

end