% Restauration of a dammaged signal part with AR model (inpainting) and
% least square method. [Fillon, Charbit]
% Code by Paul Magron, May 2014
%
% Inputs :
%     x : signal
%     Nw : analysis window length
%     Q : hop factor
%     pAR : AR filter length
%     m : restoration section length
%     lambda : click detection treshold
%
% Output :
%     xAR : restaured signal


function xAR = declick_AR(x,Nw,Q,pAR,m,lambda)

long=length(x);
nt=floor((long-Nw)/(Nw*(1-Q)));
xAR = x;

% Loop over frames
for k=1:(nt-1)  
    deb = round((k-1)*Nw*(1-Q))+1;
    fin = deb+Nw-1;
    xt = xAR(deb:fin);
    
    % AR model parameters estimation
    [a,sigma2] = eval_AR(xt,pAR);
    
    % Click detection
    ind=detect_click_AR(xt,pAR,a,sigma2,lambda);
    l=ind-(m-1)/2;
    
    % Remove the index to small / big
    % (restauration needs P samples before and after restauration zone
    yep=find( (l<=pAR) | (l+m+pAR-1>Nw) );
    l(yep)=[];
    
    % Restauration
    xr=xt;
    if isempty(l)
           % If no peak (= no click), do nothing
    else
        % Loop on each click to be restaured
        for j=1:length(l)
            xr=restore(xr,a,m,l(j));
        end
    end
    xAR(deb:fin)=xr;
end

end