% Restoration of spectrograms magnitude by linear interpolation of
% log-magnitude
% Paul Magron, Feb. 2015

function Vr = restore_mag(tc,V)

F = size(V,1);
Vr=V;

ttt = (0:length(tc)-1) + tc(1);
t_aux = tc - ttt;
Tc = tc;

% Process successive frames
while (~isempty(t_aux))

    % Take the successive frames
    indt = (t_aux==t_aux(1));
    tc_aux = Tc(indt);
    
    tA = tc_aux(1)-1;
    tB = tc_aux(end)+1;
    % Restoration of each H row
    for f=1:F
        yA = log(V(f,tA));
        yB = log(V(f,tB));
        
        if (~isinf(yA))
            a = (yB - yA) / (tB-tA);
            yr = a * (tc_aux - tA) + yA;
            Vr(f,tc_aux) = exp(yr);
        end
    end
    
    t_aux = t_aux(~indt);
    Tc = Tc(~indt);
    
end

end