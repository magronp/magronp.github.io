clc; clear all; close all;

% Parameters
Fs = 11025; Nfft = 512; Nw = 512; hop = 512/4;
rec = 0;
nPHI = 200; 

source_type = 'PIANO_ONE_RAND'; Ndata = 30;

Nmeth = 6; SDR = zeros(Nmeth+1,Ndata);

for num_source = 1:Ndata
    clc;
    fprintf('Source : %d / %d \n',num_source,Ndata);
    
    gen_sources_time; gen_sources_TF;
    delta = ones(F,T);
    tonset = detect_onset_frames(abs(X),Fs,w,hop); tonset = tonset(1)+1;
    xx = zeros(Nmeth,length(x));
    
    % Phase reconstruction
    for meth=0:(Nmeth-1)
        fprintf('Phase unwrapping method : %d / %d \n',meth,Nmeth);
        phi = phase_unwrapping(X,Fs,w,hop,delta,meth,tonset);
        Xe = abs(X).* exp(1i*phi); xe = iSTFT(Xe,Nfft,w,hop);
        xx(meth+1,:) = xe;
        SDR(meth+1,num_source) = bss_eval_sources(x',xe');

        %Record
        if rec
            audiowrite(strcat('phase unwrapping/sounds/pitched/',source_type,'_',int2str(meth),'_reco.wav'),0.999*scaling(xe),Fs);
        end

    end

    % Griffin Lim
    fprintf('Griffin Lim \n');
    phi0 = rand(F,T);
    X0 = abs(X) .* exp(1i * phi0);
    xGL = griffin_lim(X0,w,hop,nPHI);
    SDR(end,num_source) = bss_eval_sources(x',xGL);

end

%Record    
if rec
    audiowrite(strcat('phase unwrapping/sounds/pitched/',source_type,'_orig.wav'),0.999*scaling(x),Fs);
    audiowrite(strcat('phase unwrapping/sounds/pitched/',source_type,'_GL.wav'),0.999*scaling(xGL),Fs);
end
