function [xc,Xc,delta,tc] = corrupt_click(x,perc,Fs,Nfft,w,hop,tclick)

if nargin<7
    tclick = 0.001;
end
Lclick = floor(tclick*Fs);

Nw = length(w);

dcorr = zeros(1,length(x));
while (sum(dcorr)==0)
corr = floor(rand(length(x)+1,1) + perc/(100*Lclick));
corr = conv(corr,hann(Lclick),'same');
dcorr = diff(corr);
dcorr([1:Nw+1 end-(Nw):end]) = 0;
end

xc = x+dcorr./max(dcorr)*(1.1*max(x));

Xc = STFT(xc,Nfft,w,hop);
CC = STFT(dcorr,Nfft,w,hop);

T = size(Xc,2);
delta = (abs(CC) > 0);
tt = 1:T; tc = tt(sum(delta,1)>0);

end