clc; clear all; close all;

% Parameters
Fs = 11025;
Nw = 512; Nfft = 512; hop = Nw/4;
TF_type = 'STFT';
source_type = 'PIANO_H';
nPHI = 100;
nNMF = 100;

% Source generation
gen_sources_time; gen_sources_TF;

% Score initialization
Np = 9;
SDR_co = zeros(1,Np); SDR_PR = zeros(1,Np); SDR_GL = zeros(1,Np);

for p = 1:Np
    fprintf('iteration %d / %d \n',p,Np);
    % Corrupt STFT
    perc = p*10;
    delta = floor(rand(F,T) + perc/100);
    %delta = zeros(F,T); delta(1:end,[65:105 120:160])=1;
    Xc = X; r =zeros(F,T);
    Xc(delta>0) = r(delta>0) ;
    xc = iSTFT(Xc,Nfft,w,hop);
    SDR_co(p) = bss_eval_sources(x',xc');
    
    % Magnitude recovery
    mask = abs(delta-1);
    [wNMF,hNMF] = KL_nmf(abs(Xc),rand(F,K),rand(K,T),nNMF,mask);
    V = wNMF*hNMF;
    Xini = V;
    Xini(mask==1) = V(mask==1) .* exp(1i * angle(Xc(mask==1)));
    
    % Plot spectrograms
    if (p==4)
        Xplot = X; Xplot(20*log10(abs(X))<-120) = 10^(-6);
        Xcplot = Xc; Xcplot(20*log10(abs(Xc))<-120) = 10^(-6);
        Vplot = V; Vplot(20*log10(abs(V))<-120) = 10^(-6);
        Fig1 = figure(1);
        subplot(1,3,1); imagesc(ts,freq,20*log10(abs(Xplot))); axis xy; h=xlabel('Time (s)'); set(h,'FontSize',16); h=ylabel('Frequency (Hz)'); set(h,'FontSize',16); h = title('Original'); set(h,'FontSize',16);
        subplot(1,3,2); imagesc(ts,freq,20*log10(abs(Xcplot))); axis xy; h=xlabel('Time (s)'); set(h,'FontSize',16); h = title('Corrupted'); set(h,'FontSize',16);
        subplot(1,3,3); imagesc(ts,freq,20*log10(abs(Vplot))); axis xy; h=xlabel('Time (s)'); set(h,'FontSize',16); h = title('Restored'); set(h,'FontSize',16);
        set(Fig1,'Position', [477 534 929 343]);
    end
    
    % Phase recovery
    [phi,t0,n0] = phase_unwrapping(Xini,Fs,w,hop,delta,1);
    Xe = V.* exp(1i*phi); xe = iSTFT(Xe,Nfft,w,hop);
    SDR_PR(p) = bss_eval_sources(x',xe');
    
    % Griffin Lim
    [xGL,icons,err] = griffin_lim(Xini,w,hop,P_cons,nPHI);
    SDR_GL(p) = bss_eval_sources(x',xGL);

end

% Plot results
figure(2);
pp = (1:Np)*10;
plot(pp,SDR_PR,'r*-',pp,SDR_GL,'g+-',pp,SDR_co,'bo-')
h=xlabel('Percentage of corrupted bins');   set(h,'FontSize',16); h=ylabel('SDR (dB)');  set(h,'FontSize',16);
h=legend('Phase unwrapping','GriffinLim','Corrupted');  set(h,'FontSize',16);


% % Record
% audiowrite(strcat('../sounds/restoration/',source_type,'_orig.wav'),0.999*scaling(x),Fs);
% audiowrite(strcat('../sounds/restoration/',source_type,'_corr.wav'),0.999*scaling(xc),Fs);
% audiowrite(strcat('../sounds/restoration/',source_type,'_reco.wav'),0.999*scaling(xe),Fs);
% audiowrite(strcat('../sounds/restoration/',source_type,'_GL.wav'),0.999*scaling(xGL),Fs);

