function [f_inf,f_centr] = freq_influence(v)

v = v(:)';
%Central peaks
[~,f_centr] = findpeaks(v,'MINPEAKHEIGHT',0.01*max(v));

Nfreq = length(f_centr);

if (Nfreq >0)
    % Quadratic interpolation of frequencies
    f_harm = zeros(1,Nfreq);
    for ind = 1:Nfreq
        f = f_centr(ind);
        f_harm(ind) = qint(20*log10(v(f-1)),20*log10(v(f)),20*log10(v(f+1)))+f;
    end

    % Frequencies in Regions of influence
    f_inf = zeros(length(v),1);
    deb = 1;
    index_lim = zeros(1,Nfreq-1);
    
    for ind = 1:(Nfreq-1)
        f = f_centr(ind);
        fp = f_centr(ind+1);
        fin = floor((v(fp)*f+v(f)*fp)/(v(fp)+v(f)));
        f_inf(deb:fin) = f_harm(ind);
        deb = fin+1;
        index_lim(ind) = fin;
    end

    f_inf(deb:end) = f_harm(end);
    
else
    f_inf = (1:length(v))'-1;
end

end


function [p,b,a] = qint(ym1,y0,yp1)

p = (yp1 - ym1)/(2*(2*y0 - yp1 - ym1));
b = y0 - 0.25*(ym1-yp1)*p;
a = 0.5*(ym1 - 2*y0 + yp1);

end