clc; clear all; close all;

% Parameters
Fs = 44100; Nw = 4096; Nfft = 4096; hop = Nw/4;
source_type = 'PIANO_RAND';

Np = 3;
meanE = zeros(1,Np);

for it = 1:Np
    fprintf('Iteration %d / %d \n',it,Np);
    
    % Source generation
    num_piece = it;
    gen_sources_time; gen_sources_TF;
    
    % Instantaneous frequencies
    f_inf = zeros(F,T);
    f_centr = zeros(F,T);
    for t=1:T
        [inf,centr] = freq_influence(abs(X(:,t)));
        f_inf(:,t) = inf-1;
        if isempty(centr)
            f_centr(:,t) = 0;
        else
            %c = [(centr-1)' centr' (centr+1)']';
            c = centr;
            f_centr(c(:),t) = 1;
        end
    end
    f_voc_Hz = phvoc_freq(X,hop)* Fs /Nfft;
    f_QI_Hz = f_inf* Fs /Nfft;

    % Freq. estimation error
    E = abs(f_voc_Hz(f_centr==1) - f_QI_Hz(f_centr==1)) ./ f_voc_Hz(f_centr==1);
    meanE(it) = mean(E(:));
end

err = mean(meanE(~isnan(meanE)));
