clc; clear all; close all;

% Parameters
Fs = 11025; Nfft = 512; Nw = 512; hop = Nw/4; TF_type = 'STFT';
nPHI = 200;

source_type = 'PIANO_RAND'; Ndata = 30;

SDR_PU = zeros(1,Ndata); SDR_GL = zeros(1,Ndata);

for it=1:Ndata
    
    fprintf('Iteration %d / %d \n',it,Ndata);

    % Data generation
    num_piece = it; gen_sources_time; gen_sources_TF;

    % Phase reconstruction
    tic;
    [phi,t0] = phase_unwrapping(X,Fs,w,hop);
    Xe = abs(X).* exp(1i*phi); xe = iSTFT(Xe,Nfft,w,hop); tPU = toc;
    SDR_PU(it) = bss_eval_sources(x',xe');
    
    % Griffin Lim
    tic;
    phi0 = zeros(F,T); phi0(:,t0) = angle(X(:,t0));
    X0 = abs(X) .* exp(1i * phi0);
    xGL = griffin_lim(X0,w,hop,nPHI); tGL = toc;
    SDR_GL(it) = bss_eval_sources(x',xGL);
end

sdrPU = mean(SDR_PU);
sdrGL = mean(SDR_GL);