% Instantaneous frequencies estimation with the phase vocoder technique
% Code by Paul Magron, Jan. 2015
%
% Inputs :
%     X : complex STFT matrix (F*T)
%     hop : STFT hop size
% 
% Outputs :
%     f_inf : frequencies in regions of influence

function [f_inf] = phvoc_freq(X,hop)

[F,T] = size(X);
Nfft = 2*(F-1);
Ct = 2*pi*hop/Nfft;
dphi = Ct*(0:(F-1))';
    
X = [zeros(F,1) X];
f_inf = zeros(F,T);

for t=2:(T+1)
    
    v2 = X(:,t); v=abs(v2);
    v1 = X(:,t-1);
    
    phi1 = angle(v1);
    phi2 = angle(v2);

    % Phase advance and principal value
    dp = phi2 - phi1 - dphi;
    dp = dp - 2 * pi * round(dp/(2*pi));

    % Instantaneous frequency
    f_inst = (dphi+dp)/(2*pi*hop)*Nfft;
    
     % Central peaks
    [~,f_centr] = findpeaks(v);
    Nfreq = length(f_centr);

    if (Nfreq >0)
        f_harm = f_inst(f_centr);
        
        % Frequencies in Regions of influence
        deb = 1;
        for ind = 1:(Nfreq-1)
            f = f_centr(ind);
            fp = f_centr(ind+1);
            fin = floor((v(fp)*f+v(f)*fp)/(v(fp)+v(f)));
            f_inf(deb:fin,t-1) = f_harm(ind);
            deb = fin+1;
        end

        f_inf(deb:end,t-1) = f_harm(end);

        else
        f_inf(:,t-1) = (1:length(v))'-1;
    end
end

end