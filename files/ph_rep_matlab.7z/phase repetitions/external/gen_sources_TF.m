% Generation of TF data 

clear sm_aux Sm Sm_double X Xdouble;

switch TF_type
    
    case 'STFT'
        Nfft = Nw;
        w = perfect_reco_window(Nw,hop);
        %w = circshift(w,Nw/2);
        for k=1:K
            Sm(:,:,k) = STFT(sm(k,:),Nfft,w,hop);
            Sm_double(:,:,k) = STFT(sm(k,:),Nfft*2,w,hop);
        end
        
        X = STFT(x,Nfft,w,hop);
        Xdouble = STFT(x,Nfft*2,w,hop);
        
%         X = X(:,1:end-3);
%         Xdouble = Xdouble(:,1:end-3);
%         Sm = Sm(:,1:end-3,:);
%         Sm_double = Sm_double(:,1:end-3,:);

        x = iSTFT(X,Nfft,w,hop);
        parfor k=1:K
            sm_aux(k,:) = iSTFT(Sm(:,:,k),Nfft,w,hop);
        end
        sm = sm_aux;
        
        [F,T] = size(X);
        Qa = 1;         % HRNMF AR filter length
        Qb = 0;
        P_cons = 3;     % consistency length
        
        W_ini = rand(F,K);
        W_ini_double = zeros(2*F-1,K); W_ini_double(1:2:end,:) = W_ini;
        H_ini = rand(K,T);

    case 'MDCT'
        w = sin(((1:Nw)-0.5)*pi/Nw);
        for k=1:K
            Sm(:,:,k) = STmdct(sm(k,:),w,Fs);
        end
        Sm_double = zeros(size(Sm).*[2 1 1]);
        Sm_double(1:2:end,:,:) = Sm(:,:,:);
        
        X = STmdct(x,w,Fs);
        Xdouble = zeros(size(X).*[2 1]);
        Xdouble(1:2:end,:) = X;

%         X = X(:,1:end-1);
%         Xdouble = Xdouble(:,1:end-1);
%         Sm = Sm(:,1:end-1,:);
%         Sm_double = Sm_double(:,1:end-1,:);

        x = iSTmdct(X,w);
        parfor k=1:K
            sm_aux(k,:) = iSTmdct(Sm(:,:,k),w);
        end
        sm = sm_aux;
        
        [F,T] = size(X);
        Qa = 2;         % HRNMF AR filter length
        Qb = 1;
        
        W_ini = rand(F,K);
        W_ini_double = zeros(2*F,K); W_ini_double(1:2:end,:) = W_ini;
        H_ini = rand(K,T);

    case 'MDFT'
        w = sin(((1:Nw)-0.5)*pi/Nw);
        for k=1:K
            Sm(:,:,k) = MDFT(sm(k,:),w,Fs);
        end
        Sm_double = zeros(size(Sm).*[2 1 1]);
        Sm_double(1:2:end,:,:) = Sm(:,:,:);
        
        X = MDFT(x,w,Fs);
        Xdouble = zeros(size(X).*[2 1]);
        Xdouble(1:2:end,:) = X;

%         X = X(:,1:end-1);
%         Xdouble = Xdouble(:,1:end-1);
%         Sm = Sm(:,1:end-1,:);
%         Sm_double = Sm_double(:,1:end-1,:);

        x = iMDFT(X,w);
        parfor k=1:K
            sm_aux(k,:) = iMDFT(Sm(:,:,k),w);
        end
        sm = sm_aux;
        
        [F,T] = size(X);
        Qa = 2;         % HRNMF AR filter length
        Qb = 1;
        
        W_ini = rand(F,K);
        W_ini_double = zeros(2*F,K); W_ini_double(1:2:end,:) = W_ini;
        H_ini = rand(K,T);

        
    case 'CQT'
        
        B = 24;
        fmin = 27.5; fmax = Fs/2;
        
        for k=1:K
             Smcqt(k) = cqt(sm(k,:), B, Fs, fmin, fmax);
             Sm(:,:,k) = Smcqt(k).c;
        end
        
        Sm_double = zeros(size(Sm).*[2 1 1]);
        Sm_double(1:2:end,:,:) = Sm(:,:,:);
        
        Xcqt = cqt(x,B,Fs,fmin,fmax);
        X = Xcqt.c;
        Xdouble = zeros(size(X).*[2 1]);
        Xdouble(1:2:end,:) = X;

%         X = X(:,1:end-1); Xcqt.c = X;
%         Xdouble = Xdouble(:,1:end-1);
%         Sm = Sm(:,1:end-1,:);
%         Sm_double = Sm_double(:,1:end-1,:);

        x = icqt(Xcqt);
        for k=1:K
            Smcqt(k).c = Sm(:,:,k);
            sm_aux(k,:) = icqt(Smcqt(k));
        end
        sm = sm_aux;
        
        [F,T] = size(X);
        Qa = 1;         % HRNMF AR filter length
        Qb = 0;
        
        W_ini = rand(F,K);
        W_ini_double = zeros(2*F,K); W_ini_double(1:2:end,:) = W_ini;
        H_ini = rand(K,T);

end

t = size(sm,2);
ts = (0:T-1)*hop / Fs;
freq = (1:Nw/2)*Fs/Nw;
