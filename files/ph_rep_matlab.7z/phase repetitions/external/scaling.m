function [S_t] = scaling (S)
x = length(S);
smin=min(min(S));
smax=max(max(S));
a = 2/(smax-smin);
b = 1-a*smax;
S_t= a * S + b;
end
