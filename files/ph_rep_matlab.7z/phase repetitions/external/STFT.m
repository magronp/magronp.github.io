function S = STFT(x, Nfft, w, hop)
% D = stft(X, F, W, H, SR)                       Short-time Fourier transform.
%	Returns some frames of short-term Fourier transform of x.  Each 
%	column of the result is one F-point fft (default 256); each
%	successive frame is offset by H points (W/2) until X is exhausted.  
%       Data is hann-windowed at W pts (F), or rectangular if W=0, or 
%       with W if it is a vector.
%       Without output arguments, will plot like sgram (SR will get
%       axes right, defaults to 8000).
%	See also 'istft.m'.
% dpwe 1994may05.  Uses built-in 'fft'
% $Header: /home/empire6/dpwe/public_html/resources/matlab/pvoc/RCS/stft.m,v 1.4 2010/08/13 16:03:14 dpwe Exp $

if nargin < 2;  Nfft = 256; end
if nargin < 3;  w = Nfft; end
if nargin < 4;  hop = 0; end

% expect x as a row
if size(x,1) > 1
  x = x';
end

if length(w) == 1
  if w == 0
    % special case: rectangular window
    win = ones(1,Nfft);
  else
    if rem(w, 2) == 0   % force window to be odd-len
      w = w + 1;
    end
    halflen = (w-1)/2;
    halff = Nfft/2;   % midpoint of win
    halfwin = 0.5 * ( 1 + cos( pi * (0:halflen)/halflen));
    win = zeros(1, Nfft);
    acthalflen = min(halff, halflen);
    win((halff+1):(halff+acthalflen)) = halfwin(1:acthalflen);
    win((halff+1):-1:(halff-acthalflen+2)) = halfwin(1:acthalflen);
  end
else
  win = w;
end

Nw = length(win);
% now can set default hop
if hop == 0
  hop = floor(Nw/2);
end

% c = 1;
% 
% % pre-allocate output array
% S = zeros((1+Nfft/2),1+fix((s-Nfft)/shift));
% 
% for b = 0:shift:(s-Nfft)
%   xw = win'.*x((b+1):(b+Nw));
%   X = fft(xw,Nfft);
%   S(:,c) = X(1:(1+Nfft/2))';
%   c = c+1;
% end

Q = floor(Nw/hop);
x = [zeros(1,(Q-1)*hop) x zeros(1,(Q-1)*hop)];
l = length(x);
T = ceil((l-Nw)/hop)+1;
x = [x zeros(1,(T-1)*hop+Nw-l)];

S = zeros(Nfft/2+1,T);

for t = 1:T,
    time = 1 + (t-1) * hop : Nw + (t-1) * hop;
    xw = x(time) .* win';
    X = fft(xw,Nfft);
    X = X(1:Nfft/2+1);
    S(:,t) = X;
end

end
