
function score = score_separation_PEASS(sm,xest,direc,source_type,algos,Fs)

K = size(sm,1);
Nal = length(algos);

% PEASS options
options.segmentationFactor = 1;
options.destDir = direc;

% Original Files Record and path
originalFiles = cell(K,1);
for k=1:K
    originalFiles{k} = strcat(direc,source_type,'_orig',int2str(k),'.wav');
    audiowrite(originalFiles{k},0.999*scaling(sm(k,:)),Fs);
end

%score = struct('OPS',zeros(1,Nal),'TPS',zeros(1,Nal),'IPS',zeros(1,Nal),'APS',zeros(1,Nal),'SDR',zeros(1,Nal),'ISR',zeros(1,Nal),'SIR',zeros(1,Nal),'SAR',zeros(1,Nal));
score = struct('OPS',zeros(1,Nal),'IPS',zeros(1,Nal),'APS',zeros(1,Nal),'SDR',zeros(1,Nal),'SIR',zeros(1,Nal),'SAR',zeros(1,Nal));

for al=1:Nal

    a = algos(al); a = a{1};
    for k=1:K
        % Source name
        est = strcat(direc,source_type,'_',a,int2str(k),'.wav');
        
        %Record
        audiowrite(est,0.999*scaling(squeeze(xest(al,k,:))),Fs);
        
        %PEASS
        res = PEASS_ObjectiveMeasure(originalFiles,est,options);
        score.OPS(al) = score.OPS(al) + res.OPS/K;
        score.IPS(al) = score.IPS(al) + res.IPS/K;
        score.APS(al) = score.APS(al) + res.APS/K;
        
        score.SDR(al) = score.SDR(al) + res.SDR/K;
        score.SIR(al) = score.SIR(al) + res.SIR/K;
        score.SAR(al) = score.SAR(al) + res.SAR/K;
        
        originalFiles = circshift(originalFiles,1);
    end
    
end

delete(strcat(direc,'*eArtif.wav'));
delete(strcat(direc,'*eInterf.wav'));
delete(strcat(direc,'*eTarget.wav'));
delete(strcat(direc,'*true.wav'));

clc;

end