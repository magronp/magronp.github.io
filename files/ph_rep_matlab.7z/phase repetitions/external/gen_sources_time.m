% 
% ----    Time domain signal generator  -----
%       Paul Magron
% 
% 'SYNTH'           synthetic harmonics
% 'SYNTH_NO_OL'     synthetic mixture with no overlapp in the TF domain
% 'SYNTH_OL'        synthetic mixture with overlapp in the TF domain
% 'CHIRP'           linear chirp
% 'VIBRATO'         synthetic mixture with vibrato
%
% 'PIANO_ONE'       one single piano note
% 'PIANO_TWO'       two occurences of the same note
% 'PIANO_RAND'      random piano notes mixtures from MAPS database
% 'PIANO_H'         piano notes mixtures in harmonic relation
% 'PIANO_NO_OL'     piano notes mixtures from MAPS database without TF overlap
%
% 'SPEECH'          speech excerpt
% 'SOGROOVE'            polyphonic MIDI song
%
% 'DIRAC'           synthetic mixture of diracs
% 'DRUM'            percussive signal (drum)
%
% 'otherwise'       enter the name of the song
% (monophonic recording and instantaneous mix)

sources_path = '../Sounds/';
clear s sm  x name;
switch source_type
    
    % ---------------- SYNTHETIC MIXTURES ---------------------
    case 'SYNTH'
        K = 1;
        n=0:1/Fs:1;
        f0 = [600 1200 2400 3700]';
        damp = 1*[1 3 2 0.1]';
        s = sum(exp(-damp*n).*sin(2*pi*f0*n)); s=s(:); s=s';
        
    case 'SYNTH_ONE'
        K = 1;
        L = Fs;
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        s(1,:) = real(Synthesis(L,damp1,f1,a1,phi1,60))';
        s = [zeros(1,1000) s zeros(1,1000)];
        
     case 'SYNTH_TWO'
        K = 1;
        L = Fs;
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        s(1,:) = [zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))' zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))' zeros(1,2000)];
        %s(2,:) = zeros(1,2000+L);
        
    case 'SYNTH_BEAT'
        K = 1;
        n=0:1/Fs:1;
        f0 = [1200 1210]';
        damp = 1*[1 1]';
        s = sum(exp(-damp*n).*sin(2*pi*f0*n)); s=s(:); s=s';

    case 'SYNTH_NO_OL',
        K = 2;
        L = Fs;
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        f2_Hz = f1_Hz+250; f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,3); damp2 = -rand(1,1)/10000*[1 1 1]; phi2 = randn(1,3);        
        
         s(1,:) = [zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))'];
         s(2,:) = [zeros(1,2000) real(Synthesis(L,damp2,f2,a2,phi2,60))'];

        
    case 'SYNTH_OL',
        K = 2; 
        L = Fs;
        Nharmo = 3;
        f10 = 500+1000*rand(1,1);
        f1_Hz = f10*(1:Nharmo); f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,Nharmo);  damp1 = -rand(1,1)/10000*ones(1,Nharmo); phi1 = randn(1,Nharmo);
        
        f2_Hz = (2*f10+10)*(1:Nharmo); f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,Nharmo); damp2 = -rand(1,1)/10000*ones(1,Nharmo); phi2 = randn(1,Nharmo);
        
        s(1,:) = [ zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))'];
        s(2,:) = [ zeros(1,2000) real(Synthesis(L,damp2,f2,a2,phi2,60))'];

        
     case 'SYNTH_TWO_BEAT',
        K = 2; 
        L = Fs;
        Nharmo = 3;
        f10 = 300;
        f1_Hz = f10*(1:Nharmo); f1 = f1_Hz/Fs;
        a1 = 0.5*ones(1,Nharmo); damp1 = -zeros(1,Nharmo)/1000; phi1 = randn(1,Nharmo);
        
        f2_Hz = (2*f10+15)*(1:Nharmo); f2 = f2_Hz/Fs;
        a2 = 0.5*ones(1,Nharmo); damp2 = -zeros(1,Nharmo)/1000; phi2 = randn(1,Nharmo);
        
        s(1,:) = [ zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))'];
        s(2,:) = [ zeros(1,2000) real(Synthesis(L,damp2,f2,a2,phi2,60))'];
        
        
    case 'CHIRP',
        K = 1;
        n=0:1/Fs:1;
        fHz = 1500;
        s = sin(2*pi*(fHz+500*n).*n);
        
    case 'VIBRATO',
        K = 2;
        n=0:1/Fs:1;
        fHz = 1500;
        s(1,:) = exp(-1.5*n).*sin(2*pi*fHz*n);
        s(2,:) = sin(2*pi*(fHz+100)*n+20*sin(2*pi*3*n));
        
    case 'DIRAC'
        K = 1;
        s = [zeros(1,999) 3 zeros(1,1000) 2 zeros(1,1000) ];
        
    case 'HEAVISIDE'
        K = 1;
        s = [zeros(1,5000) ones(1,5000) ];
        
        
    % ---------------- PIANO NOTES ---------------------

    case 'PIANO_ONE',
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(60),'_F.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'PIANO_ONE_RAND',
        K = 1;
        index = randi(88,1,1)+20;
        [s,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index),'_F.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'PIANO_TWO',
        K = 1;
        index = randi(88,1,1)+20;
        [s,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index),'_F.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s  zeros(1,1000) s ];
        
    case 'PIANO_RAND',
        K = 2;
        index = randi(88,1,K)+20;
        while ismultiple(index)
            index = randi(88,1,K)+20;
        end;
        [s1,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index(1)),'_F.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index(2)),'_F.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
     case 'PIANO_RAND_MORE',
        K = 3;
        index = randi(88,1,K)+20;
        while ismultiple(index)
            index = randi(88,1,K)+20;
        end;
        for k=1:K
            [saux,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index(k)),'_F.wav')); saux=saux';
            s(k,:) = resample(saux,Fs,Fs_old);
        end
        s = s(:,1:floor(size(s,2)/2));
        
        
   case 'PIANO_H',
        K = 2;
        index = zeros(1,K);
        %index(1) = 60;
        index(1) = randi(81)+20;
        index(2) = index(1)+7;
        [s1,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index(1)),'_M.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index(2)),'_M.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        
   case 'PIANO_H_THREE',
        K = 3;
        [s1,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(60),'_F.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(64),'_F.wav')); s2=s2';
        s3 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(67),'_F.wav')); s3=s3';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s(3,:) = resample(s3,Fs,Fs_old);
        
    case 'PIANO_NO_OL',
        K = 2;
        [s1,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(60),'_F.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(68),'_F.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        
    case 'PIANO_NUANCE',
        K = 1;
        index = randi(88,1,1)+20;
        [s1,Fs_old] = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index),'_M.wav')); s1 = mean(s1,2); s1=s1';
        s2 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index),'_F.wav')); s2 = mean(s2,2); s2=s2';
        s3 = audioread(strcat('../Sounds/MAPS isolated/piano',int2str(index),'_P.wav')); s3 = mean(s3,2); s3=s3';
        s1 = resample(s1,Fs,Fs_old);
        s2 = resample(s2,Fs,Fs_old);
        s3 = resample(s3,Fs,Fs_old);
        s = [zeros(1,1000) s1 zeros(1,1000) s2 zeros(1,1000) s3];
        
        
    % ---------------- PIANO PIECES ---------------------      
    case 'PIANO_PIECE',
        K = 1;
        fid = fopen('../Sounds/MAPS pieces/list_pieces.txt'); T = textscan(fid, '%s', 'Delimiter','\n');
        name = T{1}; name = name(num_piece);
        L = char(strcat('MAPS_MUS-',name,'_StbgTGd2.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2);
        s = resample(s,Fs,Fs_old)';
        fclose(fid);
    
    
    % -------------------- SPEECH -----------------------  
    case 'SPEECH',
        K = 1;
        [s,Fs_old] = audioread('../Sounds/speech/speech2.wav');
        s = resample(s,Fs,Fs_old); s=s(:); s=s';
   
     case 'SPEECH_PIECE',
        K = 1;
        fid = fopen('../Sounds/speech/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        name = T{1}; name = name(num_piece);
        L = char(strcat(name,'.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2);
        s = resample(s,Fs,Fs_old)';
        fclose(fid);
        
        
    % -------------------- STRINGS ----------------------
    case 'STRING_PIECE',
        K = 1;
        fid = fopen('../Sounds/SCISSDB/sounds - method 1 - isolated notes/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        name = T{1}; name = name(num_piece);
        L = char(strcat(name,'_mix.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2);
        s = resample(s,Fs,Fs_old)';
        fclose(fid);
    
    
    % ------------------- SO GROOVE ---------------------  
    case 'SOGROOVE',
        K = 7;
        [s_aux,Fs_old] = audioread(strcat('../Sounds/sogroove/midi',int2str(1),'.wav'));
        s_aux = resample(s_aux,Fs,Fs_old);
        s = zeros(K,length(s_aux));
        s(1,:) = s_aux;
        for k=2:K
            [s_aux,Fs_old] = audioread(strcat('../Sounds/sogroove/midi',int2str(k),'.wav'));
            s(k,:) = resample(s_aux,Fs,Fs_old);
        end
        
        
    % -------------------- DRUMS ----------------------  
     case 'DRUM',
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/drums/drum',int2str(num_piece),'.wav'));
        s = s(:);  s=s';
        s = resample(s,Fs,Fs_old);
        
     case 'DRUM_TWO',
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/drums/drum',int2str(num_piece),'.wav'));
        s = s(:); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,500) s zeros(1,300) s];
  
     case 'DRUM_PIECE',
        K = 1;
        fid = fopen('../Sounds/drums/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        name = T{1}; name = name(num_piece);
        L = char(strcat(name,'.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2);
        s = resample(s,Fs,Fs_old)';
        fclose(fid);
        
    otherwise
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/songs/',source_type,'.wav'));
        s = resample(s,Fs,Fs_old);
        s=s(:); s=s';
end

if (K==1) || (strcmp(source_type,'SOGROOVE'))
   sm = s;
elseif (K==2)
    l = floor(size(s,2)); s = s(:,1:l);
%     sm(1,:) = [s(1,:) zeros(1,l) s(1,:) s(1,:) ];
%     sm(2,:) = [zeros(1,l) s(2,:) zeros(1,l) s(2,:) ];    
    sm(1,:) = [s(1,:) zeros(1,l)  s(1,:) ];
    sm(2,:) = [zeros(1,l) s(2,:)  s(2,:) ];   
%     sm(1,:) = [s(1,:) zeros(1,l)];
%     sm(2,:) = [zeros(1,l) s(2,:)];    
else
    l = floor(size(s,2)); s = s(:,1:l);
    z =zeros(1,l);
%     sm(1,:) = [s(1,:) z z   s(1,:) z s(1,:) z s(1,:)];
%     sm(2,:) = [z      s(2,:) z z s(2,:) s(2,:) s(2,:) s(2,:)];
%     sm(3,:) = [s(3,:) z s(3,:) z s(3,:) z z s(3,:)];
%     
    sm(1,:) = [s(1,:) z      s(1,:)];
    sm(2,:) = [z      s(2,:) s(2,:)];
    sm(3,:) = [s(3,:) s(3,:) z ];
end

x = sum(sm,1);
