%  Synthesis of a sum of damped sinusoids
%  Code by Paul Magron, june 2014.
% 
% Inputs :
%     N : signal lenght
%     a : amplitudes
%     f : normalized frequencies
%     phi : origin phase
%     delta : damping coefficient
%     SNR : Signal/Noise Ratio 
%
% Outputs :
%     s : signal


function s = Synthesis(N,damping,f,a,phi,SNR)

t = (0:N-1);

damping = min([damping(:),zeros(length(damping),1)],[],2);
logz = damping + 1i*2*pi*f(:);
alpha = a(:).*exp(1i*phi(:));

x = sum( (alpha*ones(1,N)) .* exp(logz*t) , 1).';

if nargin<6,
	s = x;
else
    %if there is noise
	Ex = real(x'*x) / N;
	b = randn(N,1) + 1i*randn(N,1);
	Eb = real(b'*b) / N;
	b = b * sqrt(Ex/Eb) * 10^(-SNR/20);
	s = x + b;
end

end