function [w] = perfect_reco_window(Nw,hop)

if hop == Nw
    w = ones(Nw,1);
else
    w = hann(Nw,'periodic');
    Q = floor(Nw/hop);
    
    aux = zeros(Q,Nw);
    aux(1,:) = w' ;
    for l=1:(Q-1)
        aux(l+1,:) = circshift(w,l*hop)';
    end
    aux_norm = sum(aux.^2)';
    
    w = w ./ sqrt(aux_norm);
end

end