% Testing the repeating phase model estimation on realistic data
% Paul Magron, April 2015

clc; clear all; close all;
Niter = 100;
Ndata = 30;

% Data
Fs = 11025; Nw = 512; Nfft = 512; hop = Nw/4;
source_type = 'PIANO_H'; TF_type = 'STFT'; num_piece = 1;
t0 = [6 92 178];
%t0 = [16 118 220];
T0 = length(t0);

% Relax coef
sigma = [0 0.01 0.1 0.2 0.3 0.5 1 10 100];
Lsig = length(sigma);

% Init error functions
costWiener = zeros(Ndata,Lsig,2); 
costStrict = zeros(Ndata,Lsig,2);
costRelax = zeros(Ndata,Lsig,2);

for it=1:Ndata
    fprintf('Iteration %d / %d',it,Ndata);

    % Select onset framescostWiener
    gen_sources_time; gen_sources_TF;
    X0 = X(:,t0);
    Sm0 = Sm(:,t0,:);
    A0 = abs(Sm0);

    % Phase estimation - relaxed
    chi0 = exp (1i * randn(F,K));
    mu0 = exp(1i * rand(K,T0));

    for it_sig = 1:Lsig
        [Yr,Ymix,psi,lambda,chi,mu,err]=onset_reco_relax(X0,A0,chi0,mu0,Niter,sigma(it_sig));
         costRelax(it,it_sig,1) = norm(Sm0(:,:,1)-Yr(:,:,1));
         costRelax(it,it_sig,2) = norm(Sm0(:,:,2)-Yr(:,:,2));
    end
    
    % Phase estimation - strict
    [Ys,Ymixs,psis,lambdas,chis,mus,errs]=onset_reco_strict(X0,A0,chi0,mu0,Niter);
    costStrict(it,:,1) = norm(Sm0(:,:,1)-Ys(:,:,1)) *ones(1,Lsig);
    costStrict(it,:,2) = norm(Sm0(:,:,2)-Ys(:,:,2)) *ones(1,Lsig);
    
    % Phase estimation - Wiener
    costWiener(it,:,1) = norm(Sm0(:,:,1)- (A0(:,:,1)./sum(A0,3)).^2 .* X0 ) *ones(1,Lsig);
    costWiener(it,:,2) = norm(Sm0(:,:,2)- (A0(:,:,2)./sum(A0,3)).^2 .* X0 ) *ones(1,Lsig);
    clc;

end

% Average results over sources and iterations
costS = mean(mean(costStrict,3),1);
costR = mean(mean(costRelax,3),1);
costW = mean(mean(costWiener,3),1);

% Comparison with mixture phase
figure;
plot(1:Lsig,20*log10(costW),'b--',1:Lsig,20*log10(costS),'g-',1:Lsig,20*log10(costR),'r+');
p=xlabel('\sigma'); set(p,'FontSize',16);
set(gca,'XTickLabel',sigma);
p=ylabel('Error (dB)'); set(p,'FontSize',16);
p=legend('Wiener filtering','Strict constraint','Relaxed constraint'); set(p,'FontSize',16);
