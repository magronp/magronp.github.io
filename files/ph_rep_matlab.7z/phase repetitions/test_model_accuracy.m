% Testing the repeating model accuracy.
% source_type must be equal to 'PIANO_TWO' or 'SYNTH_TWO'
% Paul Magron, April 2015

clc; clear all; close all;
Ndata = 30;

% Data
Fs = 11025; Nw = 512; Nfft = 512; hop = Nw/4;
source_type = 'PIANO_TWO'; TF_type = 'STFT';
%t0 = [16 118];    % synth attack times
t0 = [13 193];    % piano attack times

err_av = zeros(1,Ndata);

for it=1:Ndata
    % Gen sources
    num_piece = it;
    gen_sources_time; gen_sources_TF;

    % Estimate delays
    diff_phase = unwrap(angle((Sm(:,t0(2)) ./ Sm(:,t0(1)))));
    co = polyfit((0:F-1)',diff_phase,1);
    diff_estim = co(1)*(0:(F-1))';

    % Estimate error
    err = abs( (diff_phase - diff_estim) ./ diff_phase );
    err_av(it) = mean(err(2:end));
end

% Plot phase estimation
figure;
subplot(1,2,1);
imagesc(ts,freq,20*log10(abs(X))); axis xy;
p=xlabel('Time (s)'); set(p,'FontSize',16);
p=ylabel('Frequency (Hz)'); set(p,'FontSize',16);

subplot(1,2,2);
plot([0 freq],diff_phase,'-b',[0 freq],diff_estim,'--r');
p=xlabel('Frequency (Hz)'); set(p,'FontSize',16);
p=ylabel('Unwrapped phase'); set(p,'FontSize',16);
p=legend('Data','Model');set(p,'FontSize',16);
