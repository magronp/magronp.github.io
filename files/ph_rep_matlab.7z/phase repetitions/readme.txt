%%%% Repeating phase model for phase estimation %%%%

Paul Magron, Roland Badeau, Bertrand David 2015


Main scripts are :

 * test_model_accuracy : compute the phase difference between onset frames in simple signals and the error between data and estimate

 * test_model_data : phase estimation on model-built data

 * test_real_data : phase estimation on realistic data

 * test_source_separation : perform source separation


Those scripts use the two main function :

 * onset_reco_strict : phase estimation algorithm under strict constraint

 * onset_reco_relaxed : phase estimation algorithm under relaxed constraint


This code requires some external functions (found in the 'external' folder).

Be also sure to have installed some dependancies :

 - The MATLAB Tempogram Toolbox (in those scripts, onset frames are known)
 - The PEASS toolbox for source separation evaluation
 - Piano sounds from the MAPS database

MIDI files are provided in the 'sogroove' folder.



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Article related to this work:

Paul Magron, Roland Badeau, and Bertrand David. A repeating model for phase reconstruction of spectrograms: application to audio source separation.
in Proc. of IEEE Workshop on Applications of Signal Processing to Audio and Acoustics (WASPAA), New Paltz, NY, USA, October 2015