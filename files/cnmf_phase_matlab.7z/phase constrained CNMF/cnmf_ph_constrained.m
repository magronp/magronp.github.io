% Sparse Complex NMF with phase constraints (linear unwrapping and repetitions)
% Paul Magron, August 2015
%
% Inputs:
%     X : F*T complex matrix
%     Wini, Hini : initial dictionnary and activations matrices (F*K and K*T)
%     Niter : number of iterations (complex NMF)
%     p : sparsity parameter
%     sigma_s : sparsity weight
%     sigma_u : unwrapping weight
%     sigma_r : repetition weight
%
% Outputs:
%     Xhat : F*T*K estimated complex components
%     Xmix : F*T estimated mix
%     W,H : dictionnary and activations matrices (F*K and K*T)
%     Phi : exp(i*phi) phases matrices (F*T*K)
%     err : cost function

function [Xhat,Xmix,W,H,Phi,err]=cnmf_ph_constrained(X,Wini,Hini,Niter,Nini,p,sigma_s,sigma_u,sigma_r,UN,Nfft,hop)

[F,T] = size(X); K = size(Wini,2);

% Initialization
if Nini == 0
    W = Wini; H = Hini;
else
    [W,H] = KL_nmf(abs(X),Wini,Hini,Nini);
end
[W,H] = normalize_WH(W,H);

OFT = ones(F,T);

% Compute UN and UNbarr matrices
%UN = get_onset(H);
UNbarr = abs(1-UN);

% Phase parameters
Phi = repmat(exp(1i*angle(X)),[1,1,K]);
Psi = exp(1i * rand(F,K));
Lambda = exp(1i * rand(F,T,K));
Lambda(:,UN'==0) = 0;

% init components
[Xhat,Xmix,B,~] = update_aux(X,W,H,Phi);

% error
err = zeros(1,Niter+1);
nu = get_freq(W)/Nfft; mu = exp(1i*2*pi*hop*nu);
err(1) = get_err(X,Xmix,W,H,Phi,UN,mu,Psi,Lambda,p,sigma_s,sigma_u,sigma_r);

for it=1:Niter
   
    % Estimate nu  and mu : normalized frequencies / reg influence from W matrix
    nu = get_freq(W)/Nfft; mu = exp(1i*2*pi*hop*nu);
        
    % Update Psi
    for k=1:K
        aux = sum((conj(Lambda(:,:,k)).*Phi(:,:,k)).*(abs(X).^2),2);
        Psi(:,k) = exp(1i*angle(aux));
    end
    
    % Upadate Lambda
    for k=1:K
        aux = ( Psi(1:end-1,k) .* conj(Psi(2:end,k))).' * (  abs(X(1:end-1,:)) .* abs(X(2:end,:)) .* conj(Phi(1:end-1,:,k)) .* Phi(2:end,:,k));
        aux = exp(1i*angle(aux));
        Lambda(:,:,k) = vandermonde(aux,F);
        Lambda(:,UN(:,k)==0,k) = 0;
    end
    
    % Update Phi
    for k=1:K
        for tt=2:T
            rho = sigma_r * (Psi(:,k)*UN(k,tt) ) .* Lambda(:,tt,k) + sigma_u * UNbarr(k,tt) * mu(:,k).* Phi(:,tt-1,k);
            aux = B(:,tt,k).*(W(:,k)*H(k,tt)) + (abs(X(:,tt)).^2).*rho;
            Phi(:,tt,k) = exp(1i*angle(aux));
        end
    end
    
    %up components
    [~,~,~,beta] = update_aux(X,W,H,Phi);
    
    % up W
    for k=1:K
        W(:,k) = (  beta(:,:,k)*H(k,:)' ) ./ max( OFT * (H(k,:).^2)' ,eps );
    end
    %W = max(W,0);
    W =abs(W);
    
    % update aux
    [~,~,~,beta] = update_aux(X,W,H,Phi);
    
    % up H
    for k=1:K
        H(k,:) = (  W(:,k)' * beta(:,:,k) ) ./ max( ( p*sigma_s*(H(k,:)+eps).^(p-2) ) +  ((W(:,k).^2)' * OFT) ,eps );
    end
    %H = max(H,0);
    H = abs(H);
    
    % normalize
    [W,H] = normalize_WH(W,H);
    
    %up components
    [Xhat,Xmix,B,~] = update_aux(X,W,H,Phi);    
    
    %error
    err(it+1) = get_err(X,Xmix,W,H,Phi,UN,mu,Psi,Lambda,p,sigma_s,sigma_u,sigma_r);
end


end

% Normalization (L1-norm) for W and H
function [W,H] = normalize_WH(W,H)
    F = size(W,1); T = size(H,2);
    normW = sum(W);
    W = W./repmat(normW,F,1);
    H = H.*repmat(normW',1,T);
end

% Update auxiliary variables
function [Xhat,Xmix,B,beta] = update_aux(X,W,H,Phi)
    [F,K] = size(W);
    T = size(H,2);
    Vhat = zeros(F,T,K);
    for k=1:K
       Vhat(:,:,k) = W(:,k)*H(k,:);
    end
    Xhat = Vhat .* Phi;
    Xmix = sum(Xhat,3);
    B = repmat(X-Xmix,[1,1,K]) + Xhat;
    beta = real( B .* conj(Phi));
end

% Get the error
function [errs] = get_err(X,Xmix,W,H,Phi,UN,mu,Psi,Lambda,p,sigma_s,sigma_u,sigma_r)
    [F,K] = size(W);
    T = size(H,2);
    UNbarr = abs(1-UN);
    Phi0 = [zeros(F,1,K) Phi(:,1:end-1,:)];
    u = zeros(F,T,K); r = zeros(F,T,K);
    for k=1:K
        u(:,:,k) = repmat(UNbarr(k,:),F,1) .* abs(Phi(:,:,k) - diag(mu(:,k))*Phi0(:,:,k));
        r(:,:,k) = repmat(UN(k,:),F,1) .* abs(Phi(:,:,k) - diag(Psi(:,k))*Lambda(:,:,k));
    end
    errs = norm(X-Xmix).^2 + 2*sigma_s*sum(H(:).^p) + sigma_u * normTsquare(repmat(abs(X),[1,1,K]).*u) + sigma_r * normTsquare(repmat(abs(X),[1,1,K]).*r);
end

