% Compute the indicator of onset frames from H matrix (cf [Paulus &
% Virtanen 2007]
% Paul Magron, July 2015
%
% Inputs:
%     H : activations matrix (K*T)
%
% Outputs:
%     UN : K*T onset indicator matrix

function [UN] = get_onset(H)

[K,T] = size(H);
UN = zeros(K,T);
for k=1:K
    UN(k,:) = get_onset_vector(H(k,:));
end

end



function [UNv] = get_onset_vector(v)
J=100;

% Excpect row vector
v = v(:)';

% Normalize and compress
 v = v / max(v);
vlog = log(1+J*v);

% Differentiate and filter
diff_v = vlog - [0 vlog(1:end-1)];
[b,a] = butter(4,0.25*pi);
dfil = filter(b,a,vlog);

% Peak picking
[~,ind] = findpeaks(dfil,'MINPEAKHEIGHT',max(dfil)/2);
UNv = zeros(1,length(v));
UNv(ind) = 1;

end