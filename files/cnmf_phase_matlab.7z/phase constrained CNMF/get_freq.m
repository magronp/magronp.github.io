% Compute frequencies with QIFFT and regions of influences from a matrix of
% spectral templates W
% Paul Magron, July 2015
%
% Inputs:
%     W : F*K nonnegative dictionnary matrix 
%
% Outputs:
%     f_channel : F*K frequencies matrix

function [f_channel] = get_freq(W)

[F,K] = size(W);
f_channel = zeros(F,K);
for k=1:K
    f_channel(:,k) = freq_influence(W(:,k))-1;
end

end