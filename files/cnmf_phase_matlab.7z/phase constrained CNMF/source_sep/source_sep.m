clear all; clc; close all;
Fs = 11025; Nfft = 512; Nw = 512; hop = Nw/4; TF_type = 'STFT';
Ncnmf = 5; Nnmf = 30; 
Npieces = 1;
rec=1;

% Phase Parameters vectors
Sigma_r = 0.2; Nr = length(Sigma_r);
Sigma_u = 0.2; Nu = length(Sigma_u);
cnmf_wiener = 1;

% Dataset
sces = {'PIANO_C-G'}; Nsc = length(sces);
res_files = strcat('phase constrained CNMF/source_sep/results_',sces,'.mat');

% Loop over the datasets
for sc = 1:Nsc
    source_type = sces{sc};
    
    % Run the simulation
    run_simul_CNMFph;
    
    % Save scores
    res.SDR_av = SDR_av; res.SIR_av = SIR_av; res.SAR_av = SDR_av;
    res.SDR_wiener_av = SDR_wiener_av; res.SIR_wiener_av = SIR_wiener_av; res.SAR_wiener_av = SDR_wiener_av;
    res.SDR_cnmf_av = SDR_cnmf_av; res.SIR_cnmf_av = SIR_cnmf_av; res.SAR_cnmf_av = SDR_cnmf_av;
    res.Sigma_r = Sigma_r; res.Sigma_u = Sigma_u;
    save(res_files{sc},'res');
end


% Visualize scores
if strcmp(source_type,'PIANO_E-B')
    fspec = 56; kk=2;
    tdeb = 177; tend = 200;
    tts = ts(tdeb:tend);
    vv = Sm(fspec,tdeb:tend,kk);
    ve = Xhat(fspec,tdeb:tend,kk);
    ve_wiener = Xhat_wiener(fspec,tdeb:tend,kk);
    ve_cnmf = Xhat_cnmf(fspec,tdeb:tend,kk);
    figure;
    plot(tts,real(vv),'k',tts,real(ve),'b-+',tts,real(ve_cnmf),'r*-',tts,real(ve_wiener),'md-');
    ha=xlabel('Time (s)'); set(ha,'FontSize',16);
    Vax=axis; axis([tts(1) tts(end) Vax(3) Vax(4)]);
    figure;
    plot(tts,abs(vv),'k',tts,abs(ve),'b-+',tts,abs(ve_cnmf),'r*-',tts,abs(ve_wiener),'md-');
    ha=ylabel('Magnitude'); set(ha,'FontSize',16);
    ha=xlabel('Time (s)'); set(ha,'FontSize',16);
    Vax=axis; axis([tts(1) tts(end) Vax(3) Vax(4)]);
    ha=legend('original','CNMF-\phi','NMF-W','CNMF'); set(ha,'FontSize',14);
end