% Visualize results of the influence of sigma_r and sigma_u on the source separation
% score
% Code by Paul Magron, September 2015

function [] = image_sigma_r_u(res_synth,res_piano)

% Synthetic data
res = res_synth;
xl = res.Sigma_u;
yl = res.Sigma_r;

hf1=figure;
set(hf1,'Position',[610 653 1039 303]);
gcmap = colormap(autumn); gcmap = gcmap(end:-1:1,:); colormap(gcmap);

subplot(1,3,1);
imagesc(res.SDR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
ha = title('SDR'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)

subplot(1,3,2);
imagesc(res.SIR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
ha = title('SIR'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)

subplot(1,3,3);
imagesc(res.SAR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
ha = title('SAR'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)


% Piano notes
res = res_piano;
xl = res.Sigma_u;
yl = res.Sigma_r;

hf2=figure;
set(hf2,'Position',[610 205 1039 303]);
gcmap = colormap(autumn); gcmap = gcmap(end:-1:1,:); colormap(gcmap);

subplot(1,3,1);
imagesc(res.SDR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)

subplot(1,3,2);
imagesc(res.SIR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)

subplot(1,3,3);
imagesc(res.SAR_av); axis xy;
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('\sigma_r'); set(ha,'FontSize',16);
set(gca,'XTickLabel',xl); set(gca,'YTickLabel',yl)

end