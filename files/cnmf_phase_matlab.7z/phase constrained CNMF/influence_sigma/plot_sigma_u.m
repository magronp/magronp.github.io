% Visualize results of the influence of sigma_u on the source separation
% score
% Code by Paul Magron, September 2015

function [] = plot_sigma_u(res_synth,res_piano)

xx = res_synth.Sigma_u;

hFig = figure(1);
set(hFig, 'Position', [500 500 850 280])

subplot(1,3,1);
plot(xx,res_synth.SDR_av,'b--',xx,res_piano.SDR_av,'r');
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('SDR (dB)'); set(ha,'FontSize',16);
V =axis; axis([xx(1) xx(end) V(3) V(4)])

subplot(1,3,2);
plot(xx,res_synth.SIR_av,'b--',xx,res_piano.SIR_av,'r');
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('SIR (dB)'); set(ha,'FontSize',16);
V =axis; axis([xx(1) xx(end) V(3) V(4)])

subplot(1,3,3);
plot(xx,res_synth.SAR_av,'b--',xx,res_piano.SAR_av,'r');
ha = xlabel('\sigma_u'); set(ha,'FontSize',16);
ha = ylabel('SAR (dB)'); set(ha,'FontSize',16);
ha = legend('synth','piano'); set(ha,'FontSize',14);
V =axis; axis([xx(1) xx(end) V(3) V(4)])

end