%%%% Phase reconstruction with linear unwrapping %%%%

Paul Magron, Roland Badeau, and Bertrand David. Phase reconstruction of spectrograms with linear unwrapping: application to audio signal restoration.
in Proc. European Signal Processing Conference (EUSIPCO), Nice, France, October 2015


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This folder contains the code related to the above-mentionned article on Linear Phase Unwrapping.
The folders "Declick", "generators", "Onset detection", "BSS EVAL" and "STFT", as well as the functions "griffin-lim" and "phvoc_freq" are auxiliary functions used in this work.

In particular, BSS Eval and Onset Detections are based on previous work, so if you want to use this work, please quote in your papers the following references (as well as this paper) :

- Peter Grosche and Meinard M�ller, Tempogram Toolbox: MATLAB Implementations for Tempo and Pulse Analysis of Music Recordings.
International Conference on Music Information Retrieval (ISMIR), Miami, FL, USA, 2011

- Emmanuel Vincent, R�mi Gribonval and C�dric F�votte, Performance measurement in blind audio source separation,
IEEE Trans. Audio, Speech and Language Processing, 14(4), pp 1462-1469, 2006.


You might also need to download the MAPS database in order to access the piano sounds used in this code :

http://www.tsi.telecom-paristech.fr/aao/en/2010/07/08/maps-database-a-piano-database-for-multipitch-estimation-and-automatic-transcription-of-music/


Alternatively, if you want to conduct experiments on your own sounds, please modify the time signal generator which is found in "generators/gen_sources_time.m", or modify the corresponding line in the MATLAB script in order to generate your own sounds.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

The main functions and scripts are found in the "phase unwrapping" folder. Here are the core functions:


 * phase_unwrapping : the linear phase unwrapping algorithm function

 * find_n0 : used to compute the n0 attack time with the impulse model (LS)

 * freq_influence : computes the instantaneous frequencies with qifft and decompose the frequency domain in regions of influence

 * restore_mag : magnitude restoration (as used in the click removal application)


The folder "test horizontal" contains scripts for testing the horizontal unwrapping :


 * test_ph_reco_horizontal : a test of the phase unwrapping algorithm

 * benchmark_horizontal : compares the phase unwrapping technique with GriffinLim on a variety of data

 * test_qifft : compute the instantaneous frequencies with qifft and compare to the phase vocoder technique


The folder "test vertical" contains scripts for testing the vertical unwrapping :


 * test_impulse : test the impulse model based vertical unwrapping

 * compare_pitch : compare the vertical unwrapping methods for pitched signals

 * compare_percussive : compare the vertical unwrapping methods on drum sounds



The folder "test complete" contains scripts for testing the vertical unwrapping :


 * demo_restoration_phase : phase inpainting

 * demo_restoration_STFT_rand : restoration of both phase and magnitude of corrupted STFTs


The folder "exp declick" contains the main function "demo_restoration_click" that performs the restoration of corrupted signals.



Finaly, a "sounds" folder is used in order to record experimental sounds (the recording is activated when setting the boolean "rec" to 1 in the different scripts).

