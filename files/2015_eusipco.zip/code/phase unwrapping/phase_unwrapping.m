% Linear phase unwrapping algorithm
% Paul Magron, Feb 2015
%
% Inputs:
%     X : F*T complex matrix
%     Fs : sample rate (Hz)
%     w : analysis window
%     hop : STFT overlap (in samples)
%     delta : index matrices (the bin (f,t) is reconstructed if delta(f,t)=1)
%     meth : integer value indicating the vertical unwrapping method (0: horizontal only)
%     tonset : onset frames (if any)
%
% Outputs:
%     phi : reconstructed phase
%     t_vert : onset frames
%     f_inf : instantaneous frequencies matrix
%     n0 : attack times

function [phi,tonset,f_inf,n0] = phase_unwrapping(X,Fs,w,hop,delta,meth,tonset)

V = abs(X);
[F,T] = size(V);

% Onset detection
if nargin<7
    tonset = detect_onset_frames(V,Fs,w,hop);
end
tonset =tonset(:)';

% Phase unwrapping method : horizontal by def.
if nargin<6
    meth = 0;
end

% if no ft, then all bins are corrupted (to be reconstructed)
if nargin<5
    delta = ones(F,T);
end

Nfft = 2*(F-1);
phi = zeros(F,T);
phi(delta<1) = angle(X(delta<1));
Ct = 2*pi*hop/Nfft;
Cf = -2*pi/Nfft;

% Instantaneous frequencies in regions of influence
ff = 1:F;
f_inf = zeros(F,T);
for t=1:T
    f_inf(:,t) = freq_influence(V(:,t))-1;
end


% Reconstruction of vertical frames
switch meth
    case 0    % Horizontal unwrapping only
        phi(:,tonset) = angle(X(:,tonset));
    
    case 1    % Onset phase reconstruction (impulse model - LS)
        tonset = tonset(tonset<(T-2));
        Q = length(w)/hop-1;
        tonset_use = repmat(tonset',1,Q+1) + repmat((0:Q),length(tonset),1);
        Nt0 = size(tonset,1);
        n0 = zeros(F,Nt0);
        for indt0=1:Nt0
            for f=2:F
            ind_frames_use = tonset_use(indt0,:);
            ind_frames = tonset(indt0,:);
            ind_update = delta(f,ind_frames);
            % n0 estimation
            n0(f,indt0) = find_n0(V(f,ind_frames_use),w,hop);
            % vertical unwrapping
            phi_est = angle(exp(1i*(phi(f-1,ind_frames) + Cf *(n0(f,indt0)-1-hop*4)))) ;
            % compute phase only if not allready known
            phi(f,ind_frames(ind_update>0)) = phi_est(ind_update>0);
            end
        end
        
    case 2   % Onset phase reconstruction (impulse model - QI)
        Nt0 = length(tonset);
        n0 = zeros(F,Nt0);
        for indt0=1:Nt0
            for f=2:F
                ind_frames = tonset(indt0);
                v = 20*log10(V(f,[ind_frames-1 ind_frames ind_frames+1]));
                p = qint(v(1),v(2),v(3));
                n0(f,indt0) = hop*(ind_frames+p);
                phi_est = angle(exp(1i*( phi(f-1,ind_frames) + Cf*n0(f,indt0) )));
                if delta(f,ind_frames)>0
                    phi(f,ind_frames) = phi_est;
                end
            end
        end
        
    case 3  % Random phase on onset frame
        Nt0 = length(tonset);
        for indt0=1:Nt0
            ind_frames = tonset(indt0);
            for f=2:F
                if delta(f,ind_frames)>0
                    phi(f,ind_frames) = rand;
                end
            end
        end
        
     case 4  % Zero phase on onset frame (partials in phase)
         Nt0 = length(tonset);
        for indt0=1:Nt0
            ind_frames = tonset(indt0);
            for f=2:F
                if delta(f,ind_frames)>0
                    phi(f,ind_frames) = rand;
                end
            end
        end
        
    case 5  % Alternate 0 and Pi for partial phases (phase opposition)
        Nt0 = length(tonset);
        for indt0=1:Nt0
            ind_frames = tonset(indt0);
            fff = f_inf(:,ind_frames);
            f_aux = fff;
            c=0;
            while (~isempty(f_aux))
                phi(fff==f_aux(1),ind_frames)=c;
                f_aux = f_aux(~(f_aux==f_aux(1)));
                c=mod(c+pi,2*pi);
            end
        end
        
     case 6  % Alternate 0 and Pi/2 for partial phases (phase opposition)
        Nt0 = length(tonset);
        for indt0=1:Nt0
            ind_frames = tonset(indt0);
            fff = f_inf(:,ind_frames);
            f_aux = fff;
            c=0;
            while (~isempty(f_aux))
                phi(fff==f_aux(1),ind_frames)=c;
                f_aux = f_aux(~(f_aux==f_aux(1)));
                c=mod(c+pi/2,pi);
            end
        end
end


% non-onset frames
t_tot = 1:T;
t_non_onset = t_tot(~ismember(t_tot,tonset));
t_non_onset = t_non_onset(t_non_onset>tonset(1));
t_non_onset = t_non_onset(max(V(:,t_non_onset))>0.01);

% frames to be updated
t_up = intersect(t_non_onset,t_tot(sum(delta)>0));

% horizontal unwrapping
for t=t_up
    ind_freq = delta(:,t).*ff';
    delta_phi = Ct*f_inf(:,t);
    phi_est = phi(:,t-1)+delta_phi;
    phi(ind_freq>0,t) = phi_est(ind_freq>0);
end

phi = angle(exp(1i*phi));

end