clc; clear all; close all;

% Data generation
Fs = 44100; Nw = 4096/8; Nfft = 4096/8; hop = Nw/2; TF_type = 'STFT';
source_type = 'MSD100';
nPHI = 50; nHR = 10; perc = 0.1;

% Methods
alg = {'Corrupted';'Tradi';'HRNMF';'GL';'ForwardU';'BackwardU';'AverageU'}; Nal = length(alg);
direc = 'phase unwrapping/sounds/declick/';

Ndata = 50;
SDR = zeros(Nal,Ndata);

for it =1:Ndata
    clc; fprintf('Iteration %d / %d \n',it,Ndata);

    num_piece=it; gen_sources_time; gen_sources_TF;
    xe = zeros(Nal,length(x));
    
    % Corruption
    [xCO,Xc,delta,tc] = corrupt_click(x,perc,Fs,Nfft,w,hop,0.0005);
    mask = abs(delta-1);
    xe(1,:) = xCO;

    % Traditionnal declick
    xAR = declick_AR(xCO,Nw,0.5,12,11,1);
    xe(2,:) = xAR;
    
    %HRNMF
    XHR = declick_HR(Xc+eps,1,delta,nHR);
    xHR = iSTFT(XHR,Nfft,w,hop);
    xe(3,:) = xHR;
    
    % Magnitude recovery
    Vr = restore_mag(tc,abs(X));
    Xini = Vr;
    Xini(mask==1) = Vr(mask==1) .* exp(1i * angle(Xc(mask==1)));
   
    % Griffin Lim
    xGL = griffin_lim(Xini,w,hop,nPHI);
    xe(4,:) = xGL;

    %forward unwrapping
    phif = phase_unwrapping(Xini,Fs,w,hop,delta,0);
    Xf = Vr.* exp(1i*phif);
    xf = iSTFT(Xf,Nfft,w,hop); xe(5,:) = xf;
    
    %backward unwrapping
    phib = phase_unwrapping(Xini(:,end:-1:1),Fs,w,hop,delta(:,end:-1:1),0,1,-1);
    Xb = Vr.* exp(1i*phib(:,end:-1:1)); 
    xb = iSTFT(Xb,Nfft,w,hop); xe(6,:) = xb;
    
    % Average unwrapping
    Xe = (Xf+Xb)/2; xPU = iSTFT(Xe,Nfft,w,hop);
    xe(7,:) = xPU;
    
    % Score and record
    audiowrite(strcat(direc,source_type,'_orig.wav'),0.999*scaling(x),Fs);
    for al=1:Nal
        estFile = strcat(direc,source_type,'_',alg{al},'.wav');
        audiowrite(estFile,0.999*scaling(xe(al,:)),Fs);
        SDR(al,it) = bss_eval_sources(x',xe(al,:));
    end

     % Plot Spectrograms
%     Xcplot = Xc; Xcplot(20*log10(abs(Xc))<-120) = 10^(-6);
%     figure;
%     subplot(1,3,1); imagesc(ts,freq,20*log10(abs(X))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16); p=ylabel('Frequency (Hz)'); set(p,'FontSize',16); p = title('Original'); set(p,'FontSize',16);
%     subplot(1,3,2); imagesc(ts,freq,20*log10(abs(Xcplot))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16); p = title('Corrupted'); set(p,'FontSize',16);
%     subplot(1,3,3); imagesc(ts,freq,20*log10(Vr)); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16); p = title('Restored'); set(p,'FontSize',16);

end

% Display SDR (BSS eval)
SDR(isnan(SDR))=[];
SDR = reshape(SDR,Nal,length(SDR(:))/Nal);
sdr_av = mean(SDR,2);
clc;
fprintf('--------- SDR Results ---------- \n');
fprintf(' Corrupt         %f dB \n Tradit.         %f dB \n HR NMF          %f dB  \n Griff Lim       %f dB \n Forward Unwrap  %f dB \n Backward Unwrap %f dB \n Average Unwrap  %f dB \n',sdr_av(1),sdr_av(2),sdr_av(3),sdr_av(4),sdr_av(5),sdr_av(6),sdr_av(7));


hfig = figure;
boxplot(SDR([2 3 4 7],:)',{'AR','HRNMF','GL','D�roul�'});
ha = findobj(hfig,'Type','text'); set(ha,'FontSize',16);
set(ha,'VerticalAlignment','top');
ha = ylabel('SDR (dB)'); set(ha,'FontSize',16);
