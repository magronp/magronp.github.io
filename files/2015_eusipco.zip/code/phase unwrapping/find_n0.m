function [n0] = find_n0(v,w,hop)

Q = length(w)/hop-1;
Nt0 = floor(length(v)/(Q+1));

w = w(:)';
logw = log(w);

v = log(v) ;
v = reshape(v,[1 (Q+1) Nt0]);
v = v(:,end:-1:1,:);

logA = repmat(v(:,1,:),[hop 1 1])-repmat(logw(1:hop)',[1 1 Nt0]);
vaux = repmat(v,[hop 1 1]) - repmat(logA,[1 Q+1 1]);
est = repmat(reshape(logw,hop,Q+1),[1 1 Nt0]);
diff = vaux-est;

err = squeeze(sum(diff.^2,2));


[~,n0] = min(err);
n0 = n0+Q*hop;

end