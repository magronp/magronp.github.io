clc; clear all; close all;

% Parameters
Fs = 44100/4; Nfft = 512; Nw = 512; hop = Nw/4; TF_type = 'STFT';   
rec = 1;
direc = 'phase unwrapping/sounds/horizontal/';

% Data generation
source_type = 'VIBRATO';  num_piece = 1;
gen_sources_time; gen_sources_TF;

% Phase reconstruction
tic;
[phi,t0,f_inf] = phase_unwrapping(X,Fs,w,hop);
Xe = abs(X).* exp(1i*phi); xPU = iSTFT(Xe,Nfft,w,hop);
tPU = toc;
SDR_PU = bss_eval_sources(x',xPU');

% Instantaneous frequencies
f_inf_real_Hz = phvoc_freq(X,hop)* Fs /Nfft;
f_inf_Hz = f_inf* Fs /Nfft;
err_freq = sum(sum(abs((f_inf_real_Hz - f_inf_Hz ) ./ (f_inf_real_Hz+eps))));

% Griffin Lim
nPHI = 200;
phi0 = rand(F,T); phi0(:,t0) = angle(X(:,t0));
X0 = abs(X) .* exp(1i * phi0);
x0 = iSTFT(X0,Nfft,w,hop);
tic; [xGL,err] = griffin_lim(X0,w,hop,nPHI); tGL = toc;
SDR_GL = bss_eval_sources(x',xGL);

% Plot spectrogram and instantaneous frequencies
fplot = 100;
figure;
subplot(1,2,1); imagesc(ts,freq,20*log10(abs(X))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16); p=ylabel('Frequency (Hz)'); set(p,'FontSize',16);
subplot(1,2,2); plot(ts,[f_inf_real_Hz(fplot,:)' f_inf_Hz(fplot,:)']); axis([0 3 1490 1670]); p=xlabel('Time (s)'); set(p,'FontSize',16); p=ylabel('Frequency (Hz)'); set(p,'FontSize',16); p=legend('phase vocoder','QIFFT'); set(p,'FontSize',16);

% Record
if rec
    audiowrite(strcat(direc,source_type,'_orig.wav'),0.999*scaling(x),Fs);
    audiowrite(strcat(direc,source_type,'_corr.wav'),0.999*scaling(x0),Fs);
    audiowrite(strcat(direc,source_type,'_PU.wav'),0.999*scaling(xPU),Fs);
    audiowrite(strcat(direc,source_type,'_GL.wav'),0.999*scaling(xGL),Fs);
end
