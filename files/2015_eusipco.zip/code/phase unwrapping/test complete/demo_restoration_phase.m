clc; clear all; close all;

% Parameters
Fs = 11025; Nw = 512; Nfft = 512; hop = Nw/4;
source_type = 'PIANO_RAND';
nPHI = 200;

% Score initialization
Ndata = 10;
Np = 10;
SDR_CO = zeros(Ndata,Np); SDR_PR = zeros(Ndata,Np); SDR_GL = zeros(Ndata,Np);


for num_piece=1:Ndata
% Source generation
gen_sources_time; gen_sources_TF;
clc;
fprintf('source %d / %d \n',num_piece,Ndata);
for p = 1:Np
    fprintf('iteration %d / %d \n',p,Np);
    % Corrupt STFT phase
    perc = p*10;
    delta = floor(rand(F,T) + perc/100);
    Xc = X; r = rand(F,T);
    Xc(delta>0) = abs(X(delta>0)) .* exp(1i * r(delta>0));
    xc = iSTFT(Xc,Nfft,w,hop);

    % Phase recovery
    [phi,t0,n0] = phase_unwrapping(Xc,Fs,w,hop,delta,1);
    Xe = abs(X).* exp(1i*phi);
    xe = iSTFT(Xe,Nfft,w,hop);

    % Griffin Lim
    xGL = griffin_lim(Xc,w,hop,nPHI);

    % Score
    SDR_CO(num_piece,p) = bss_eval_sources(x',xc');
    SDR_PR(num_piece,p) = bss_eval_sources(x',xe');
    SDR_GL(num_piece,p) = bss_eval_sources(x',xGL);

end

end

% Plot results
pp = (1:Np)*10;
plot(pp,mean(SDR_PR,1),'r*-',pp,mean(SDR_GL,1),'g+-',pp,mean(SDR_CO,1),'bo-')
pointer = xlabel('Percentage of corrupted bins');
set(pointer,'FontSize',16);
pointer = ylabel('SDR (dB)');
set(pointer,'FontSize',16);
pointer = legend('Phase unwrapping','GriffinLim','Corrupted');
set(pointer,'FontSize',16);


% %  Record
 audiowrite(strcat('phase unwrapping/sounds/phase inpainting/',source_type,'_orig.wav'),0.999*scaling(x),Fs);
 audiowrite(strcat('phase unwrapping/sounds/phase inpainting/',source_type,'_corr.wav'),0.999*scaling(xc),Fs);
 audiowrite(strcat('phase unwrapping/sounds/phase inpainting/',source_type,'_reco.wav'),0.999*scaling(xe),Fs);
 audiowrite(strcat('phase unwrapping/sounds/phase inpainting/',source_type,'_GL.wav'),0.999*scaling(xGL),Fs);
