clc; clear all; close all;

% Parameters
Fs = 11025; Nfft = 512; Nw = 512; hop = Nw/4;
nPHI = 100; NGL = 1;

source_type = 'IMPULSE';  
gen_sources_time; gen_sources_TF;
delta = ones(F,T);

% Phase reconstruction
tic;
[phi,t0,n0] = phase_unwrapping(X,Fs,w,hop,delta,1);
Xe = abs(X).* exp(1i*phi); xe = iSTFT(Xe,Nfft,w,hop);
tPU = toc;
%SDR_PR = bss_eval_sources(x',xe');

% Griffin Lim
phi0 = rand(F,T); X0 = abs(X) .* exp(1i * phi0);
SDR_GL = 0;
tic;
for nn=1:NGL
    [xGL,err] = griffin_lim(X0,w,hop,nPHI);
    %SDR_GL = SDR_GL + bss_eval_sources(x',xGL)/NGL;
end
tGL = toc/NGL;


% Plot
fplot = 27; tplot = t0(1);
subplot(1,3,1);
imagesc(ts,freq,20*log10(abs(X))); axis xy;
p = xlabel('Time (s)'); set(p,'FontSize',16);
p= ylabel('Frequency (Hz)'); set(p,'FontSize',16);
subplot(1,3,2);
plot([ts' ts'],[angle(X(fplot,:))' angle(Xe(fplot,:))']);
p = xlabel('Time (s)'); set(p,'FontSize',16);
subplot(1,3,3);
plot([ [0 freq]' [0 freq]'],[angle(X(:,tplot)) angle(Xe(:,tplot))]);
p = xlabel('Frequency (Hz)'); set(p,'FontSize',16);
p = legend('Original','Reconstructed'); set(p,'FontSize',16);

