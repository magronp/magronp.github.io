clc; clear all; close all;

% Parameters
Fs = 11025; Nfft = 512; Nw = 512; hop = Nw/4;
rec = 0;
nPHI = 200; NGL = 30;

source_type = 'DRUM'; TF_type = 'STFT';

% Get original percussive data
for num_piece = 1:3
    gen_sources_time; gen_sources_TF;
    xx(num_piece,:) = x(:)';
    XX(:,:,num_piece) = X;
end
delta = ones(F,T);

% Plot drum spectrograms
subplot(1,3,1); imagesc(ts,freq,20*log10(abs(XX(:,:,1)))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16); p=ylabel('Frequency (Hz)'); set(p,'FontSize',16);
subplot(1,3,2); imagesc(ts,freq,20*log10(abs(XX(:,:,2)))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16);
subplot(1,3,3); imagesc(ts,freq,20*log10(abs(XX(:,:,3)))); axis xy; p=xlabel('Time (s)'); set(p,'FontSize',16);

% Methods for onset reconstruction to be compared
Nmeth = 6;
SDR = zeros(3,Nmeth+1);
xe = zeros(3,Nmeth,length(x));

% Phase reco comparison
for num=1:3
    fprintf(' ----- Data : %d / %d \n',num,3);
    X = XX(:,:,num);
    x = squeeze(xx(num,:))';

    % Phase unwrapping
    for meth=0:(Nmeth-1)
        fprintf('Phase unwrapping method : %d / %d \n',meth,Nmeth);
        
        phi = phase_unwrapping(X,Fs,w,hop,delta,meth);
        Xe = abs(X).* exp(1i*phi);
        xe(meth+1,num,:) = iSTFT(Xe,Nfft,w,hop);
        SDR(num,meth+1) = bss_eval_sources(x',squeeze(xe(meth+1,num,:))');
        
        %Record
        if rec
            audiowrite(strcat('phase unwrapping/sounds/percussive/',source_type,'_',int2str(num),'_',int2str(meth),'_reco.wav'),0.999*scaling(squeeze(xe(meth+1,num,:))),Fs);
        end
    end
    
    % Griffin Lim
    fprintf('Griffin Lim \n');
    for nGL = 1:NGL
        phi0 = rand(F,T);
        X0 = abs(X) .* exp(1i * phi0);
        xGL = griffin_lim(X0,w,hop,nPHI);
        SDR(num,end) = SDR(num,end) + bss_eval_sources(x',xGL)/NGL;
    end
    if rec
        audiowrite(strcat('phase unwrapping/sounds/percussive/',source_type,'_',int2str(num),'_orig.wav'),0.999*scaling(x),Fs);
        audiowrite(strcat('phase unwrapping/sounds/percussive/',source_type,'_',int2str(num),'_GL.wav'),0.999*scaling(xGL),Fs);
    end

    
end