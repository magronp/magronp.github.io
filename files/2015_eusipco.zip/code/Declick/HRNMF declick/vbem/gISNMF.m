function [sigma2,w,h,L,time] = gISNMF(x,delta,sigma2,w,h,MaxIt,update_w)
% Generalized IS-NMF (i.e. HR-NMF with P = 0)

% Initialization
T = size(x,1);
F = size(x,2);
K = size(w,1);
if nargin < 7, update_w = true; end;

% Multiplicative update rules
V = abs(x.').^2.*delta.';
sigma2ft = w' * h + sigma2;
logp = delta.'.*log(sigma2ft)+V./sigma2ft;
logp(isnan(logp)) = 0;
L = - sum(sum(logp));
time = zeros(1,MaxIt+1);
tic;
for iteration = 1:MaxIt,           
    sigma2 = sigma2 .* sum(sum(V./sigma2ft.^2)) ./ sum(sum(delta.'./sigma2ft));
    sigma2(isnan(sigma2)) = 0;
    h = h .* (w*(V./sigma2ft.^2)) ./ (w*(delta.'./sigma2ft));
    h(isnan(h)) = 0;
    sigma2ft = w' * h + sigma2;    
    if update_w,
        sigma2 = sigma2 .* sum(sum(V./sigma2ft.^2)) ./ sum(sum(delta.'./sigma2ft));
        sigma2(isnan(sigma2)) = 0;        
        w = w .* (h*(V./sigma2ft.^2)') ./ (h*(delta.'./sigma2ft)');
        w(isnan(w)) = 0;
        sigma2ft = w' * h + sigma2;
    end;
    logp = delta.'.*log(sigma2ft)+V./sigma2ft;
    logp(isnan(logp)) = 0;
    L(iteration+1) = - sum(sum(logp));
    % Normalization of the NMF
    if update_w,
        for k=1:K,
            tmp = max(h(k,:));
            w(k,:) = w(k,:) * tmp;
            h(k,:) = h(k,:) / tmp;
        end;
    end;
    time(iteration+1) = toc;
end;
