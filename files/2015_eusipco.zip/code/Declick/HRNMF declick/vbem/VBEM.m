function [eys,a,b,sigma2x,sigma2y,z,gz,VFE] = VBEM(y,delta,mz,qz,a,b,sigma2x,sigma2y,IterEstep,IterMstep,update_filters,evalVFE)
% Variational Bayesian EM algorithm for estimating the HR-NMF model

%% Initializations
F = size(y,1);
T = size(y,2);
M = size(y,3);
S = size(mz,3);
Pa = (size(a,2)-1)/2;
Pb = (size(b,2)-1)/2;
Pz = max(Pa,Pb);
Qa = size(a,3);
Qb = size(b,3)-1;
Qz = max(Qa,Qb);
D = sum(delta(:));
gz = ones(F,Qz+T,S);
z = zeros(F,Qz+T,S);

% Initialize (g)ey(f,t,m) for f=0...F-1, t = 0...T-1, m = 0...M-1
geys = zeros(F,T,M,S);
eys = zeros(F,T,M,S);
t = 0:T-1;
for s = 0:S-1,
    for phi = -Pb:Pb,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 0:Qb,          
            for m = 0:M-1,
                tmpb = b(1+f,1+Pb+phi,1+tau,1+m,1+s);
                geys(1+f,1+t,1+m,1+s) = geys(1+f,1+t,1+m,1+s) + (abs(tmpb).^2*ones(1,length(t)))  .* gz(1+f-phi,Qz+1+t-tau,1+s);
                eys(1+f,1+t,1+m,1+s) = eys(1+f,1+t,1+m,1+s) + (tmpb*ones(1,length(t)))  .*z(1+f-phi,Qz+1+t-tau,1+s);
            end;
        end;
    end;
end;

%%%%%%% ajout initialisation
% [~,~,~,~,~,~,c,~,~,~] = initialization(squeeze(y(:,:,1)).',squeeze(delta(:,:,1))',S,Qa*ones(S,1),30,'IS');
% eys(:,:,1,1) = squeeze(c(1,:,:)).';
% eys(:,:,1,2) = squeeze(c(2,:,:)).';
%%%%%%%

gey = delta .* sum(geys,4);
ey = delta .* (y - sum(eys,4));

% Initialize (g)ex(f,t,s) for f=0...F-1, t = 0...T-1, and s
gex = zeros(F,T,S);
ex = zeros(F,T,S);
for s = 0:S-1,
    gex(:,:,1+s) = gz(1:F,Qz+1:end,1+s); 
    ex(:,:,1+s) = z(1:F,Qz+1:end,1+s);   
    for phi = -Pa:Pa,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 1:Qa,
            tmpa = a(1+f,Pa+1+phi,tau,1+s);
            gex(1+f,1+t,1+s) = gex(1+f,1+t,1+s) + (abs(tmpa).^2*ones(1,length(t))) .*gz(1+f-phi,Qz+1+t-tau,1+s);
            ex(1+f,1+t,1+s) = ex(1+f,1+t,1+s) + (tmpa*ones(1,length(t))) .*z(1+f-phi,Qz+1+t-tau,1+s);
        end;
    end;
end;

if evalVFE,
    % Evaluation of the variational free energy
    VFE = VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D);
else
    VFE = [];
end;

%% Iterate
for iter=1:IterEstep+IterMstep,

%% E-step
for s = 0:S-1,
    % Update of gz(f,t,s) for f=0...2F-1, t = -Qz...T-1, and s
    tmpgz = zeros(F,Qz+T);
    tmpgz(:,1:Qz) = qz(:,:,1+s);
    for phi = -Pb:Pb,
        f = max(0,-phi):F-1+min(0,-phi);
        for tau = 0:Qb,
            t = -tau:T-1-tau;
            for m = 0:M-1,
                tmp2 = (abs(b(:,1+Pb+phi,1+tau,1+m,1+s)).^2*ones(1,T)) .* delta(:,:,1+m);
                tmpgz(1+f,Qz+1+t) = tmpgz(1+f,Qz+1+t) + tmp2(1+f+phi,1+t+tau) / sigma2y;                
            end;
        end;
    end;
    tmpgz(:,Qz+1:end) = tmpgz(:,Qz+1:end) + ones(F,1)*(1./sigma2x(:,1+s).');
    for phi = -Pa:Pa,
        f = max(0,-phi):F-1+min(0,-phi);
        for tau = 1:Qa,
            t = -tau:T-1-tau;
            tmp2 = abs(a(:,Pa+1+phi,tau,1+s)).^2*ones(1,T);
            tmpgz(1+f,Qz+1+t) = tmpgz(1+f,Qz+1+t) + tmp2(1+f+phi,1+t+tau) .*(ones(length(f),1) * (1./sigma2x(1+t+tau,1+s).'));
        end;
    end;
    gz(:,:,1+s) = 1 ./ tmpgz;
      
    % Update gex(f,t,s) for f=0...F-1, t = 0...T-1, and s
    gex(:,:,1+s) = gz(1:F,Qz+1:end,1+s); 
    t = 0:T-1;
    for phi = -Pa:Pa,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 1:Qa,
            gex(1+f,1+t,1+s) = gex(1+f,1+t,1+s) + (abs(a(1+f,Pa+1+phi,tau,1+s)).^2*ones(1,length(t))) .*gz(1+f-phi,Qz+1+t-tau,1+s);
        end;
    end;
    % Update gey(f,t,m) for f=0...F-1, t = 0...T-1, m = 0...M-1
    geys(:,:,:,1+s) = zeros(F,T,M);
    for phi = -Pb:Pb,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 0:Qb,
            for m = 0:M-1,
                geys(1+f,1+t,1+m,1+s) = geys(1+f,1+t,1+m,1+s) + (abs(b(1+f,1+Pb+phi,1+tau,1+m,1+s)).^2*ones(1,length(t)))  .* gz(1+f-phi,Qz+1+t-tau,1+s);
            end;
        end;
    end;
    gey = delta .* sum(geys,4);   
    if evalVFE,
        % Evaluation of the variational free energy
        VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
        disp('End of gz'); length(VFE)
    end;

    % Update of z(f,t,s) for f=0...2F-1, t = -Qz...T-1, and s
    f_shift = 1 + 2*Pz;
    t_shift = 1 + Qz;
    for f_init = 0:f_shift-1,
        for t_init = 0:t_shift-1,    
            tmpz = zeros(F,Qz+T);
            tmpz(:,1:Qz) = qz(:,:,1+s) .* (z(1:F,1:Qz,1+s)-mz(:,:,1+s));
            for phi = -Pb:Pb,
                f = max(0,-phi):F-1+min(0,-phi);
                for tau = 0:Qb,
                    t = -tau:T-1-tau;
                    for m = 0:M-1,
                        tmp2 = (conj(b(:,1+Pb+phi,1+tau,1+m,1+s))*ones(1,T)) .* ey(:,:,1+m);             
                        tmpz(1+f,Qz+1+t) = tmpz(1+f,Qz+1+t) - tmp2(1+f+phi,1+t+tau) / sigma2y;
                    end;
                end;
            end;
            tmpz(:,Qz+1:end) = tmpz(:,Qz+1:end) + ex(:,:,1+s) .* (ones(F,1) * (1./sigma2x(:,1+s).'));
            for phi = -Pa:Pa,
                f = max(0,-phi):F-1+min(0,-phi);
                for tau = 1:Qa,
                    t = -tau:T-1-tau;
                    tmp2 = (conj(a(:,Pa+1+phi,tau,1+s))*ones(1,T)) .* ex(:,:,1+s);
                    tmpz(1+f,Qz+1+t) = tmpz(1+f,Qz+1+t) + tmp2(1+f+phi,1+t+tau) .* (ones(length(f),1) * (1./sigma2x(1+t+tau,1+s).'));
                end;
            end;
            z(1+f_init:f_shift:F,1+t_init:t_shift:end,1+s) = z(1+f_init:f_shift:F,1+t_init:t_shift:end,1+s) ...
                - tmpz(1+f_init:f_shift:F,1+t_init:t_shift:end) ./ tmpgz(1+f_init:f_shift:F,1+t_init:t_shift:end);

            % Update ex(f,t,s) for f=0...F-1, t = 0...T-1, and s
            ex(:,:,1+s) = z(1:F,Qz+1:end,1+s);
            t = 0:T-1;
            for phi = -Pa:Pa,
                f = max(0,phi):F-1+min(0,phi);
                for tau = 1:Qa,
                    ex(1+f,1+t,1+s) = ex(1+f,1+t,1+s) + (a(1+f,Pa+1+phi,tau,1+s)*ones(1,length(t))) .*z(1+f-phi,Qz+1+t-tau,1+s);
                end;
            end;   
            % Update ey(f,t,m) for f=0...F-1, t = 0...T-1, m = 0...M-1
            eys(:,:,:,1+s) = zeros(F,T,M);
            for phi = -Pb:Pb,
                f = max(0,phi):F-1+min(0,phi);
                for tau = 0:Qb,
                    for m = 0:M-1,
                        eys(1+f,1+t,1+m,1+s) = eys(1+f,1+t,1+m,1+s) + (b(1+f,1+Pb+phi,1+tau,1+m,1+s)*ones(1,length(t)))  .*z(1+f-phi,Qz+1+t-tau,1+s);
                    end;
                end;
            end;
            ey = delta .* (y - sum(eys,4));
            if evalVFE,
                % Evaluation of the variational free energy
                VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
                disp('End of z'); length(VFE)
            end;
        end;
    end;
end;

%% M-step

if iter>IterEstep,

% Update of sigma2y
sigma2y = sum(gey(:)+abs(ey(:)).^2) / D;

if evalVFE,
    % Evaluation of the variational free energy
    VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
    disp('End of sigma2y'); length(VFE)
end;    
    
% Update of sigma2x
for s = 0:S-1,
    sigma2x(:,1+s) = sum(gex(:,:,1+s)+abs(ex(:,:,1+s)).^2,1).' / F;
end;

if evalVFE,
    % Evaluation of the variational free energy
    VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
    disp('End of sigma2x'); length(VFE)
end;    

if update_filters,

% Update of a(f,phi,tau,s)
t = 0:T-1; 
for s = 0:S-1,
    for phi = -Pa:Pa,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 1:Qa,
            tmpa = a(1+f,Pa+1+phi,tau,1+s);
            tmpz = z(1+f-phi,Qz+1+t-tau,1+s);
            tmpgz = gz(1+f-phi,Qz+1+t-tau,1+s);
            gex(1+f,1+t,1+s) = gex(1+f,1+t,1+s) - (abs(tmpa).^2*ones(1,length(t))) .* tmpgz;
            ex(1+f,1+t,1+s) = ex(1+f,1+t,1+s) - (tmpa*ones(1,length(t))) .* tmpz;
            tmpa = - sum(conj(tmpz).*ex(1+f,1+t,1+s).*(ones(length(f),1)*(1./sigma2x(:,1+s).')),2) ./ sum((tmpgz+abs(tmpz).^2).*(ones(length(f),1)*(1./sigma2x(:,1+s).')),2);
            gex(1+f,1+t,1+s) = gex(1+f,1+t,1+s) + (abs(tmpa).^2*ones(1,length(t))) .* tmpgz;
            ex(1+f,1+t,1+s) = ex(1+f,1+t,1+s) + (tmpa*ones(1,length(t))) .* tmpz;
            a(1+f,Pa+1+phi,tau,1+s) = tmpa;
            if evalVFE,
                % Evaluation of the variational free energy
                VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
            end;
        end;
    end;
end;

if evalVFE,
    disp('End of a:'); length(VFE)
end;

    
% Update of b(f,phi,tau,m,s)
for s = 0:S-1,
    for phi = -Pb:Pb,
        f = max(0,phi):F-1+min(0,phi);
        for tau = 0:Qb,
            for m = 0:M-1,
                tmpb = b(1+f,1+Pb+phi,1+tau,1+m,1+s);
                tmpz = z(1+f-phi,Qz+1+t-tau,1+s);
                tmpgz = gz(1+f-phi,Qz+1+t-tau,1+s);
                geys(1+f,1+t,1+m,1+s) = geys(1+f,1+t,1+m,1+s) - (abs(tmpb).^2*ones(1,length(t)))  .* tmpgz;
                eys(1+f,1+t,1+m,1+s) = eys(1+f,1+t,1+m,1+s) - (tmpb*ones(1,length(t)))  .* tmpz;
                tmp = delta(1+f,1+t,1+m) .* (y(1+f,1+t,1+m) - sum(eys(1+f,1+t,1+m,:),4));
                tmpb = sum(conj(tmpz).*tmp,2) ./ sum(delta(1+f,1+t,1+m) .* (tmpgz+abs(tmpz).^2),2);
                geys(1+f,1+t,1+m,1+s) = geys(1+f,1+t,1+m,1+s) + (abs(tmpb).^2*ones(1,length(t)))  .* tmpgz;
                eys(1+f,1+t,1+m,1+s) = eys(1+f,1+t,1+m,1+s) + (tmpb*ones(1,length(t))) .* tmpz;
                b(1+f,1+Pb+phi,1+tau,1+m,1+s) = tmpb;
                gey = delta .* sum(geys,4);
                ey = delta .* (y - sum(eys,4));
                if evalVFE,
                    % Evaluation of the variational free energy
                    VFE = [VFE,VFEeval(gz,z,mz,qz,gey,ey,gex,ex,sigma2y,sigma2x,D)];
                end;
            end;
        end;
    end;
end;

end;

if evalVFE,
    disp('End of b:'); length(VFE)
end;

end; % if

%% End iterate
end;

