function [p,h,f]=cosmod(N,M)
% function [p,h,f] = cosmod(N,M)
% cosine-modulated pour N=2KM, ou 2KM+1
% p = filtre prototype
% h = filtres d'analyse
% f = filtres de synthese
% M = Nombre de bandes
% N = longueur des filtres

lfft = 4096;
fg=0:1/lfft:1/2;
ws=0.85*pi/M+pi/1000;       % ws = pi/(2*M) + epsilon
alpha =100;                 % alpha = Epb + alpha * Ebs
taille_grid=200;            % taille_grid = nombre de points pour l'optimisation
if (rem(N,2)==0),
	[p, h, f] = lotp(M,N,ws,alpha,taille_grid);
else
	[p, h, f] = loti(M,N,ws,alpha,taille_grid);
end

clf;
hold on;
for l=1:M,
	G=fft(h(:,l),lfft);
	plot(fg,20*log10(abs(G(1:lfft/2+1))));
end;
hold off
figure(2);
H=zeros(lfft,1);
for l=1:M,
	G=fft(h(:,l),lfft);
	H=H+abs(G).*abs(G);
end
plot(fg,sqrt(H(1:lfft/2+1)));

h = [sqrt(M)*h',zeros(M,1)];
f = [zeros(M,1),sqrt(M)*f'];
p = sqrt(M)*p;