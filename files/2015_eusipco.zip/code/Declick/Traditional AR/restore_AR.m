% Restauration of a dammaged signal part with AR model (inpainting) and
% least square method. [Fillon, Charbit]
% Code by Paul Magron, May 2014
%
% Inputs :
%     x : signal
%     a = [1 a1 a2 ... aP] : AR parameters
%     m = length of the zone to be restaured
%     l = begining index of the zone to be restaured
%
% Output :
%     x_rest : restaured signal

function [x_rest] = restore_AR(x,a,m,l)

P = length(a)-1;

% Taking P samples before and after the restauration zone
x0=x(l-P:l-1);
x1=x(l+m:l+m+P-1);

a=fliplr(a');
z=zeros(1,m+P-1);
r=[a z];
c=[a(1);z'];
A=toeplitz(c,r);

A0=A(:,1:P);
B=A(:,(P+1):P+m);
A1=A(:,(P+m+1):(2*P+m));

% Least-square estimation of the missing data
y=-inv(B'*B)*B'*(A0*x0+A1*x1);
 
x_rest=x;
x_rest(l:l+m-1)=y;

end