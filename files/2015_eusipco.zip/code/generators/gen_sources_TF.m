% Generation of the STFT of the data 

clear sm_aux Sm Sm_double X Xdouble;

w = perfect_reco_window(Nw,hop);

X = STFT(x,Nfft,w,hop);
[F,T] = size(X);
x = iSTFT(X,Nfft,w,hop);

Sm = zeros(F,T,K);
sm_aux = zeros(K,length(x));

parfor k=1:K
    Sm(:,:,k) = STFT(sm(k,:),Nfft,w,hop);
    sm_aux(k,:) = iSTFT(Sm(:,:,k),Nfft,w,hop);
end
sm = sm_aux;

t = size(sm,2);
ts = (0:T-1)*hop / Fs;
freq = (1:Nw/2)*Fs/Nw;