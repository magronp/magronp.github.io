% ----    Time domain signal generator  -----
%       Paul Magron
% 
% 'SYNTH'               one synthetic mixture of sinusoids
% 'SYNTH_NO_OL'         2 mixtures of sinusoids with no overlapp in the TF domain
% 'SYNTH_OL'            2 mixtures of sinusoids with overlapp (beating) in the TF domain
% 'CHIRP'               linear chirp
% 'VIBRATO'             synthetic mixture with vibrato
% 'IMPULSE'             mixture of 2 impulses
% 'HEAVISIDE'           heaviside signal
%
% 'PIANO_ONE'           one single piano note (midi pitch=60)
% 'PIANO_ONE_RAND'      one single piano note (random)
% 'PIANO_TWO'           two occurences of the same (random) note
% 'PIANO_RAND'          two random piano notes
% 'PIANO_H'             two random piano notes in harmonic (5th) relation
% 'PIANO_NO_OL'         piano notes mixtures from MAPS database without TF overlap
% 'PIANO_E-B'           an E and B piano notes
% 'PIANO_RAND_THREE'    three random piano notes
% 'PIANO_H_THREE'       three random piano notes in harmonic (3rd and 5th) relation
% 'PIANO_NUANCE'        two occurences of a note with different nuances
%
% 'GUITAR_ONE'          one single guitar note (midi pitch=60)
% 'GUITAR_ONE_RAND'     one single guitar note (random)
% 'GUITAR_TWO'          two occurences of the same (random) note
% 'GUITAR_NUANCE'       two occurences of a note with different nuances
%
% 'PIANO_GUITAR'        one piano and one guitar note (same midi pitch)
%
% 'PIANO_PIECE'         a piano piece
% 'GUITAR_PIECE'        a guitar lick
% 'STRING_PIECE'        a string quarter piece
% 'SPEECH_PIECE'        a speech excerpt
%
% 'SOGROOVE'            a polyphonic MIDI song
%
% 'DRUM'                one occurence of a percussive signal
% 'DRUM_TWO'            two occurences of a percussive signal
%
% 'otherwise'           enter the name of the song



sources_path = '../Sounds/';
clear s sm  x name;
switch source_type
    
    % ---------------- SYNTHETIC MIXTURES ---------------------
    case 'SYNTH'
        K = 1;
        n=0:1/Fs:1;
        f0 = [600 1200 2400 3700]';
        damp = 1*[1 3 2 0.1]';
        s = sum(exp(-damp*n).*sin(2*pi*f0*n)); s=s(:); s=s';
        
    case 'SYNTH_ONE'
        K = 1;
        L = Fs;
        Nh = 3;
        f10 = 500+1000*rand(1,1);
        f1_Hz = f10 * (1:Nh); f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,Nh); damp1 = -rand(1,1)/10000*ones(1,Nh); phi1 = 2*pi*rand(1,Nh);
        
        s(1,:) = real(Synthesis(L,damp1,f1,a1,phi1,60))';
        s = [zeros(1,1000) s zeros(1,1000)];
        
     case 'SYNTH_TWO'
        K = 1;
        L = Fs;
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        s(1,:) = [zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))' zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))' zeros(1,2000)];
        %s(2,:) = zeros(1,2000+L);
        
    case 'SYNTH_NO_OL',
        K = 2;
        L = Fs;
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        f2_Hz = f1_Hz+250; f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,3); damp2 = -rand(1,1)/10000*[1 1 1]; phi2 = randn(1,3);        
        
         s(1,:) = [zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))'];
         s(2,:) = [zeros(1,2000) real(Synthesis(L,damp2,f2,a2,phi2,60))'];

    case 'SYNTH_OL',
        K = 2; 
        L = Fs;
        Nharmo = 3;
        f10 = 600+100*rand(1,1);
        f1_Hz = f10*(1:Nharmo); f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,Nharmo);  damp1 = -rand(1,1)/10000*ones(1,Nharmo); phi1 = randn(1,Nharmo);
        
        f2_Hz = (2*f10+10)*(1:Nharmo); f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,Nharmo); damp2 = -rand(1,1)/10000*ones(1,Nharmo); phi2 = randn(1,Nharmo);
        
        s(1,:) = [ zeros(1,2000) real(Synthesis(L,damp1,f1,a1,phi1,60))'];
        s(2,:) = [ zeros(1,2000) real(Synthesis(L,damp2,f2,a2,phi2,60))'];
        
    case 'CHIRP',
        K = 1;
        n=0:1/Fs:1;
        fHz = 1500;
        s = sin(2*pi*(fHz+500*n).*n);
        
    case 'VIBRATO',
        K = 2;
        n=0:1/Fs:1;
        fHz = 1500;
        s(1,:) = exp(-1.5*n).*sin(2*pi*fHz*n);
        s(2,:) = sin(2*pi*(fHz+100)*n+20*sin(2*pi*3*n));
        
    case 'IMPULSE'
        K = 1;
        s = [zeros(1,999) 3 zeros(1,1000) 2 zeros(1,1000) ];
        
    case 'HEAVISIDE'
        K = 1;
        s = [zeros(1,5000) ones(1,5000) ];
        
        
    % ---------------- PIANO NOTES ---------------------

    case 'PIANO_ONE',
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(60),'_F.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'PIANO_ONE_RAND',
        K = 1;
        midi_pitch = randi(88,1,1)+20;
        [s,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch),'_F.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'PIANO_TWO',
        K = 1;
        midi_pitch = randi(88,1,1)+20;
        [s,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch),'_F.wav')); s=s'; s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s  zeros(1,1000) s ];
        
    case 'PIANO_RAND',
        K = 2;
        midi_pitch = randi(88,1,K)+20;
        while ismultiple(midi_pitch)
            midi_pitch = randi(88,1,K)+20;
        end;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(1)),'_F.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(2)),'_F.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old); s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
   case 'PIANO_H',
        K = 2;
        midi_pitch = zeros(1,K); midi_pitch(1) = randi(81,1,1)+20; midi_pitch(2) = midi_pitch(1)+7;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(1)),'_M.wav')); s1=s1'; s1 = s1 .* exp(-0.0001 * (1:length(s1)));
        s2 = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(2)),'_M.wav')); s2=s2'; s2 = s2 .* exp(-0.0001 * (1:length(s1)));
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
 
    case 'PIANO_E-B',
        K = 2;
        midi_pitch = zeros(1,K); midi_pitch(1) = 40; midi_pitch(2) = midi_pitch(1)+7;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(1)),'_M.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(2)),'_M.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
    case 'PIANO_C-G',
        K = 2;
        midi_pitch = zeros(1,K); midi_pitch(1) = 60; midi_pitch(2) = midi_pitch(1)+7;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(1)),'_M.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(2)),'_M.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
    case 'PIANO_RAND_THREE',
        K = 3;
        midi_pitch = randi(88,1,K)+20;
        while ismultiple(midi_pitch)
            midi_pitch = randi(88,1,K)+20;
        end;
        for k=1:K
            [saux,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch(k)),'_F.wav')); saux=saux';
            s(k,:) = resample(saux,Fs,Fs_old);
        end
        s = s(:,1:floor(size(s,2)/2));
        
    case 'PIANO_H_THREE',
        K = 3;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(60),'_F.wav')); s1=s1';
        s2 = audioread(strcat('../Sounds/piano/notes/piano',int2str(64),'_F.wav')); s2=s2';
        s3 = audioread(strcat('../Sounds/piano/notes/piano',int2str(67),'_F.wav')); s3=s3';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s(3,:) = resample(s3,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
    case 'PIANO_NUANCE',
        K = 1;
        midi_pitch = randi(88,1,1)+20;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch),'_M.wav')); s1=s1'; s1 = resample(s1,Fs,Fs_old);
        [s2,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch),'_F.wav')); s2=s2'; s2 = resample(s2,Fs,Fs_old);
        s = [zeros(1,1000) s1  zeros(1,1000) s2 ];
 
        
% ---------------- GUITAR ---------------------
        
    case 'GUITAR_ONE',
        K = 1;
        midi_pitch = 60;
        [s,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_1.wav')); s=s'; s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'GUITAR_ONE_RAND',
        K = 1;
        midi_pitch =  randi(37,1,1)+39;
        [s,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_1.wav')); s=s'; s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'GUITAR_TWO',
        K = 1;
        midi_pitch = randi(37,1,1)+39;
        [s1,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_1.wav')); s1=s1'; s1 = resample(s1,Fs,Fs_old);
        s = [zeros(1,1000) s1  zeros(1,1000) s1 ];
        
    case 'GUITAR_NUANCE',
        K = 1;
        midi_pitch = randi(27,1,1)+44;
        [s1,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_1.wav')); s1=s1'; s1 = resample(s1,Fs,Fs_old);
        [s2,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_2.wav')); s2=s2'; s2 = resample(s2,Fs,Fs_old);
        s = [zeros(1,1000) s1  zeros(1,1000) s2 ];
        
    case 'GUITAR_H',
        K = 2;
        midi_pitch = zeros(1,K); midi_pitch(1) = randi(30,1,1)+39; midi_pitch(2) = midi_pitch(1)+7;
        [s1,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch(1)),'_1.wav')); s1=s1';
        [s2,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch(2)),'_1.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(size(s,2)/2));
        
% ------------- PIANO AND GUITAR -----------------

    case 'PIANO_GUITAR',
        K = 1;
        midi_pitch = randi(37,1,1)+39;
        [s1,Fs_old] = audioread(strcat('../Sounds/piano/notes/piano',int2str(midi_pitch),'_F.wav')); s1=s1'; s1 = resample(s1,Fs,Fs_old);
        [s2,Fs_old] = audioread(strcat('../Sounds/guitar/notes/guitar',int2str(midi_pitch),'_1.wav')); s2=s2'; s2 = resample(s2,Fs,Fs_old);
        s = [zeros(1,1000) s1  zeros(1,1000) s2 ];
        
        
    % ---------------- PIECES ---------------------
    
    case 'PIANO_PIECE',
        K = 1;
        fid = fopen('../Sounds/piano/pieces/list_pieces.txt'); T = textscan(fid, '%s', 'Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(30,1,1);
        end
        name = T{1}; name = name(num_piece);
        L = char(strcat('../Sounds/piano/pieces/MAPS_MUS-',name,'_StbgTGd2.wav'));
        [s,Fs_old] = audioread(L,Fs*[1 20]); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        fclose(fid);
        
     case 'GUITAR_PIECE',
        K = 1;
        if ~exist('num_piece','var')
            num_piece = randi(6,1,1);
        end
        L = char(strcat('../Sounds/guitar/pieces/lick',int2str(num_piece),'.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        
    case 'STRING_PIECE',
        K = 1;
        fid = fopen('../Sounds/strings/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(12,1,1);
        end
        name = T{1}; name = name(num_piece);
        L = char(strcat('../Sounds/strings/',name,'_mix.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        fclose(fid);
        
    case 'SPEECH_PIECE',
        K = 1;
        fid = fopen('../Sounds/speech/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(42,1,1);
        end
        name = T{1}; name = name(num_piece);
        L = char(strcat('../Sounds/speech/',name,'.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        fclose(fid);
        
    case 'MSD100',
        K = 1;
        fid = fopen('../Sounds/msd100/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(50,1,1);
        end
        name = T{1}; name = name(num_piece);
        L = char(strcat('../Sounds/msd100/',name,'/mixture.wav'));
        [s,Fs_old] = audioread(L); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        fclose(fid);

     case 'MSD100sources',
        K = 4;
        fid = fopen('../Sounds/msd100/list_pieces.txt');
        T = textscan(fid, '%s','Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(50,1,1);
        end
        name = T{1}; name = name(num_piece);
        L1 = char(strcat('../Sounds/msd100/',name,'/bass.wav')); [s1,Fs_old] = audioread(L1,Fs*[1 60]); s1=mean(s1,2); s(1,:) = resample(s1,Fs,Fs_old)';
        L2 = char(strcat('../Sounds/msd100/',name,'/drums.wav')); [s2,Fs_old] = audioread(L2,Fs*[1 60]); s2=mean(s2,2); s(2,:) = resample(s2,Fs,Fs_old)';
        L3 = char(strcat('../Sounds/msd100/',name,'/other.wav')); [s3,Fs_old] = audioread(L3,Fs*[1 60]); s3=mean(s3,2); s(3,:) = resample(s3,Fs,Fs_old)';
        L4 = char(strcat('../Sounds/msd100/',name,'/vocals.wav')); [s4,Fs_old] = audioread(L4,Fs*[1 60]); s4=mean(s4,2); s(4,:) = resample(s4,Fs,Fs_old)';
        fclose(fid);

    
    % ------------------- SO GROOVE ---------------------  
    case 'SOGROOVE',
        K = 10;
        [s_aux,Fs_old] = audioread(strcat('../Sounds/sogroove/midi',int2str(1),'.wav'));
        s_aux = resample(s_aux,Fs,Fs_old);
        s = zeros(K,length(s_aux));
        s(1,:) = s_aux;
        for k=2:K
            [s_aux,Fs_old] = audioread(strcat('../Sounds/sogroove/midi',int2str(k),'.wav'));
            s(k,:) = resample(s_aux,Fs,Fs_old);
        end
        
        
    case 'sunrise',
        K = 5;
        Ninst = 5;
        Fs_old = 44100;
        deb = 27.45; fin = 39;
        %s = zeros(Ninst,round(Fs*(fin-deb))+1);
        s1 = audioread('../Sounds/sunrise/acoustik_gtr.wav',[deb fin]*Fs_old); s1 = mean(s1,2); s(1,:) = resample(s1,Fs,Fs_old);
        s2 = audioread('../Sounds/sunrise/bass.wav',[deb fin]*Fs_old); s2 = mean(s2,2); s(2,:) = resample(s2,Fs,Fs_old);
        s3 = audioread('../Sounds/sunrise/drums.wav',[deb fin]*Fs_old); s3 = mean(s3,2); s(3,:) = resample(s3,Fs,Fs_old);
        s4 = audioread('../Sounds/sunrise/piano.wav',[deb fin]*Fs_old); s4 = mean(s4,2); s(4,:) = resample(s4,Fs,Fs_old);
        s5 = audioread('../Sounds/sunrise/lead_vocal.wav',[deb fin]*Fs_old); s5 = mean(s5,2); s(5,:) = resample(s5,Fs,Fs_old);

        
    % -------------------- DRUMS ----------------------  
     case 'DRUM',
        K = 1;
        if ~exist('num_piece','var')
            num_piece = randi(3,1,1);
        end
        [s,Fs_old] = audioread(strcat('../Sounds/drums/drum',int2str(num_piece),'.wav'));
        s = s(:);  s=s';
        s = resample(s,Fs,Fs_old);
        
     case 'DRUM_TWO',
        K = 1;
        if ~exist('num_piece','var')
            num_piece = randi(3,1,1);
        end
        [s,Fs_old] = audioread(strcat('../Sounds/drums/drum',int2str(num_piece),'.wav'));
        s = s(:); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,500) s zeros(1,300) s];
        
        
    % ------------ ohterwise load a song --------------     
    
    case 'songs',
        K = 1;
        fid = fopen('../Sounds/songs/list_pieces.txt'); T = textscan(fid, '%s', 'Delimiter','\n');
        if ~exist('num_piece','var')
            num_piece = randi(30,1,1);
        end
        name = T{1}; name = name(num_piece);
        L = char(strcat('../Sounds/songs/',name));
        [s,Fs_old] = audioread(L); s=mean(s,2); s = resample(s,Fs,Fs_old)';
        fclose(fid);
    
    
    otherwise
        K = 1;
        [s,Fs_old] = audioread(strcat('../Sounds/songs/',source_type,'.wav'));
        s = resample(s,Fs,Fs_old);
        s=s(:); s=s';
end


% Build the mixture from the isolated sources
l = floor(size(s,2)); zz =zeros(1,l);

if (K==1) || (strcmp(source_type,'SOGROOVE'))  || (strcmp(source_type,'sunrise')) || (strcmp(source_type,'MSD100sources'))
   sm = s;
   
elseif (K==2)
    sm(1,:) = [s(1,:) zz  s(1,:) ];
    sm(2,:) = [zz s(2,:)  s(2,:) ];
    
else
    sm(1,:) = [s(1,:) zz s(1,:)];
    sm(2,:) = [zz s(2,:) s(2,:)];
    sm(3,:) = [s(3,:) s(3,:) zz];
end

x = sum(sm,1);
