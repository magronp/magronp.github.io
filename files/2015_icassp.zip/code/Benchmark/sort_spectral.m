function [W,H] = sort_spectral(S,W,H)

K = size(S,3);
W_aux = W;
H_aux = H;

for j=1:(K-1)
    D = zeros(1,K);
    for k=j:K
        D(k) = distcorr(abs(S(:,:,j)),sqrt(W(:,k)*H(k,:)));
    end
    [~,ind] = max(D); 
    
    W_aux(:,j) = W(:,ind);
    W_aux(:,ind) = W(:,j);
    W = W_aux;
    
    H_aux(j,:) = H(ind,:);
    H_aux(ind,:) = H(j,:);
    H = H_aux;
end

end