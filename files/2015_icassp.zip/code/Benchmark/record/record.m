
% Blind estimated sources
for al=1:Nal
    for k=1:K
        audio_rec(squeeze(sb(al,k,:)),Fs,strcat(Sources(sc), '/Source_blind', int2str(k), '-', algos(al)))
    end
end

% Oracle estimated sources
for al=1:Nal
    for k=1:K
        audio_rec(squeeze(so(al,k,:)),Fs,strcat(Sources(sc), '/Source_oracle', int2str(k), '-', algos(al)))
    end
end

% Original mixed sources
for k=1:K
    audio_rec(sm(k,:),Fs,strcat(Sources(sc), '/Original_Source', int2str(k)))
end
audio_rec(x,Fs,strcat(Sources(sc),'/Original_Mix'))