function audio_rec(x,Fs,path)
path = strcat(path, '.wav');
wavwrite(0.9999 * scaling(x),Fs,path{1});
end