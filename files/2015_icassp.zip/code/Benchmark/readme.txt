%%%% Comparison of audio source separation algorithms %%%%

Paul Magron, Roland Badeau, Bertrand David 2015


Main scripts are :

 * run_benchmark : run the whole benchmark. There is the possibility of choosing algorithms, sources types, Time-Frequency representations that are to be compared

 * compare_init : compare HRNMF initializations (EM or VBEM algorithms, initialization can be Random, KL NMF or IS NMF)

 * compare_params : evaluate the influence of the number of parameters used in NMF and HRNMF on the BSS eval score


Useful scripts :

 * gen_sources_time_benchmark : generate the time sources s1...sk and the mixture x = sum(sk)
This script uses the sounds from the folder "Sounds", or the function Synthesis for synthetic datas (harmonics, vibratos, dirac...)

 * gen_sources_TF_benchmark : generate a time-frequency representation (STFT, CQT, MDCT...) representation of the sources and mixture. Functions for TF representations are in the folder "TF transforms"

 * ASS_blind (resp. ASS_oracle) perform Audio Source Separation in blind (resp. oracle) conditions. They call the algorithms from the "Algos" folder.

 * record is a function that record original and estimated separate sources in the folder named after source type (eg. MIDI or PIANO_RAND)

 * compute_score, disp_score_stat : computation and plot of BSS eval score, with the function in the folder "BSS EVAL" 




If you use this work, please quote:

Paul Magron, Roland Badeau, and Bertrand David. Phase reconstruction in NMF for audio source separation: An insightful benchmark. In IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), Brisbane, Australia, April 2015