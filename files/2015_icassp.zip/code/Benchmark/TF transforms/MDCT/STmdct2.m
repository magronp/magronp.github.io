% Short term Direct Modified Discrete Cosine Transform with 50% overlap
% Code by Paul Magron, october 2014.
%
% Inputs :
%     x : time signal
%     w : analysis window
%     Fs : sampling frequency
% 
% Outputs :
%     X : TF representation
%     ts : time
%     freq : frequencies

function [X,ts,freq] = STmdct2(x,w,Fs)

Nw = length(w);
w = w(:); w = [w' ; zeros(1,Nw)]; w = w(:);
Nw = length(w);


% Expecting x and w as rows
x = x(:); x = [x' ; zeros(1,length(x))]; x = x(:);

x = [ zeros(Nw/2,1) ; x ; zeros(Nw-mod(length(x),Nw),1); zeros(Nw/2,1)];

% frame length
T = 2*length(x)/Nw-1;

% init X
X = zeros(Nw/2,T);

for r=1:T
    ind = (Nw/2*(r-1)+1) : (Nw/2*(r-1)+Nw);
    X(:,r) = mdct4(w.*x(ind));
end

ts = (0:(T-1))*Nw/2/Fs;
freq = (1:Nw/2)*Fs/Nw;

end