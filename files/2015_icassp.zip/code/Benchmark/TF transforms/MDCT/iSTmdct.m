% Short term Inverse Modified Discrete Cosine Transform with 50% overlap
% Code by Paul Magron, october 2014.
%
% Inputs :
%     X : TF representation
%     w : analysis window
% 
% Outputs :
%     y : time signal

function [y] = iSTmdct(X,w)

w = w(:);
[F,T] = size(X);
Nw = F*2;

% init X
y = zeros(Nw/2*(T+1),1);

for r=1:T
    ind = (Nw/2*(r-1)+1) : (Nw/2*(r-1)+Nw);
    y(ind) = y(ind) + w.* imdct4(X(:,r));
end

y = y(Nw/2+1:end-Nw/2);

end