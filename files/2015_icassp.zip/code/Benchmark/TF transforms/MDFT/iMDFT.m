function x = iMDFT(X,w)

[F,T] = size(X);
Z1 = zeros(F/2,T);
Z2 = zeros(F/2,T);

for f=1:F/2
    Z2(f,:) = (X(2*f-1,:) + X(2*f,:))/2;
    Z1(f,:) = (X(2*f-1,:) - X(2*f,:))/(2*1i);
end

Zz = zeros(F/2,2*T);
Zz(:,1:2:end) = Z1;
Zz(:,2:2:end) = Z2;

% M points iMDCT
x = iSTmdct(Zz,w);

end
