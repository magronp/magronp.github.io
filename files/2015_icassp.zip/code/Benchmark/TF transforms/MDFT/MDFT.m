function X = MDFT(x, w, OL)

M = length(w);
% M points MDCT
hop = M*(1-OL);
Z = STmdct(x,w,hop);
[F,T] = size(Z);
Z = [Z zeros(F,mod(T,2))];
[F,T] = size(Z);
Z1 = Z(:,1:2:end);
Z2 = Z(:,2:2:end);

X = zeros(2*F,T/2);

% Split real and imaginary parts
for f=1:F
    X(2*f-1,:) = Z2(f,:) + 1i*Z1(f,:) ;
    X(2*f,:) = Z2(f,:) - 1i*Z1(f,:) ;
end

end
