%% Regular NMF
fprintf('Regular NMF\n');
tic;

% NMF
[wNMF,hNMF,err,~] = KL_nmf(abs(Xdouble),W_ini_double,H_ini,n_NMF);

Xnorm = Xdouble(1:2:end,:);
wNMFnorm = wNMF(1:2:end,:);

% Wiener filtering
[cb_NMF] = wiener(Xnorm,wNMFnorm,hNMF);
time_NMF = toc;

%% Complex NMF
if strcmp(TF_type,'STFT')
fprintf('Complex NMF\n');

tic;
phase_ini = zeros(F,T,K);
parfor k=1:K
    phase_ini(:,:,k) = angle(X);
end

[~,~,~,cb_CNMF] = complex_nmf(X,W_ini,H_ini,phase_ini,n_NMF);
time_CNMF = toc;

%% Consistent Complex NMF
fprintf('Consistent Complex NMF\n');
tic;
phase_ini = zeros(F,T,K);
parfor k=1:K
    phase_ini(:,:,k) = angle(X);
end

[~,~,~,cb_CNMF_LR] = complex_nmf_consistency(X,W_ini,H_ini,phase_ini,n_NMF,w,hop,1);
time_CNMF_LR = toc;
end
%% HR NMF
fprintf('HRNMF\n');

tic;
% NMF
[wNMF,hNMF,~,~] = KL_nmf(abs(X),W_ini,H_ini,n_NMF);

M = 1;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 0;
mz = zeros(F,Qz,K);
qz = 1e5*ones(F,Qz,K);
a = zeros(F,2*Pa+1,Qa,K);
b = ones(F,2*Pb+1,Qb+1,M,K);
b(:,1,1,1,:) = wNMF;
sigma2x = hNMF';
sigma2w = 1;
delta = ones(F,T,M);

[c,~,~,~,~,~,~,~] = VBEM(X,delta,mz,qz,a,b,sigma2x,sigma2w,n_HR,n_HR,true,false);

cb_HRNMF = zeros(F,T,K);
for k=1:K
    cb_HRNMF(:,:,k) = squeeze(c(:,:,1,k));
end
time_HRNMF = toc;
