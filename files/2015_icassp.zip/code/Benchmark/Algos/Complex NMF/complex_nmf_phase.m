
function [W,H,phi,C] = complex_nmf_phase(Y,W_ini,H_ini,phase_ini,f0,n_iter,w,hop,sigma0)
r=1;
K = size(W_ini,2);
Nw = length(w);
L = hop*Nw;                                  % frame shift

 p = 1.2;
 lambda = 2*(norm(Y)^2)/(K^(1-p/2))*10^-5;      % sparsity weight

W = W_ini;
H = H_ini;

[F,T] = size(Y);
C = zeros(F,T,K);
phi = zeros(F,T,K);

for k=1:K
    phi(:,:,k) = phase_ini(:,:,k);
    C(:,:,k) = W(:,k)*H(k,:) .* exp(1i*phi(:,:,k));
end

X = sum(C,3);
V = sum(abs(C),3);

for it=1:n_iter
    
    for k=1:K    
        %compute gain
        beta = W(:,k)*H(k,:) ./ V;
    
        %compute C_hat
        C_barr = C(:,:,k) + beta.*(Y-X);
        
        %compute H_barr
        H_barr = H(k,:);
        
        %compute phase
        phi_before = [phi(:,1,k) phi(:,1:end-1,k)];
        phi_after = [phi(:,2:end,k) phi(:,end,k)];
        phi(:,:,k) = angle(  W(:,k)*H(k,:) .* (C_barr./beta  + sigma0 * (  exp(1i*(phi_before+2*pi*f0(k)*r*L)) + exp(1i*(phi_after-2*pi*f0(k)*r*L)) )));

        %compute W
        W(:,k) =  (real(C_barr./beta .* exp(1i*phi(:,:,k))) *  H(k,:).')   ./  (  (1./beta) * abs(H(k,:)').^2 );
        
        %compute H
        H(k,:) =  (W(:,k).' * real(C_barr./beta .* exp(1i*phi(:,:,k))))   ./  ( (abs(W(:,k)').^2 ) * (1./ beta) + lambda*p* abs(H_barr).^(p-2));
        
        %normalize W
        W(:,k) = abs(W(:,k));
        H(k,:) = abs(H(k,:));
        
        sumW = sum(W(:,k));
        W(:,k) = W(:,k) /  sumW; 
        H(k,:) = H(k,:) *  sumW; 

        
    end
    
    for k=1:K
        C(:,:,k) = W(:,k)*H(k,:) .* exp(1i*phi(:,:,k));
    end
    
    X = sum(C,3);
    V = sum(abs(C),3);
    
end


end