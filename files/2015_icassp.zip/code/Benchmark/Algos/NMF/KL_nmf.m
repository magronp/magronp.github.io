%  Implementation of the KL-NMF algorithm under multiplicative update
%  rules, as defined in [Lee and Seung 1999]
%  Code by Paul Magron, october 2013.
% 
% Inputs :
%     V : positive matrix F*T
%     W_ini : initial feature matrix F*K
%     H_ini : initial activation matrix K*T
%     n_iter : number of iterations
%     mask : F*T binary mask (take into account the bin or not)
% 
% Outputs :
%     W : feature matrix
%     H : activation matrix
%     err : cost function
%     time : computation time

function [W,H,err,time] = KL_nmf(V,W_ini,H_ini,n_iter,mask)
tic;
[F,T] = size(V);

if nargin<5
mask = ones(F,T);
end

%% initialization

W=W_ini;
H=H_ini;
WH=W*H;

err = zeros(1,n_iter+1);  % creation of the error vector, containing the error before the first iteration
err(1) = div_KL(V,WH);

%% iteration

for k=1:n_iter
    W = W.*(((mask.*V)./(WH+eps))*H')./(mask*H'+eps);                  %update W
    WH=W*H;
    H = H.*(W'*((mask.*V)./(WH+eps)))./(W'*mask+eps);                  %update H
    WH=W*H;    
    err(k+1) =div_KL(V,WH);                                    %compute the error value
end

% normalize to avoid scaling problem
sumW = sum(W);

W = W * diag(1./sumW);
H = diag(sumW) * H;
time = toc;
end

%% KL divergence
function [err] = div_KL(A,B)
E=A.*log((A+eps)./(B+eps))-A+B;
err = sum(E(:));
end