% Implementation of the IS-NMF algorithm under multiplicative updatae rules
% as defined in [Fevotte, Durrieu and Bertin 2009]
% Code by Paul Magron, october 2013.
%
% Inputs :
%     V : positive matrix F*N
%     W_ini : initial feature matrix F*K
%     H_ini : initial activation matrix K*N
%     n_iter : number of iterations
% 
% Outputs :
%     W : feature matrix
%     H : activation matrix
%     err : cost function
%     time : computation time

function [W,H,err,time] = IS_nmf_MU(V,W_ini,H_ini,n_iter)
tic;
%% initialization

W=W_ini;
H=H_ini;
WH=W*H;

err = zeros(1,n_iter+1);   % creation of the error vector, containing the error before the first iteration
err(1) = div_IS(V,WH);

%% iteration

for k=1:n_iter
    W = W .* ((V.*(WH+eps).^-2)*H'+eps)./((WH+eps).^-1*H'+eps);              %update W
    WH = W*H;                                                                %update WH
    H = H .* (W'*(V.*(WH+eps).^-2+eps))./(W'*(WH+eps).^-1+eps);              %update H
    WH = W*H;                                                                %update WH
    err(k+1) =div_IS(V,WH);                                                  %error
end

% normalize to avoid scaling problem
sumW2 = sum(W);
W = W * diag(1./sumW2);
H = diag(sumW2) * H;
time = toc;
end

%IS divergence
function [err] = div_IS(A,B)
AdB=(A+eps)./(B+eps);
E=AdB-log(AdB)-1;
err = sum(E(:));
end