function [sigma2,a,w,h,c,L,time] = EM(x,delta,K,P,MaxItInit,MaxItEM,init)

if nargin < 7, init = 'IS'; end;

% Initialization method
[sigma2,a,w,h,e,sqrtS,c,L,P,time] = initialization(x,delta,K,P,MaxItInit,init);

% EM algorithm
tic;
for iteration = 1:MaxItEM,
    disp(sprintf('Iteration %d/%d',iteration,MaxItEM));
    [sigma2,a,w,h] = Mstep(e,sqrtS,P,h,a,w,true);
    [e,sqrtS,c,newL] = Estep(x,delta,sigma2,a,P,w,h);
    time(end+1) = toc;
    L(end+1) = newL;
end;
