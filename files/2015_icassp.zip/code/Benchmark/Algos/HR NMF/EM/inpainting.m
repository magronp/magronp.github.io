%% Run the inpainting experiment presented in section IV-C
disp('3) Inpainting');

%% Estimation of sigma2 and h from the partially observed TF data
K = 1;
index = rand(size(delta))<.5;
delta(index) = 0;
delta(:,round(3*T/6):round(6*T/6)) = 0;
% NMF
hNMF0 = rand(K,T);
[sigmaNMF0,~,hNMF0,LNMF0] = gISNMF(XC4.',delta.',0,wC4NMF,hNMF0,10,false);
aNMF0 = zeros(0,K,F);
[e,sqrtSNMF,cNMF0] = Estep(XC4.',delta.',sigmaNMF0,aNMF0,zeros(K,F),wC4NMF,hNMF0);
C4NMF = squeeze(cNMF0(1,:,:)).';
% HR-NMF
hHR0 = hNMF0;
sigmaHR0 = rand;
P = 2 * ones(K,F);
disp('Estimating the temporal activations of the HR-NMF model with missing data');
[e,sqrtSHR,cHR0,LHR0] = Estep(XC4.',delta.',sigmaHR0,aC4HR,P,wC4HR,hHR0);
MaxIt = 10;
for iteration = 1:MaxIt,
    disp(sprintf('Iteration %d/%d',iteration,MaxIt));
    [sigmaHR0,~,~,hHR0] = Mstep(e,sqrtSHR,P,hHR0,aC4HR,wC4HR,false);
    [e,sqrtSHR,cHR0,newL] = Estep(XC4.',delta.',sigmaHR0,aC4HR,P,wC4HR,hHR0);
    LHR0(end+1) = newL;
end;
C4HR = squeeze(cHR0(1,:,:)).';

%% Plot the spectrogram of the C4 piano tone restored with HR-NMF (Figure 4)
figure;
surf(t,f,20*log10(abs(C4HR)),'EdgeColor','none'); 
axis xy; axis tight; colormap(colors); view(0,90);
caxis([-60,40]);
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('Frequency (Hz)');
set(pointer,'FontSize',12);
pointer = title('Spectrogram recovered with HR-NMF');
set(pointer,'FontSize',12);

%% Synthesize the restored piano tones
% C4 tone restored with IS-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = C4NMF;
ResC4NMF = iSTFT(S0,M);
% C4 tone restored with HR-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = C4HR;
ResC4HR = iSTFT(S0,M);
wavwrite(ResC4NMF,Fs,'InpaintedC4-ISNMF.wav');
wavwrite(ResC4HR,Fs,'InpaintedC4-HRNMF.wav');


