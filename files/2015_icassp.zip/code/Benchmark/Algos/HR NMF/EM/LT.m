function L = LT(M)

[~,S,V] = svd(M'+eps,0);
L = V*S;