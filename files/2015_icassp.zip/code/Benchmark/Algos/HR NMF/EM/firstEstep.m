function [e,sqrtS,c,P,L] = firstEstep(x,delta,sigma2,w,h,P)

T = size(x,1);
F = size(x,2);
K = size(h,1);

c = zeros(K,T,F);
sqrtR = zeros(T,1);
e = 0;
sqrtS = zeros(1+max(P),1+max(P),K,T,F);
sigma2ft = w' * h + sigma2;
V = abs(x.').^2.*delta.';
L = - sum(sum(delta.'.*log(sigma2ft)+V./sigma2ft));

for f=1:F,
    for t=1:T,
        e = e + delta(t,f)*sigma2/sigma2ft(f,t) * (max(0,sigma2ft(f,t)-sigma2) + sigma2/sigma2ft(f,t)*abs(x(t,f))^2);
    end;
    for k=1:K,
        for t=1:T,
            v = w(k,f)*h(k,t);
            c(k,t,f) = delta(t,f)*v/sigma2ft(f,t) * x(t,f);
            sqrtR(t) = sqrt(v/sigma2ft(f,t))*sqrt(max(0,sigma2ft(f,t)-delta(t,f)*v));
            Pmax = min(P(k),t-1);
            sqrtS(:,:,k,t,f) = eye(max(P)+1);
            sqrtS(1:Pmax+1,1:Pmax+1,k,t,f) = LT(conj([diag(sqrtR(t:-1:t-Pmax)),c(k,t:-1:t-Pmax,f).']));
        end;
    end;
end;
e = e / sum(sum(delta));
P = P*ones(1,F);
