%% Numerical simulations presented in section IV
%disp('Numerical simulations');

% Initializations
clear all;
colors = gray;
colors = colors(end:-1:1,:);
close all;
% Read the sound files
[C4,Fs] = wavread('C4');
[C3,Fs] = wavread('C3');
C4 = decimate(C4,4);
C3 = decimate(C3,4);
Fs = Fs / 4;

%% Learning experiment presented in section IV-A
learning;

%% Source separation experiment presented in section IV-B
separation;

%% Inpainting experiment presented in section IV-C
inpainting;