function x = iSTFT2(S,M);
% Inverse Short Time Fourier Transform

Nfft = 2*(size(S,1)-1);
T = size(S,2);
N = M * (1 + (T-1) / 4);
x = zeros(N,1);
window = hann(M,'periodic');
for t = 1:T,
    time = 1 + (t-1) * M/4 : M + (t-1) * M / 4;
    s = 2*real(ifft(S(:,t),Nfft));
    x(time) = x(time) + window .* s(1:M);
end;
x = x(3*M/4+1:end-3*M/4)*2/3;
