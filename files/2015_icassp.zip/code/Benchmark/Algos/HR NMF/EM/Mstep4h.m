function h = Mstep4h(sqrtS,a,w)

F = length(w);
h = 0;
for f = find(w > 0),
    h = h + (norm(sqrtS(:,:,1,1,f)'*a(:,f)) / sqrt(F*w(f)))^2;
end;