%% Run the source separation experiment presented in section IV-B
disp('2) Source separation');

%% Compute the STFT of the mixture signal
T = length(C4)/2;
xC4 = C4;
xC3 = zeros(size(xC4));
xC3(T+1:end) = C3(1:T);
x = xC4+xC3;
[X,~,t] = STFT2(x,M,1024,Fs);
[XC4,~,t] = STFT2(xC4,M,1024,Fs);
[XC3,~,t] = STFT2(xC3,M,1024,Fs);
X = X(1:F,1:end-7);
XC4 = XC4(1:F,1:end-7);
XC3 = XC3(1:F,1:end-7);
t = t(1:end-7);
T = length(t);
% Plot the spectrogram of the mixture signal (Figure 1)
figure;
surf(t,f,20*log10(abs(X)),'EdgeColor','none');   
axis xy; axis tight; colormap(colors); view(0,90);
caxis([-60,40]);
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('Frequency (Hz)');
set(pointer,'FontSize',12);
pointer = title('Spectrogram of the original mixture signal');
set(pointer,'FontSize',12);
% Re-synthesize the mixture signal and its components
Xfull = zeros(full_F,T);
Xfull(1:F,:) = X;
x = iSTFT2(Xfull,M);
Xfull = zeros(full_F,T);
Xfull(1:F,:) = XC4;
xC4 = iSTFT2(Xfull,M);
Xfull = zeros(full_F,T);
Xfull(1:F,:) = XC3;
xC3 = iSTFT2(Xfull,M);
wavwrite(xC3,Fs,'OriginalC3.wav');
wavwrite(xC4,Fs,'OriginalC4.wav');
wavwrite(x,Fs,'OriginalMix.wav');

%% Estimate the activations (h,sigma2) in the mixture signal
% IS-NMF
K = 2;
wNMF = [wC4NMF;wC3NMF];
hNMF = rand(K,T);
aNMF = zeros(0,K,F);
delta = ones(F,T);
[sigmaNMF,wNMF,hNMF,LNMF] = gISNMF(X.',delta.',0,wNMF,hNMF,30,false);
[e,sqrtS,cNMF] = Estep(X.',delta.',sigmaNMF,aNMF,zeros(K,F),wNMF,hNMF);
% HR-NMF
wHR = [wC4HR;wC3HR];
aHR = zeros(P,K,F);
aHR(:,1,:) = aC4HR;
aHR(:,2,:) = aC3HR;
hHR = hNMF;
sigmaHR = rand;
P = 2 * ones(K,F);
delta = ones(F,T);
disp('Estimating the temporal activations of the mixture HR-NMF model');
[e,sqrtS,cHR,LHR] = Estep(X.',delta.',sigmaHR,aHR,P,wHR,hHR);
MaxIt = 60;
for iteration = 1:MaxIt,
    disp(sprintf('Iteration %d/%d',iteration,MaxIt));
    [sigmaHR,aHR,wHR,hHR] = Mstep(e,sqrtS,P,hHR,aHR,wHR,false);
    [e,sqrtS,cHR,newL] = Estep(X.',delta.',sigmaHR,aHR,P,wHR,hHR);
    LHR(end+1) = newL;
end;

%% Plot the separated components (Figure 3)
f0 = 50;
figure;
subplot(211);
plot(t,real(XC4(f0,:)),'r');
hold on;
plot(t,real(cNMF(1,:,f0)),'k-.');
plot(t,real(cHR(1,:,f0)),'--');
hold off;
rect = axis;
rect([1,2]) = [t(1),t(end)];
axis(rect);
axis tight;
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('2nd harmonic (540 Hz)');
set(pointer,'FontSize',12);
pointer = title('(a) First component (C4)');
set(pointer,'FontSize',12);
subplot(212);
plot(t,real(XC3(f0,:)),'r');
hold on;
plot(t,real(cNMF(2,:,f0)),'k-.');
plot(t,real(cHR(2,:,f0)),'--');
hold off;
rect = axis;
rect([1,2]) = [t(1),t(end)];
axis(rect);
axis tight;
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('4th harmonic (540 Hz)');
set(pointer,'FontSize',12);
pointer = title('(b) Second component (C3)');
set(pointer,'FontSize',12);

%% Synthesize the separated piano tones
% C4 tone separated with IS-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cNMF(1,:,:)).';
SepC4NMF = iSTFT(S0,M);
% C3 tone separated with IS-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cNMF(2,:,:)).';
SepC3NMF = iSTFT(S0,M);
% C4 tone separated with HR-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cHR(1,:,:)).';
SepC4HR = iSTFT(S0,M);
% C3 tone separated with HR-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cHR(2,:,:)).';
SepC3HR = iSTFT(S0,M);
wavwrite(SepC4NMF,Fs,'SeparatedC4-ISNMF.wav');
wavwrite(SepC3NMF,Fs,'SeparatedC3-ISNMF.wav');
wavwrite(SepC4HR,Fs,'SeparatedC4-HRNMF.wav');
wavwrite(SepC3HR,Fs,'SeparatedC3-HRNMF.wav');
