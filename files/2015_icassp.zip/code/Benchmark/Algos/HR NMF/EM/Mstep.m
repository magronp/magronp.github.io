function [sigma2,a,w,h] = Mstep(e,sqrtS,P,h,a,w,update_w)

% Initializations
K = size(sqrtS,3);
T = size(sqrtS,4);
F = size(sqrtS,5);
if update_w,
    a = zeros(size(sqrtS,1),K,F);
    w = zeros(K,F);
    MaxIt = 10;
else,
    a = [ones(1,K,F);-a];
    MaxIt = 1;
end;


% Estimation of sigma2
sigma2 = e;

% Independent maximization for each component
for k = 1:K,
    for iteration = 1:MaxIt, % Sequential loop
        if update_w,
            for f = 1:F, % Parallel loop for f
                [a(1:P(k,f)+1,k,f),w(k,f)] = Mstep4w(sqrtS(:,:,k,:,f),h(k,:),P(k,f));
            end;
        end;
        for t = 1:T, % Parallel loop for t
            h(k,t) = Mstep4h(sqrtS(:,:,k,t,:),a(:,k,:),w(k,:));
        end;
        if update_w,
            % Normalization of the NMF
            tmp = max(h(k,:));
            w(k,:) = w(k,:) * tmp;
            h(k,:) = h(k,:) / tmp;
        end;
    end; % iteration    
end;

a = - a(2:end,:,:);


