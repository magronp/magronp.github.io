function [a,w] = Mstep4w(sqrtS,h,P)

T = size(sqrtS,4);
sqrtSigma = zeros(P+1,T*(P+1));
for t = find(h > 0),
    sqrtSigma(:,1+(t-1)*(P+1):t*(P+1)) = sqrtS(1:P+1,1:P+1,1,t) / sqrt(T*h(t));
end;
sqrtSigma = LT(sqrtSigma);
a = [1,-sqrtSigma(1,:)*pinv(sqrtSigma(2:end,:))]';
w = norm(sqrtSigma'*a)^2;
