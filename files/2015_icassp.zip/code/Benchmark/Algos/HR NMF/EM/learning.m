%% Run the learning experiment presented in section IV-A
disp('1) Learning');

%% Compute the STFT of the two piano tones
T = length(C4)/2;
M = 4 * round(0.09*Fs / 4);
[C4STFT,f,t] = STFT2(C4(1:T),M,1024,Fs);
[C3STFT,f,t] = STFT2(C3(1:T),M,1024,Fs);
full_F = length(f);
F = 400;
f = f(1:F);
C4STFT = C4STFT(1:F,1:end-5);
C3STFT = C3STFT(1:F,1:end-5);
t = t(1:end-5);
T = length(t);

%% Learn the spectral parameters (w,a) of the two piano tones
K = 1;
P = 2*ones(K,1);
delta = ones(F,T);
% NMF
[sigmaC4NMF,wC4NMF,hC4NMF,LC4NMF,timeC4NMF] = gISNMF(C4STFT.',delta.',0,rand(K,F),rand(K,T),30);
[sigmaC3NMF,wC3NMF,hC3NMF,LC3NMF,timeC3NMF] = gISNMF(C3STFT.',delta.',0,rand(K,F),rand(K,T),30);
% HR-NMF
disp('Learning the spectral parameters of the C4 HR-NMF model');
[sigmaC4HR,aC4HR,wC4HR,hC4HR,cC4HR,LC4HR,timeC4HR] = EM(C4STFT.',delta.',K,P,30,10);
disp('Learning the spectral parameters of the C3 HR-NMF model');
[sigmaC3HR,aC3HR,wC3HR,hC3HR,cC3HR,LC3HR,timeC3HR] = EM(C3STFT.',delta.',K,P,30,10);
% Plot the log-likelihood L for the C4 HR-NMF model (Figure 2)
figure;
subplot(2,1,1);
plot(0:30,LC4NMF(1:31),'k-.');
hold on;
plot(0:30,LC4HR(1:31),'r');
plot(30:40,LC4HR(31:end),'b--');
axis([0,40,LC4HR(1),LC4HR(end)*2]);
plot([30,30],[LC4HR(1),LC4HR(end)*2],'k:')
hold off;
pointer = legend('IS-NMF Multiplicative updates','HR-NMF Multiplicative updates','HR-NMF EM algorithm');
set(pointer,'FontSize',12);
pointer = xlabel('Iteration number');
set(pointer,'FontSize',12);
pointer = ylabel('Log-likelihood');
set(pointer,'FontSize',12);
pointer = title('(a) Log-likelihood of C4 model');
set(pointer,'FontSize',12);
subplot(2,1,2);
semilogx(timeC4NMF(1:31),LC4NMF(1:31),'k-.');
hold on;
semilogx(timeC4HR(1:31),LC4HR(1:31),'r');
semilogx(timeC4HR(31:41),LC4HR(31:end),'b--');
axis([timeC4HR([1,41]),LC4HR(2),LC4HR(end)*1.1]);
plot(timeC4HR(31)*[1,1],[LC4HR(2),LC4HR(end)*1.1],'k:')
hold off;
pointer = xlabel('Elapsed time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('Log-likelihood');
set(pointer,'FontSize',12);
pointer = title('(b) Log-likelihood of C4 model');
set(pointer,'FontSize',12);
