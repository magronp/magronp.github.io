function [sigma2,a,w,h,e,sqrtS,c,L,P,time] = initialization(x,delta,K,P,MaxIt,init)

if nargin < 6, init = 'IS'; end;

T = size(x,1);
F = size(x,2);

% Initialization
sigma2 = rand;
w = rand(K,F);
h = rand(K,T);

switch init
    case 'IS'
        [sigma2,w,h,~,time] = gISNMF(x,delta,sigma2,w,h,MaxIt,true);
    case 'KL'
        tic;
        [W,h,~] = KL_nmf(abs(x.'),w',h,MaxIt); w=W';
        time = toc;
    case 'rand'
        time = 0;
    otherwise
        fprintf('invalid initialization type');
end

a = zeros(max(P),K,F);

% First E-step
[e,sqrtS,c,P,L] = firstEstep(x,delta,sigma2,w,h,P);

end