%% Numerical simulations presented in section VI.B
disp('Running the source separation experiment');

% Initializations
clear all;
colors = jet;
close all;
% Read the sound files
[A4,Fs] = wavread('MAPS_ISOL_NO_M_S1_M69_ENSTDkCl');
[Ab4,Fs] = wavread('MAPS_ISOL_NO_M_S1_M68_ENSTDkCl');
Fs = Fs / 4;
A4 = decimate(A4(:),4);
A4 = A4(7935:7935+2*Fs-1);
A4 = A4 / max(abs(A4));
Ab4 = decimate(Ab4(:),4);
Ab4 = Ab4(7992:7992+2*Fs-1);
Ab4 = Ab4 / max(abs(Ab4));

%% Compute the STFT of the two piano tones
T = length(A4);
MSTFT = 4 * round(0.09*Fs / 4);
[A4STFT,f,t] = STFT(A4(1:T),MSTFT,1024,Fs);
[Ab4STFT,f,t] = STFT(Ab4(1:T),MSTFT,1024,Fs);
full_F = length(f);
F = 400;
f = f(1:F);
A4STFT = A4STFT(1:F,4:end-5);
Ab4STFT = Ab4STFT(1:F,4:end-5);
t = t(4:end-5);
T = length(t);

%% Learn the spectral parameters (a,b) of the two piano tones
S = 1;
delta = ones(F,T);
% NMF
disp('Learning the spectral parameters of the A4 NMF model');
[sigmaA4NMF,wA4NMF,hA4NMF,LA4NMF,timeA4NMF] = gISNMF(A4STFT.',delta.',0,ones(S,F),ones(S,T),30);
disp('Learning the spectral parameters of the Ab4 NMF model');
[sigmaAb4NMF,wAb4NMF,hAb4NMF,LAb4NMF,timeAb4NMF] = gISNMF(Ab4STFT.',delta.',0,ones(S,F),ones(S,T),30);
% HR-NMF
S = 1;
M = 1;
Qa = 1;
Qb = 0;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 0;
mz = zeros(F,Qz,S);
qz = 1e5*ones(F,Qz,S);
a = zeros(F,2*Pa+1,Qa,S);
b = ones(F,2*Pb+1,Qb+1,M,S);
sigma2x = ones(T,S);
sigma2w = 1;
delta = ones(F,T,M);
MaxIt = 100;
evalVFE = false;
disp('Learning the spectral parameters of the A4 HR-NMF model');
[cA4HR,aA4HR,bA4HR,hA4HR,sigmaA4HR] = VBEM(A4STFT,delta,mz,qz,a,b,sigma2x,sigma2w,0,MaxIt,true,evalVFE);
disp('Learning the spectral parameters of the Ab4 HR-NMF model');
[cAb4HR,aAb4HR,bAb4HR,hAb4HR,sigmaAb4HR] = VBEM(Ab4STFT,delta,mz,qz,a,b,sigma2x,sigma2w,0,MaxIt,true,evalVFE);

%% Compute the STFT of the mixture signal
xA4 = A4;
xAb4 = Ab4;
x = xA4+xAb4;
[X,~,t] = STFT(x,MSTFT,1024,Fs);
% Plot the spectrogram of the mixture signal
figure;
surf(t(2:end-5),f,20*log10(abs(X(1:F,2:end-5))),'EdgeColor','none');   
axis xy; axis tight; colormap(colors); view(0,90);
caxis([-60,40]);
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('Frequency (Hz)');
set(pointer,'FontSize',12);
pointer = title('(a) Spectrogram of the original mixture signal');
set(pointer,'FontSize',12);
saveas(gcf,'Spectrogram','eps2c');
[XA4,~,t] = STFT(xA4,MSTFT,1024,Fs);
[XAb4,~,t] = STFT(xAb4,MSTFT,1024,Fs);
X = X(1:F,4:end-5);
XA4 = XA4(1:F,4:end-5);
XAb4 = XAb4(1:F,4:end-5);
t = t(4:end-5);
T = length(t);
% Re-synthesize the mixture signal and its components
Xfull = zeros(full_F,T);
Xfull(1:F,:) = X;
x = iSTFT(Xfull,MSTFT);
Xfull = zeros(full_F,T);
Xfull(1:F,:) = XA4;
xA4 = iSTFT(Xfull,MSTFT);
Xfull = zeros(full_F,T);
Xfull(1:F,:) = XAb4;
xAb4 = iSTFT(Xfull,MSTFT);
wavwrite(xAb4/max(abs(xAb4(:)))*0.9,Fs,'OriginalAb4.wav');
wavwrite(xA4/max(abs(xA4(:)))*0.9,Fs,'OriginalA4.wav');
wavwrite(x/max(abs(x(:)))*0.9,Fs,'OriginalMix.wav');

%% Estimate the activations (h,sigma2) in the mixture signal
% IS-NMF
S = 2;
wNMF = [wA4NMF;wAb4NMF];
hNMF = ones(S,T);
aNMF = zeros(0,S,F);
delta = ones(F,T);
disp('Separating the sources with the NMF model');
[sigmaNMF,wNMF,hNMF,LNMF] = gISNMF(X.',delta.',0,wNMF,hNMF,30,false);
[e,sqrtS,cNMF] = Estep(X.',delta.',sigmaNMF,aNMF,zeros(S,F),wNMF,hNMF);
% HR-NMF
S = 2;
M = 1;
Qa = 1;
Qb = 0;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 0;
mz = zeros(F,Qz,S);
qz = 1e5*ones(F,Qz,S);
a = zeros(F,2*Pa+1,Qa,S);
a(:,:,:,1) = aA4HR;
a(:,:,:,2) = aAb4HR;
b = zeros(F,2*Pb+1,Qb+1,M,S);
b(:,:,:,:,1) = bA4HR;
b(:,:,:,:,2) = bAb4HR;
sigma2x = hNMF.';
sigma2w = 1e-2;
delta = ones(F,T,M);
MaxIt = 100;
evalVFE = true;
disp('Separating the sources with the HR-NMF model');
[cHR,aHR,bHR,hHR,sigmaHR] = VBEM(X,delta,mz,qz,a,b,sigma2x,sigma2w,MaxIt,MaxIt,false,evalVFE);

%% Plot the separated components
f0 = 41;
figure;
subplot(211);
plot(t,real(XA4(f0,:)),'r');
hold on;
plot(t,real(cNMF(1,:,f0)),'k--');
plot(t,real(cHR(f0,:,1,1)),'b.','MarkerSize',10);
hold off;
rect = axis;
rect([1,2]) = [t(1),t(end)];
axis(rect);
axis tight;
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('First partial (440 Hz)');
set(pointer,'FontSize',12);
pointer = title('(a) First source (A4)');
set(pointer,'FontSize',12);
subplot(212);
plot(t,real(XAb4(f0,:)),'r');
hold on;
plot(t,real(cNMF(2,:,f0)),'k--');
plot(t,real(cHR(f0,:,1,2)),'b.','MarkerSize',10);
hold off;
rect = axis;
rect([1,2]) = [t(1),t(end)];
axis(rect);
axis tight;
pointer = xlabel('Time (s)');
set(pointer,'FontSize',12);
pointer = ylabel('First partial (415.30 Hz)');
set(pointer,'FontSize',12);
pointer = title('(b) Second source (Ab4)');
set(pointer,'FontSize',12);
saveas(gcf,'Separation','eps2c');

%% Synthesize the separated piano tones
% A4 tone separated with IS-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cNMF(1,:,:)).';
SepA4NMF = iSTFT(S0,MSTFT);
% Ab4 tone separated with IS-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cNMF(2,:,:)).';
SepAb4NMF = iSTFT(S0,MSTFT);
% A4 tone separated with HR-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cHR(:,:,1,1));
SepA4HR = iSTFT(S0,MSTFT);
% Ab4 tone separated with HR-NMF
S0 = zeros(full_F,T);
S0(1:F,:) = squeeze(cHR(:,:,1,2));
SepAb4HR = iSTFT(S0,MSTFT);
wavwrite(SepA4NMF/max(abs(SepA4NMF(:)))*0.9,Fs,'SeparatedA4-ISNMF.wav');
wavwrite(SepAb4NMF/max(abs(SepAb4NMF(:)))*0.9,Fs,'SeparatedAb4-ISNMF.wav');
wavwrite(SepA4HR/max(abs(SepA4HR(:)))*0.9,Fs,'SeparatedA4-HRNMF.wav');
wavwrite(SepAb4HR/max(abs(SepAb4HR(:)))*0.9,Fs,'SeparatedAb4-HRNMF.wav');

%% Compute the SDR
SDRA4NMF = 20*log10(norm(xA4)/norm(xA4-SepA4NMF));
SDRAb4NMF = 20*log10(norm(xAb4)/norm(xAb4-SepAb4NMF));
SDRA4HR = 20*log10(norm(xA4)/norm(xA4-SepA4HR));
SDRAb4HR = 20*log10(norm(xAb4)/norm(xAb4-SepAb4HR));
