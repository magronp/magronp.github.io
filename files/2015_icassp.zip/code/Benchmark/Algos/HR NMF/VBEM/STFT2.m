function [S,f,t] = STFT(x,M,Nfft,Fs);
% Short Time Fourier Transform

shift = round(M/4);
M = 4*shift;
N = length(x);
N = M*(6/4+ceil(length(x)/M));
x = [zeros(3*shift,1); x(:);zeros(N-3*shift-length(x),1)];
window = hann(M,'periodic');
T = 1 + 4 * (N/M -1);
S = zeros(Nfft/2+1,T);
for t = 1:T,
    X = fft(x(1 + (t-1) * shift : M + (t-1) * shift) .* window,Nfft);
    X = X(1:Nfft/2+1);
    X([1,end]) = X([1,end]) / 2;
    S(:,t) = X;
end;
f = (0:Nfft/2)'/Nfft * Fs;
t = (0:T-1)*shift / Fs;