%% Numerical simulations presented in section VI.A
disp('Running the audio inpainting experiment');

clear all;
close all;
[C3,Fs] = wavread('C3');
C3 = decimate(C3,4);
Fs = Fs / 4;

% Synthesis of the stereo signal
rm = [20 19 21];
src = [5 2 1];
mic = [19 18 1.6];
h1=rir(Fs, mic, 12, 0.3, rm, src);
mic = [15 11 10];
h2=rir(Fs, mic, 12, 0.3, rm, src);
h1 = h1(521:2520);
h2 = h2(521:2520);
y(:,1) = filter(h1,1,C3);
y(:,2) = filter(h2,1,C3);
y = y / max(abs(y(:)));
M = 2;
wavwrite(y,Fs,'OriginalC3');

% Initialization
F = 201;
L = 8;
K = 2;
N = L*F;
[proto,h,g] = cosmod(N,F);
close all;

% Analysis
Y = zeros(F,ceil((size(y,1)+size(h,2)-1)/F),M);
for m = 0:M-1,
    for f = 1:F,
        z = conv(h(f,:),y(:,1+m));
        Y(f,:,1+m) = z(1:F:end);
    end;
end;
T = size(Y,2);

% Display of the time-frequency representation
figure;
for m = 0:M-1,
    subplot(M,1,1+m);
    t = (0:size(Y,2)-1) * F / Fs;
    f = (0:F-1) /(2*F) * Fs;
    imagesc(t,f,20*log10(abs(Y(:,:,1+m))+1e-5));   
    axis xy;
    caxis([-60,40]);
    hold on;
    fmax = (F-1) /(2*F) * Fs;
    t1 = (round(T/3)) * F / Fs;
    t2 = round(2*T/3-1) * F / Fs;
    plot([t1 t1],[0 fmax],'Color','r','LineWidth',3);
    plot([t2 t2],[0 fmax],'Color','r','LineWidth',3);
    plot([t1 t2],[0 0],'Color','r','LineWidth',3);
    plot([t1 t2],[fmax fmax],'Color','r','LineWidth',3);
    hold off;
    pointer = xlabel('Time (s)');
    set(pointer,'FontSize',12);
    pointer = ylabel('Frequency (Hz)');
    set(pointer,'FontSize',12);
    if m ==0,
        pointer = title('Left channel (m=0)');
    else,
        pointer = title('Right channel (m=1)');
    end;
    set(pointer,'FontSize',12);
end;
saveas(gcf,'Original','eps2c');

% NMF estimation
Qa = 0;
Qb = 0;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 0;
mz = zeros(F,Qz);
qz = 1e5*ones(F,Qz);
a = .1*randn(F,2*Pa+1,Qa);
b = .1*randn(F,2*Pb+1,Qb+1,M);
sigma2x = ones(T,1);
sigma2y = 1;
delta = ones(F,T,M);
delta(:,round(T/3)+1:round(2*T/3),:) = 0;
MaxIt = 100;
evalVFE = false;

YMSNMF = VBEM(Y,delta,mz,qz,a,b,sigma2x,sigma2y,0,MaxIt,true,evalVFE);

% HRNMF estimation
Qa = 2;
Qb = 3;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 1;
mz = zeros(F,Qz);
qz = 1e5*ones(F,Qz);
a = .1*randn(F,2*Pa+1,Qa);
b = .1*randn(F,2*Pb+1,Qb+1,M);

YMSHRNMF = VBEM(Y,delta,mz,qz,a,b,sigma2x,sigma2y,0,MaxIt,true,evalVFE);

% Synthesis of yms with NMF
writefiles = true;
ymsNMF = zeros(size(YMSNMF,2)*F,M);
for m = 0:M-1,
    tmp = zeros(F,size(YMSNMF,2)*F);
    tmp(:,1:F:end) = YMSNMF(:,:,1+m);
    for f=1:F,
        tmp(f,:) = filter(g(f,:),1,tmp(f,:));
    end;
    ymsNMF(:,1+m) = real(sum(tmp));
end;
if writefiles,
    name = sprintf('InpaintedC3-NMF');
    wavwrite(ymsNMF/max(abs(ymsNMF(:))),Fs,name);
end;
% Display of the time-frequency representation
figure;
for m = 0:M-1,
    subplot(M,1,1+m);
    t = (0:size(Y,2)-1) * F / Fs;
    f = (0:F-1) /(2*F) * Fs;
    imagesc(t,f,20*log10(abs(YMSNMF(:,:,1+m))+1e-5));   
    axis xy;
    caxis([-60,40]);
    hold on;
    fmax = (F-1) /(2*F) * Fs;
    t1 = (round(T/3)) * F / Fs;
    t2 = round(2*T/3-1) * F / Fs;
    plot([t1 t1],[0 fmax],'Color','r','LineWidth',3);
    plot([t2 t2],[0 fmax],'Color','r','LineWidth',3);
    plot([t1 t2],[0 0],'Color','r','LineWidth',3);
    plot([t1 t2],[fmax fmax],'Color','r','LineWidth',3);
    hold off;
    pointer = xlabel('Time (s)');
    set(pointer,'FontSize',12);
    pointer = ylabel('Frequency (Hz)');
    set(pointer,'FontSize',12);
    if m ==0,
        pointer = title('Left channel (m=0)');
    else,
        pointer = title('Right channel (m=1)');
    end;
    set(pointer,'FontSize',12);
end;
saveas(gcf,'NMF','eps2c');

% Synthesis of yms with HRNMF
ymsHRNMF = zeros(size(YMSHRNMF,2)*F,M);
for m = 0:M-1,
    tmp = zeros(F,size(YMSHRNMF,2)*F);
    tmp(:,1:F:end) = YMSHRNMF(:,:,1+m);
    for f=1:F,
        tmp(f,:) = filter(g(f,:),1,tmp(f,:));
    end;
    ymsHRNMF(:,1+m) = real(sum(tmp));
end;
if writefiles,
    name = sprintf('InpaintedC3-HRNMF');
    wavwrite(ymsHRNMF/max(abs(ymsHRNMF(:))),Fs,name);
end;
% Display of the time-frequency representation
figure;
for m = 0:M-1,
    subplot(M,1,1+m);
    t = (0:size(Y,2)-1) * F / Fs;
    f = (0:F-1) /(2*F) * Fs;
    imagesc(t,f,20*log10(abs(YMSHRNMF(:,:,1+m))+1e-5));   
    axis xy;
    caxis([-60,40]);
    hold on;
    fmax = (F-1) /(2*F) * Fs;
    t1 = (round(T/3)) * F / Fs;
    t2 = round(2*T/3-1) * F / Fs;
    plot([t1 t1],[0 fmax],'Color','r','LineWidth',3);
    plot([t2 t2],[0 fmax],'Color','r','LineWidth',3);
    plot([t1 t2],[0 0],'Color','r','LineWidth',3);
    plot([t1 t2],[fmax fmax],'Color','r','LineWidth',3);
    hold off;
    pointer = xlabel('Time (s)');
    set(pointer,'FontSize',12);
    pointer = ylabel('Frequency (Hz)');
    set(pointer,'FontSize',12);
    if m ==0,
        pointer = title('Left channel (m=0)');
    else,
        pointer = title('Right channel (m=1)');
    end;
    set(pointer,'FontSize',12);
end;
saveas(gcf,'HRNMF','eps2c');

