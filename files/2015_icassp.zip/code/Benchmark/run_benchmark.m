clear all; close all; clc;
delete MIDI/*.wav PIANO_RAND/*.wav SYNTH_NO_OL/*.wav SYNTH_OL/*.wav VIBRATO/*.wav

Fs = 11025;                                           % Sample Rate
Nw = 512;                                             % window length
rec_se = 1;                                           % 1 : record estimated sources 
n_NMF = 30;                                           % #iterations (NMF)
n_phi = 50;                                           % #iterations (phase reconstruction)
n_HR = 30;                                            % #iterations (HRNMF)
Nit = 30;

% Algorithms
algos = [ {'NMF-Wiener'} ; {'NMF-GL'}; {'NMF-LR'} ; {'CNMF'} ; {'CNMF-LR'} ; {'HRNMF'}];
Nal = length(algos);

% Source type
%Sources = {'SYNTH_NO_OL','SYNTH_OL','VIBRATO','PIANO_RAND','MIDI'};
Sources = {'SYNTH_NO_OL','SYNTH_OL'};
Nsc = length(Sources);

% TF representation
TF = {'STFT75'};
Ntf = length(TF);

% Initialize energy ratios
SDRb = zeros(Nal,Ntf,Nsc,Nit); SIRb = zeros(Nal,Ntf,Nsc,Nit); SARb = zeros(Nal,Ntf,Nsc,Nit);
SDRo = zeros(Nal,Ntf,Nsc,Nit); SIRo = zeros(Nal,Ntf,Nsc,Nit); SARo = zeros(Nal,Ntf,Nsc,Nit);
time = zeros(Nal,Ntf,Nsc,Nit);

for sc = 1:Nsc
    
    source_type = Sources{sc};
 
        
    for it=1:Nit

        gen_sources_time_benchmark;
            
        for tf = 1:Ntf

            % TF representation and overlap selection
           switch TF{tf}
               case 'STFT0'
                   TF_type = 'STFT'; OL = 0;
               case 'STFT50'
                   TF_type = 'STFT'; OL = 0.5;
               case 'STFT75'
                   TF_type = 'STFT'; OL = 0.75;    
               case 'MDCT'
                   TF_type = 'MDCT'; OL = 0.5;
               case 'MDFT'
                   TF_type = 'MDFT'; OL = 0.5;
               case 'CQT'
                   TF_type = 'CQT'; OL = 0.5;
           end

           hop = Nw*(1-OL);
           
           gen_sources_TF_benchmark;
            
            % Source separation (blind & oracle)
            fprintf(Sources{sc});  
            fprintf(strcat('\n', TF{tf},' \n \n Iteration %.1d / %.1d \n'),it,Nit);

            fprintf(' ------ Oracle Separation ----- \n');
            so = zeros(Nal,K,t);
            ASS_oracle;

            fprintf(' ------ Blind Separation ------ \n');
            sb = zeros(Nal,K,t);
            ASS_blind;

            fprintf(' ---------- Synthesis --------- \n');
            synthesis_TF_to_T;
if strcmp(TF{tf},'STFT75')
            if and(rec_se,Nit==1)
            fprintf(' ---------- Recording --------- \n');
                record;
            end
end

            fprintf(' ---------- BSS Score --------- \n');
            compute_score;

            clc;
        end
    end
end

SDRb_av = mean(SDRb,4); SIRb_av = mean(SIRb,4); SARb_av = mean(SARb,4);
SDRo_av = mean(SDRo,4); SIRo_av = mean(SIRo,4); SARo_av = mean(SARo,4);
time_av = mean(time,4);

%disp_score_stat;
disp_score_mean;

