co_CNMF = zeros(F,T,K);
co_CNMF_LR = zeros(F,T,K);
co_HRNMF = zeros(F,T,K);

%% Regular NMF
fprintf('Regular NMF\n');
wNMF = zeros(size(W_ini_double));
hNMF = zeros(K,T);

% NMF
parfor k=1:K
    [wNMF(:,k),hNMF(k,:),err] = KL_nmf(abs(Sm_double(:,:,k))+eps,W_ini_double(:,k),H_ini(k,:),n_NMF);
end

Xnorm = Xdouble(1:2:end,:);
wNMFnorm = wNMF(1:2:end,:);

% Wiener filtering
[co_NMF] = wiener(Xnorm,wNMFnorm,hNMF);

%% Complex NMF
if strcmp(TF_type,'STFT')
fprintf('Complex NMF\n');

phase_ini = zeros(F,T,K);

for k=1:K
    phase_ini(:,:,k) = angle(X);
    [~,~,~,co_CNMF(:,:,k)] = complex_nmf(Sm(:,:,k),rand(F,1),rand(1,T),phase_ini,n_NMF);
end

%% Consistent Complex NMF
fprintf('Consistent Complex NMF\n');
phase_ini = zeros(F,T,K);

for k=1:K
    phase_ini(:,:,k) = angle(X);
    [~,~,~,co_CNMF_LR(:,:,k)] = complex_nmf_consistency(Sm(:,:,k),rand(F,1),rand(1,T),phase_ini,n_NMF,w,hop,1);
end

end
%% HRNMF Oracle
fprintf('HRNMF\n');

wNMF = zeros(F,K);
hNMF = zeros(K,T);

% NMF
parfor k=1:K
    [wNMF(:,k),hNMF(k,:),err] = KL_nmf(abs(Sm(:,:,k))+eps,W_ini(:,k),H_ini(k,:),n_NMF);
end

M = 1;
% Qa and Qb depends on the TF type
Qz = max(Qa,Qb);
Pa = 1;
Pb = 0;
mz = zeros(F,Qz,K);
qz = 1e5*ones(F,Qz,K);
a = zeros(F,2*Pa+1,Qa,K);
b = ones(F,2*Pb+1,Qb+1,M,K);
b(:,1,1,1,:) = wNMF;
sigma2x = hNMF';
sigma2w = 1;
delta = ones(F,T,M);

for k=1:K
    [c,~,~,~,~,~,~,~] = VBEM(Sm(:,:,k)+eps,delta,mz(:,:,k),qz(:,:,k),a(:,:,:,k),b(:,:,:,:,k),sigma2x(:,k),sigma2w,n_HR,n_HR,true,false);
    co_HRNMF(:,:,k) = squeeze(c(:,:,1,:));
end
