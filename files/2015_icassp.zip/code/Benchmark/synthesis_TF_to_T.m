
switch TF_type
    case 'STFT'
        
        time_Wiener = time_NMF; time_GL = time_NMF; time_LR = time_NMF;
        
        for k=1:K
    
            % Direct inverse from Wiener filtered components
            tic;
            sb(1,k,:) = iSTFT(cb_NMF(:,:,k),Nfft,w,hop); time_Wiener = time_Wiener+toc;
            so(1,k,:) = iSTFT(co_NMF(:,:,k),Nfft,w,hop);

            % Griffin & Lim
            tic;
            sb(2,k,:) = griffin_lim(cb_NMF(:,:,k),w,hop,P_cons,n_phi); time_GL = time_GL+toc;
            so(2,k,:) = griffin_lim(co_NMF(:,:,k),w,hop,P_cons,n_phi);

            % Le Roux
            tic;
            sb(3,k,:) = leroux(cb_NMF(:,:,k),w,hop,P_cons,n_phi); time_LR = time_LR+toc;
            so(3,k,:) = leroux(co_NMF(:,:,k),w,hop,P_cons,n_phi);

            % Complex NMF
            tic;
            sb(4,k,:) = iSTFT(cb_CNMF(:,:,k),Nfft,w,hop); time_CNMF = time_CNMF + toc;
            so(4,k,:) = iSTFT(co_CNMF(:,:,k),Nfft,w,hop);

            % Consistent Complex NMF
            tic;
            sb(5,k,:) = iSTFT(cb_CNMF_LR(:,:,k),Nfft,w,hop); time_CNMF_LR = time_CNMF_LR + toc;
            so(5,k,:) = iSTFT(co_CNMF_LR(:,:,k),Nfft,w,hop);

            % HRNMF
            tic;
            sb(6,k,:) = iSTFT(cb_HRNMF(:,:,k),Nfft,w,hop); time_HRNMF = time_HRNMF + toc;
            so(6,k,:) = iSTFT(co_HRNMF(:,:,k),Nfft,w,hop);

        end
    
        time(:,tf,sc,it) = [time_Wiener ; time_GL ; time_LR ; time_CNMF ; time_CNMF_LR ; time_HRNMF];
   
    case 'MDCT'
        
        time_Wiener = time_NMF;
        
        for k=1:K
    
            % Direct inverse from Wiener filtered components
            tic;
            sb(1,k,:) = iSTmdct(cb_NMF(:,:,k),w); time_Wiener = time_Wiener+toc;
            so(1,k,:) = iSTmdct(co_NMF(:,:,k),w);

            % HRNMF
            tic;
            sb(6,k,:) = iSTmdct(cb_HRNMF(:,:,k),w); time_HRNMF = time_HRNMF + toc;
            so(6,k,:) = iSTmdct(co_HRNMF(:,:,k),w);

        end  
        
        time(:,tf,sc,it) = [time_Wiener ; 0 ; 0 ; 0 ; 0 ; time_HRNMF];
        
     case 'MDFT'
        
        time_Wiener = time_NMF;
        
        for k=1:K
    
            % Direct inverse from Wiener filtered components
            tic;
            sb(1,k,:) = iMDFT(cb_NMF(:,:,k),w); time_Wiener = time_Wiener+toc;
            so(1,k,:) = iMDFT(co_NMF(:,:,k),w);

            % HRNMF
            tic;
            sb(6,k,:) = iMDFT(cb_HRNMF(:,:,k),w); time_HRNMF = time_HRNMF + toc;
            so(6,k,:) = iMDFT(co_HRNMF(:,:,k),w);
        end  
        
        time(:,tf,sc,it) = [time_Wiener ; 0 ; 0 ; 0 ; 0 ; time_HRNMF];
        
    case 'CQT'
        
        time_Wiener = time_NMF;
        
        for k=1:K
    
            % Direct inverse from Wiener filtered components
            tic;
            cb_NMF_cqt(k) = Xcqt; cb_NMF_cqt(k).c = cb_NMF(:,:,k);
            co_NMF_cqt(k) = Xcqt; co_NMF_cqt(k).c = co_NMF(:,:,k);
            sb(1,k,:) = icqt(cb_NMF_cqt(k)); time_Wiener = time_Wiener+toc;
            so(1,k,:) = icqt(co_NMF_cqt(k));

            % HRNMF
            tic;
            cb_HRNMF_cqt(k) = Xcqt; cb_HRNMF_cqt(k).c = cb_HRNMF(:,:,k);
            co_HRNMF_cqt(k) = Xcqt; co_HRNMF_cqt(k).c = co_HRNMF(:,:,k);
            sb(6,k,:) = icqt(cb_HRNMF_cqt(k)); time_HRNMF = time_HRNMF + toc;
            so(6,k,:) = icqt(co_HRNMF_cqt(k));
        end  
        
        time(:,tf,sc,it) = [time_Wiener ; 0 ; 0 ; 0 ; 0 ; time_HRNMF];
               
end
