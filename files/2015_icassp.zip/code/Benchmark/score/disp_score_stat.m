
% y-axis limits
ylb = [-3 50 ; -3 50 ; -10 45 ; -10 30 ; -3 40];
ylo = [85 115 ; 85 115 ; 55 80 ; 50 70 ; 50 70];

Ntf = 1;
Nsc = 1;

for sc=1:Nsc
    for tf = 1:Ntf
    
        figure;

        subplot(2,3,1);
        plot(11,squeeze(SDRo_av(end,tf,sc)),'^');
        set(gca,'ylim',ylo(sc,:),'xlim',[1 12],'Box','off','XTick', []); title('SDR');

        subplot(2,3,4);
        boxplot(squeeze(SDRb(:,tf,sc,:))',algos,'labelorientation','inline','symbol','r','color','b');
        set(gca,'ylim',ylb(sc,:)); set(gca,'Box','off'); set(gca, 'XTick', []);
        %ylabel('Energy (dB)');
        hold on;
        plot(squeeze(SDRo_av(1:end-1,tf,sc)),'^');

        subplot(2,3,2);
        plot(11,squeeze(SIRo_av(end,tf,sc)),'^');
        set(gca,'ylim',ylo(sc,:),'xlim',[1 12]); axis off; title('SIR');

        subplot(2,3,5);
        boxplot(squeeze(SIRb(:,tf,sc,:))',algos,'labelorientation','inline','symbol','r','color','b');
        set(gca,'ylim',ylb(sc,:)); axis off;
        hold on;
        plot(mean(SIRo(:,1:end-1)),'^');

        subplot(2,3,3);
        plot(11,squeeze(SARo_av(end,tf,sc)),'^');
        set(gca,'ylim',ylo(sc,:),'xlim',[1 12]); axis off; title('SAR');

        subplot(2,3,6);
        boxplot(squeeze(SARb(:,tf,sc,:))',algos,'labelorientation','inline','symbol','r','color','b');
        set(gca,'ylim',ylb(sc,:)); axis off;
        hold on;
        plot(mean(SARo(:,1:end-1)),'^'); 

    end
end
