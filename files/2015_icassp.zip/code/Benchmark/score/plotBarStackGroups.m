function [H] = plotBarStackGroups(stackData, groupLabels)
%% Plot a set of stacked bars, but group them according to labels provided.
%%
%% Params: 
%%      stackData is a 3D matrix (i.e., stackData(i, j, k) => (Group, Stack, StackElement)) 
%%      groupLabels is a CELL type (i.e., { 'a', 1 , 20, 'because' };)
%%
%% Copyright 2011 Evan Bollig (bollig at scs DOT fsu ANOTHERDOT edu
%%
%% 
NumGroupsPerAxis = size(stackData, 1);
NumStacksPerGroup = size(stackData, 2);


% Count off the number of bins
groupBins = 1:NumGroupsPerAxis;
MaxGroupWidth = 0.65; % Fraction of 1. If 1, then we have all bars in groups touching
groupOffset = MaxGroupWidth/NumStacksPerGroup;
figure
    hold on; 
for i=1:NumStacksPerGroup

    Y = squeeze(stackData(:,i,:));
    
    % Center the bars:
    internalPosCount = i - ((NumStacksPerGroup+1) / 2);
    
    % Offset the group draw positions:
    groupDrawPos = (internalPosCount)* groupOffset + groupBins;
    
    h(i,:) = bar(groupDrawPos, Y, 'stacked');
    set(h(i,:),'BarWidth',groupOffset);
end

set(h(1,1),'facecolor','b');
set(h(1,2),'facecolor',[0 0 0.7]);

set(h(2,1),'facecolor','r');
set(h(2,2),'facecolor',[0.7 0 0]);

% set(h(3,1),'facecolor','g');
% set(h(3,2),'facecolor',[0 0.7 0]);
% 
% set(h(4,1),'facecolor','c');
% set(h(4,2),'facecolor',[0 0.7 0.7]);
% 
% set(h(5,1),'facecolor','m');
% set(h(5,2),'facecolor',[0.7 0 0.7]);
% 
% set(h(6,1),'facecolor','y');
% set(h(6,2),'facecolor',[0.7 0.7 0.0]);


hold off;
H = gca;
set(H,'XTickMode','manual');
set(H,'XTick',1:NumGroupsPerAxis);
set(H,'XTickLabelMode','manual');
set(H,'XTickLabel',groupLabels);

end 