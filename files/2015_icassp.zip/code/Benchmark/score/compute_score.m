
for al=1:Nal
   [sr,si,sa] = bss_eval_sources(squeeze(sb(al,:,:)),sm);
   SDRb(al,tf,sc,it) = mean(sr); SIRb(al,tf,sc,it) = mean(si); SARb(al,tf,sc,it) = mean(sa);

   [sr,si,sa] = bss_eval_sources(squeeze(so(al,:,:)),sm);
   SDRo(al,tf,sc,it) = mean(sr); SIRo(al,tf,sc,it) = mean(si); SARo(al,tf,sc,it) = mean(sa);
end