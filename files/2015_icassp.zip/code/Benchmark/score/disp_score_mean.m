% Display average results of the benchmark (blind+oracle)

close all;

if (Nsc==1)
    figure;
    bar([SDRb_av SDRo_av],'stacked');
    set(gca,'XTickLabel',algos);
    xticklabel_rotate([],45,[],'Fontsize',14);
    p= ylabel('SDR (dB)'); set(p,'FontSize',16);
    p=legend('blind','oracle'); set(p,'FontSize',16);
else
    %stack data
    data = zeros(Nal,Nsc,2);
    data(:,:,1)=SDRb_av;
    data(:,:,2)=SDRo_av;
    %barplot
    plotBarStackGroups(data,algos);
    xticklabel_rotate([],45,[],'Fontsize',14);
    p= ylabel('SDR (dB)'); set(p,'FontSize',16);
    p=legend('NO overlap - blind','NO overlap - oracle','WITH overlap - blind','WITH overlap - oracle'); set(p,'FontSize',14);
    
end