function [C] = sort_sources(S,C)

K = size(S,3);
C_aux = C;

for j=1:(K-1)
    D = zeros(1,K);
    for k=j:K
        D(k) = distcorr(abs(S(:,:,j)),abs(C(:,:,k)));
    end
    [~,ind] = max(D); 
    C_aux(:,:,j) = C(:,:,ind);
    C_aux(:,:,ind) = C(:,:,j);
    C = C_aux;
end

end