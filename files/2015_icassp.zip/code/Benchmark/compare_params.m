% Evaluate the influence of the number of parameters between NMF and HRNMF

clear all; close all; clc;

K=2;
Fs = 11025;
nNMF = 30;
nHR = 30;

% Generate data from original sources
type_selection = 'PIANO_RAND';
gen_sources_time_benchmark;

% STFT
Nfft1 = 512;
Nfft2 = 1024;

Nw = 512;                                               % Window length
hop = Nw/4;                                             % Temporal shift

w = perfect_reco_window(Nw,hop);

X1 = STFT(x,Nfft1,w,hop);
X2 = STFT(x,Nfft2,w,hop);

X1 = X1(:,1:end-3);
X2 = X2(:,1:end-3);

[F1,T] = size(X1);
[F2,~] = size(X2);

% Initialization
N = 30;
SDR1 = 0; SIR1 = 0; SAR1 = 0;
SDR2 = 0; SIR2 = 0; SAR2 = 0;
SDR3 = 0; SIR3 = 0; SAR3 = 0;

for j=1:N
    
fprintf('Step  %.1d/%.1d \n',j,N);

% NMF and synthesis
[W1,H1,err1] = KL_nmf(abs(X1),rand(F1,K),rand(K,T),nNMF);
[W2,H2,err2] = KL_nmf(abs(X2),rand(F2,K),rand(K,T),nNMF);
% plot(0:nNMF,20*log10([err1 ; err2]')); ylabel('error (dB)'); xlabel('#iterations');
% legend('Nfft = 512','Nfft = 1024');

se1 = wiener(X1,W1,H1,Nfft1,w,hop);

W2_norm = W2(1:2:end,:);
X2_norm = X2(1:2:end,:);
se2 = wiener(X2_norm,W2_norm,H2,Nfft1,w,hop);

% HRNMF
M = 1;
Qa = 1;
Qb = 0;
Qz = max(Qa,Qb);
Pa = 0;
Pb = 0;
mz = zeros(F1,Qz,K);
qz = 1e5*ones(F1,Qz,K);
a = zeros(F1,2*Pa+1,Qa,K);
b = ones(F1,2*Pb+1,Qb+1,M,K);
b(:,1,1,1,:) = W1;
sigma2x = H1';
sigma2w = 1;
delta = ones(F1,T,M);

[cHR,~,~,~,~,~,~,~] = VBEM(X1,delta,mz,qz,a,b,sigma2x,sigma2w,nHR,nHR,true,false);

for k=1:K
    c_HRNMF(:,:,k) = squeeze(cHR(:,:,1,k));
end

% Sort components
c_HRNMF = sort_sources(S,c_HRNMF);

% Synthesize time signals
parfor k=1:K
    sb_HRNMF(k,:)  = iSTFT(c_HRNMF(:,:,k),Nfft1,w,hop);
end

% BSS score
[SDR,SIR,SAR] = bss_eval_sources(se1,sm);
SDR1 = SDR1 + mean(SDR)/N;
SIR1 = SIR1 + mean(SIR)/N;
SAR1 = SAR1 + mean(SAR)/N;

[SDR,SIR,SAR] = bss_eval_sources(se2,sm);
SDR2 = SDR2 + mean(SDR)/N;
SIR2 = SIR2 + mean(SIR)/N;
SAR2 = SAR2 + mean(SAR)/N;

[SDR,SIR,SAR] = bss_eval_sources(sb_HRNMF,sm);
SDR3 = SDR3 + mean(SDR)/N;
SIR3 = SIR3 + mean(SIR)/N;
SAR3 = SAR3 + mean(SAR)/N;

end

clc;
fprintf('**********************************************************************\n');
fprintf('*********  NMF_Wiener source separation  :  SDR, SIR, SAR  ***********\n');
fprintf('**********************************************************************\n');
fprintf(strcat( ' Nfft = %.1d  - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB \n'),Nfft1,SDR1, SIR1, SAR1);
fprintf(strcat( ' Nfft = %.1d - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB \n'),Nfft2,SDR2, SIR2, SAR2);
fprintf(strcat( ' HRNMF        - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB \n'),SDR3, SIR3, SAR3);