% 
% ----    Time domain signal generator  -----
%       Paul Magron
% 
% 'SYNTH'           synthetic harmonics
% 'SYNTH_NO_OL'     synthetic mixture with no overlapp in the TF domain
% 'SYNTH_OL'        synthetic mixture with overlapp in the TF domain
% 'CHIRP'           linear chirp
% 'VIBRATO'         synthetic mixture with vibrato
%
% 'PIANO_ONE'       one single piano note
% 'PIANO_TWO'       two occurences of the same note
% 'PIANO_RAND'      random piano notes mixtures from MAPS database
% 'PIANO_H'         piano notes mixtures in harmonic relation
% 'PIANO_NO_OL'     piano notes mixtures from MAPS database without TF overlap
%
% 'MIDI'            MIDI song excerpt
% (monophonic recording and instantaneous mix)

sources_path = '../Sounds/';
clear s sm  x name;
switch source_type
    
    % ---------------- SYNTHETIC MIXTURES ---------------------
    case 'SYNTH'
        K = 1;
        n=0:1/Fs:1;
        f0 = [600 1200 2400 3700]';
        damp = 1*[1 3 2 0.1]';
        s = sum(exp(-damp*n).*sin(2*pi*f0*n)); s=s(:); s=s';

    case 'SYNTH_NO_OL',
        K = 2;
        L = round(Fs/2);
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        f2_Hz = f1_Hz+250; f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,3); damp2 = -rand(1,1)/10000*[1 1 1]; phi2 = randn(1,3);        
        
        s(1,:) = real(Synthesis(L,damp1,f1,a1,phi1,60))'; 
        s(2,:) = real(Synthesis(L,damp2,f2,a2,phi2,60))'; 
        
    case 'SYNTH_OL',
        K = 2; 
        L = round(Fs/2);
        f10 = 500+1000*rand(1,1);
        f1_Hz = [f10 2*f10 3*f10]; f1 = f1_Hz/Fs;
        a1 = 0.5+0.5*rand(1,3); damp1 = -rand(1,1)/10000*[1 1 1]; phi1 = randn(1,3);
        
        f2_Hz = [0.75*f1_Hz(2) f1_Hz(2) 1.3*f1_Hz(2)]; f2 = f2_Hz/Fs;
        a2 = 0.5+0.5*rand(1,3); damp2 = -rand(1,1)/10000*[1 1 1]; phi2 = randn(1,3);  
        
        s(1,:) = real(Synthesis(L,damp1,f1,a1,phi1,60))';
        s(2,:) = real(Synthesis(L,damp2,f2,a2,phi2,60))';
        
    case 'CHIRP',
        K = 1;
        n=0:1/Fs:1;
        fHz = 1500;
        s = sin(2*pi*(fHz+500*n).*n);
        
    case 'VIBRATO',
        K = 2;
        n=0:1/Fs:1;
        fHz = 1500+1000*rand(1,1);
        s(1,:) = exp(-0.8*n).*sin(2*pi*fHz*n);
        s(2,:) = sin(2*pi*(fHz+300)*n+50*sin(2*pi*5*n));
        
    case 'DIRAC'
        K = 1;
        s = [zeros(1,999) 3 zeros(1,1000) 2 zeros(1,1000) ];
        
        
    % ---------------- PIANO NOTES ---------------------  
    case 'PIANO_ONE',
        K = 1;
        [s,Fs_old] = audioread(strcat('Sounds/MAPS isolated/piano',int2str(60),'.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s ];
        
    case 'PIANO_TWO',
        K = 1;
        [s,Fs_old] = audioread(strcat('Sounds/MAPS isolated/piano',int2str(60),'.wav')); s=s';
        s = resample(s,Fs,Fs_old);
        s = [zeros(1,1000) s  3*zeros(1,1000) s ];
        
    case 'PIANO_RAND',
        K = 2;
        midi_index = [21:26 29 32:35 37:40 42 44 48 49 55 57:60 67 68 72 78 80:82 84 85 90 93 100:104];
        rand_index = zeros(1,2);
        while rand_index(1) == rand_index(2)
            rand_index = randi(40,1,2);
        end;
        [s1,Fs_old] = audioread(strcat('Sounds/MAPS isolated/piano',int2str(midi_index(rand_index(1))),'.wav')); s1=s1';
        s2 = audioread(strcat('Sounds/MAPS isolated/piano',int2str(midi_index(rand_index(2))),'.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(end/2));
        
   case 'PIANO_H',
        K = 2;
        [s1,Fs_old] = audioread(strcat('Sounds/MAPS isolated/piano',int2str(60),'.wav')); s1=s1';
        s2 = audioread(strcat('Sounds/MAPS isolated/piano',int2str(67),'.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(end/2));
        
    case 'PIANO_NO_OL',
        K = 2;
        [s1,Fs_old] = audioread(strcat('Sounds/MAPS isolated/piano',int2str(60),'.wav')); s1=s1';
        s2 = audioread(strcat('Sounds/MAPS isolated/piano',int2str(68),'.wav')); s2=s2';
        s(1,:) = resample(s1,Fs,Fs_old);
        s(2,:) = resample(s2,Fs,Fs_old);
        s = s(:,1:floor(end/2));
        
        
    
    % ------------------- MIDI ---------------------  
    case 'MIDI',
        K = 7;
        [s_aux,Fs_old] = audioread(strcat('Sounds/midi/midi',int2str(1),'.wav'));
        s_aux = resample(s_aux,Fs,Fs_old);
        s = zeros(K,length(s_aux));
        s(1,:) = s_aux;
        for k=2:K
            [s_aux,Fs_old] = audioread(strcat('Sounds/midi/midi',int2str(k),'.wav'));
            s(k,:) = resample(s_aux,Fs,Fs_old);
        end
        
end

if (K==1) || (strcmp(source_type,'MIDI'))
   sm = s;
else
    l = size(s,2);
%     sm(1,:) = [s(1,:) zeros(1,l) s(1,:) s(1,:) ];
%     sm(2,:) = [zeros(1,l) s(2,:) zeros(1,l) s(2,:) ];    
    sm(1,:) = [s(1,:) zeros(1,l) s(1,:) ];
    sm(2,:) = [zeros(1,l) s(2,:) s(2,:) ];    
end

x = sum(sm,1);
