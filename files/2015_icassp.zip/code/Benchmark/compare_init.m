clear all; close all; clc;

Fs = 11025;
Nw = 512; Nfft = 512; hop = Nw/4;

source_type = 'PIANO_RAND'; TF_type = 'STFT';
gen_sources_time_benchmark;
gen_sources_TF_benchmark;

n_init = 1;
nHR = 1;
nVB = 1;
delta = ones(F,T);
P = 1 * ones(K,1);

cEM_Rand = zeros(Nfft/2+1,T,K);
cEM_IS = zeros(Nfft/2+1,T,K);
cEM_KL = zeros(Nfft/2+1,T,K);
cVB_Rand = zeros(Nfft/2+1,T,K);
cVB_IS = zeros(Nfft/2+1,T,K);
cVB_KL = zeros(Nfft/2+1,T,K);

Nit = 1;
score = zeros(6,3,Nit); % 5 algos, 3 scores, Nit initializations for each

for it=1:Nit
    fprintf('Iteration %d / %d \n',it,Nit)
    % EM algorithm with random initialization
    
    fprintf('EM algorithm with random initialization \n');
    tic;
    
    init = 'rand';
    [~,~,~,~,c,LRand,~] = EM(X.'+eps,delta',K,P,n_init,nHR,init);
    
    for k=1:K
        cEM_Rand(1:F,:,k) = squeeze(c(k,:,:)).';
    end
    
    % Sort components
    cEM_Rand(1:F,:,:) = sort_sources(S,cEM_Rand(1:F,:,:));
    
    % Synthesize time signals
    parfor k=1:K
        sEM_Rand(k,:)  = iSTFT(cEM_Rand(:,:,k),Nfft,w,hop);
    end
    tEM_Rand = toc;
    
    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sEM_Rand,sm);
    score(1,1,it) = mean(SDR);
    score(1,2,it) = mean(SIR);
    score(1,3,it) = mean(SAR);
    
    % EM algorithm with IS NMF initialization
    
    fprintf('EM algorithm with IS NMF initialization \n');
    
    tic;
    init = 'IS';
    [~,~,~,~,c,LIS,~] = EM(X.'+eps,delta',K,P,n_init,nHR,init);
    
    for k=1:K
        cEM_IS(1:F,:,k) = squeeze(c(k,:,:)).';
    end
    
    % Sort components
    cEM_IS(1:F,:,:) = sort_sources(S,cEM_IS(1:F,:,:));
    
    % Synthesize time signals
    parfor k=1:K
        sEM_IS(k,:)  = iSTFT(cEM_IS(:,:,k),Nfft,w,hop);
    end
    tEM_IS = toc;
    
    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sEM_IS,sm);
    score(2,1,it) = mean(SDR);
    score(2,2,it) = mean(SIR);
    score(2,3,it) = mean(SAR);
    
    % EM algorithm with KL NMF initialization
    
    fprintf('EM algorithm with KL NMF initialization \n');
    tic;
    
    init = 'KL';
    [~,~,~,~,c,LKL,~] = EM(X.'+eps,delta',K,P,n_init,nHR,init);
    
    for k=1:K
        cEM_KL(1:F,:,k) = squeeze(c(k,:,:)).';
    end
    
    % Sort components
    cEM_KL(1:F,:,:) = sort_sources(S,cEM_KL(1:F,:,:));
    
    % Synthesize time signals
    parfor k=1:K
        sEM_KL(k,:)  = iSTFT(cEM_KL(:,:,k),Nfft,w,hop);
    end
    tEM_KL = toc;
    
    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sEM_KL,sm);
    score(3,1,it) = mean(SDR);
    score(3,2,it) = mean(SIR);
    score(3,3,it) = mean(SAR);

    % VBEM multi-channel algorithm with random initialization

    fprintf('VBEM algorithm with random initialization \n');
    tic;

    hNMF = rand(K,T);

    M = 1;
    Qa = 1;
    Qb = 0;
    Qz = max(Qa,Qb);
    Pa = 0;
    Pb = 0;
    mz = zeros(F,Qz,K);
    qz = 1e5*ones(F,Qz,K);
    a = zeros(F,2*Pa+1,Qa,K);
    b = ones(F,2*Pb+1,Qb+1,M,K);
    sigma2x = hNMF.';
    sigma2w = 1;
    delta = ones(F,T,M);
    evalVFE = false;

    [c,~,~,~,~,~,~,~] = VBEM(X,delta,mz,qz,a,b,sigma2x,sigma2w,nVB,nVB,true,evalVFE);


    for k=1:K
        cVB_Rand(1:F,:,k) = squeeze(c(:,:,1,k));
    end

    % Sort components
    cVB_Rand(1:F,:,:) = sort_sources(Sm,cVB_Rand(1:F,:,:));

    % Synthesize time signals
    parfor k=1:K
        sVB_Rand(k,:)  = iSTFT(cVB_Rand(:,:,k),Nfft,w,hop);
    end
    tVB_Rand = toc;

    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sVB_Rand,sm);
    score(4,1,it) = mean(SDR);
    score(4,2,it) = mean(SIR);
    score(4,3,it) = mean(SAR);

    % VBEM multi-channel algorithm with IS initialization

    fprintf('VBEM algorithm with IS initialization \n');
    tic;

    [wNMF,hNMF,~] = IS_nmf_MU(abs(X),rand(F,K),rand(K,T),n_init);

    M = 1;
    Qa = 1;
    Qb = 0;
    Qz = max(Qa,Qb);
    Pa = 0;
    Pb = 0;
    mz = zeros(F,Qz,K);
    qz = 1e5*ones(F,Qz,K);
    a = zeros(F,2*Pa+1,Qa,K);
    b = ones(F,2*Pb+1,Qb+1,M,K);
    b(:,1,1,1,:) = wNMF;
    sigma2x = hNMF.';
    sigma2w = 1;
    delta = ones(F,T,M);
    evalVFE = false;

    [c,~,~,~,~,~,~,~] = VBEM(X,delta,mz,qz,a,b,sigma2x,sigma2w,nVB,nVB,true,evalVFE);

    for k=1:K
        cVB_IS(1:F,:,k) = squeeze(c(:,:,1,k));
    end

    % Sort components
    cVB_IS(1:F,:,:) = sort_sources(Sm,cVB_IS(1:F,:,:));

    % Synthesize time signals
    parfor k=1:K
        sVB_IS(k,:)  = iSTFT(cVB_IS(:,:,k),Nfft,w,hop);
    end
    tVB_IS = toc;

    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sVB_IS,sm);
    score(5,1,it) = mean(SDR);
    score(5,2,it) = mean(SIR);
    score(5,3,it) = mean(SAR);

    % VBEM multi-channel algorithm with KL initialization

    fprintf('VBEM algorithm with KL initialization \n');
    tic;

    [wNMF,hNMF,~] = KL_nmf(abs(X),rand(F,K),rand(K,T),n_init);

    M = 1;
    Qa = 1;
    Qb = 0;
    Qz = max(Qa,Qb);
    Pa = 0;
    Pb = 0;
    mz = zeros(F,Qz,K);
    qz = 1e5*ones(F,Qz,K);
    a = zeros(F,2*Pa+1,Qa,K);
    b = ones(F,2*Pb+1,Qb+1,M,K);
    b(:,1,1,1,:) = wNMF;
    sigma2x = hNMF.';
    sigma2w = 1;
    delta = ones(F,T,M);
    evalVFE = false;

    [c,~,~,~,~,~,~,~] = VBEM(X,delta,mz,qz,a,b,sigma2x,sigma2w,nVB,nVB,true,evalVFE);

    for k=1:K
        cVB_KL(1:F,:,k) = squeeze(c(:,:,1,k));
    end

    % Sort components
    cVB_KL(1:F,:,:) = sort_sources(Sm,cVB_KL(1:F,:,:));

    % Synthesize time signals
    parfor k=1:K
        sVB_KL(k,:)  = iSTFT(cVB_KL(:,:,k),Nfft,w,hop);
    end
    tVB_KL = toc;

    % BSS score
    [SDR,SIR,SAR] = bss_eval_sources(sVB_KL,sm);
    score(6,1,it) = mean(SDR);
    score(6,2,it) = mean(SIR);
    score(6,3,it) = mean(SAR);

    clc;
end

% Average score
score_av = mean(score,3);

% Display BSS score

clc;
fprintf('**********************************************************************************************\n');
fprintf('******************  HRNMF source separation  :  SDR, SIR, SAR, Time (s)  *********************\n');
fprintf('**********************************************************************************************\n');
fprintf(strcat( ' EM Rd - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(1,1), score_av(1,2), score_av(1,3), tEM_Rand);
fprintf(strcat( ' EM IS - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(2,1), score_av(2,2), score_av(2,3), tEM_IS);
fprintf(strcat( ' EM KL - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(3,1), score_av(3,2), score_av(3,3), tEM_KL);
fprintf(strcat( ' VB Rd - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(4,1), score_av(4,2), score_av(4,3), tVB_Rand);
fprintf(strcat( ' VB IS - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(5,1), score_av(5,2), score_av(5,3), tVB_IS);
fprintf(strcat( ' VB KL - SDR = %.1f dB ; SIR = %.1f dB ; SAR = %.1f dB ; Time = %.d \n'),score_av(6,1), score_av(6,2), score_av(6,3), tVB_KL);
