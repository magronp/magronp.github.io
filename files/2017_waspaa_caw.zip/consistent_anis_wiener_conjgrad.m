function [SE,iter,score] = consistent_anis_wiener_conjgrad(m_post,kappa,mu,V2,delta,Nfft,w,hop,sm)

bss=1;
if nargin<9
    bss =0;
end

[F,T]=size(m_post);
wlen=2*(F-1);

%First, compute the covariance in the AG model
lambda = besseli(1,kappa) ./ besseli(0,kappa);
rho = (besseli(2,kappa).*besseli(0,kappa) - besseli(1,kappa).^2 )./ besseli(0,kappa).^2;
gamma = (1-lambda.^2).* V2;
c = rho.*V2 .*exp(2*1i*mu) ;

% Mixture and posterior covariance
gamma_X = sum(gamma,3);      
c_X = sum(c,3);
detGX = gamma_X.^2 - abs(c_X).^2+eps;
        
gamma_post = abs(gamma(:,:,1) - ( gamma_X .* (gamma(:,:,1).^2+abs(c(:,:,1)).^2) - 2 * gamma(:,:,1) .* real(c(:,:,1).*conj(c_X))  )  ./ detGX);
c_post = c(:,:,1) - (2*gamma(:,:,1).*gamma_X.*c(:,:,1) - gamma(:,:,1).^2 .* c_X - c(:,:,1).^2 .* conj(c_X)  )  ./ detGX;
detG = gamma_post.^2-abs(c_post).^2;


%%% Wiener filter initialization %%%
SE=m_post;

%%% Conjugate gradient %%%
wei=repmat([1; 2*ones(F-2,1); 1],[1 T]);
se=iSTFT(SE,Nfft,w,hop)';
FSE=SE-STFT(se,Nfft,w,hop);
r=-delta*FSE;

z =  detG ./ (1+2*delta*(wlen-hop)/wlen*gamma_post + (delta*(wlen-hop)/wlen)^2 * detG) .* ( (gamma_post./(detG+eps) + delta*(wlen-hop)/wlen ).* r + c_post./(detG+eps) .* conj(r) );
P=z;
rsold=real(sum(sum(wei.*conj(r).*z)));
iter=0;
converged=false;

SDR =[]; SIR = []; SAR = [];
if bss
    se2 = sum(sm,1)-se;
    [sd,si,sa] = GetSDR([se;se2],sm);
    SDR = [SDR  sd]; SIR = [SIR  si]; SAR = [SAR  sa];
end
    

while ~converged,
    iter=iter+1;
    p=iSTFT(P,Nfft,w,hop);
    
        
    FP=P-STFT(p,Nfft,w,hop);
    AP=( gamma_post .* P - c_post .* conj(P)  )./(detG+eps) +delta*FP;
    alpha=rsold/real(sum(sum(wei.*conj(P).*AP))+realmin);
    SE=SE+alpha*P;
    
    if bss
        se1 = iSTFT(SE,Nfft,w,hop)'; se2 = sum(sm,1)-se1;
        [sd,si,sa] = GetSDR([se1;se2],sm);
        SDR = [SDR  sd]; SIR = [SIR  si]; SAR = [SAR  sa];
    end
        
    
    converged=(sum(sum(alpha^2*real(P.*conj(P)))) < 1e-6*sum(sum(real(SE.*conj(SE)))));
    r=r-alpha*AP;
    z =  detG ./ (1+2*delta*(wlen-hop)/wlen*gamma_post + (delta*(wlen-hop)/wlen)^2 * detG) .* ( (gamma_post./(detG+eps) + delta*(wlen-hop)/wlen ).* r + c_post./(detG+eps) .* conj(r) );
    
    rsnew=real(sum(sum(wei.*conj(r).*z)));
    beta=rsnew/(rsold+realmin);
    P=z+beta*P;
    rsold=rsnew;
end

score = [];
if bss
   score = zeros(2,iter+1,3);
   score(:,:,1) = SDR; score(:,:,2) = SIR; score(:,:,3) = SAR;
end


end