function wnorm = window_norm(w,Nw,hop)
    
    Q = floor(Nw/hop);
    
    % Window normalization for perfect reconstruction
    aux = zeros(Q,Nw);
    aux(1,:) = w' ;
    for l=1:(Q-1)
        aux(l+1,:) = circshift(w,l*hop)';
    end
    wnorm = sum(aux.^2,1)';
    
end