% Onset frames detection from a spectrogram
%
% Inputs :
%     V : spectrogram (F*T matrix)
%     Fs : sample rate
%     w : analysis window
%     hop : hop size
%
% Output :
%     UN : K*T matrix =1 if onset and 0 else

function [UN] = detect_onset_frames(V,Fs,w,hop,source_type)

[F,T,K] = size(V);
UN = zeros(K,T);

if nargin<5
    % If source type unspecified, use Tempogram toolbox
    Nfft = 2*(F-1);
    parameter.win_len = Nfft;
    parameter.fs = Fs;
    parameter.stepsize = hop;
    parameter.StftWindow = w;

    for k=1:K
        [v0,~] = audio_to_noveltyCurve(V(:,:,k), parameter);
        [~,ind] = findpeaks(v0,'MINPEAKHEIGHT',max(v0)*0.1);
        t0 = ind'; t0 = t0(1:end);
        UN(k,t0)=1;
    end
    
else
    %If source type specified, set the values
    switch source_type
        case {'SYNTH_OL','SYNTH_NO_OL'}
            UN(1,[16 220]) = 1; UN(2,[119 220])=1;
        case {'PIANO_FIFTH','PIANO_OCTAVE'}
            UN(1,[5 177]) = 1; UN(2,[91 177])=1;
        case 'PIANO_GUITAR_2'
            UN(1,[5 177]) = 1; UN(2,[103 190])=1;
        case 'PIANO_H_THREE'
            UN(1,[5 177]) = 1; UN(2,[91 177])=1; UN(3,[5 91])=1;
    end
end


end