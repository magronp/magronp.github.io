function [w,wnorm] = perfect_reco_window(Nw,hop,type)

if nargin<3
    type = 'hann';
end

if hop == Nw
    w = ones(Nw,1);
else
    switch type
        case 'hann'
            w = hann(Nw,'periodic');
        case 'hamming'
            w = hamming(Nw,'periodic');
        case 'blackman'
            w = blackman(Nw,'periodic');
    end
    
    wnorm = window_norm(w,Nw,hop);
    w = w ./ sqrt(wnorm); 

end

end

function wnorm = window_norm(w,Nw,hop)
    
    Q = floor(Nw/hop);
    
    % Window normalization for perfect reconstruction
    aux = zeros(Q,Nw);
    aux(1,:) = w' ;
    for l=1:(Q-1)
        aux(l+1,:) = circshift(w,l*hop)';
    end
    wnorm = sum(aux.^2)';
    
end
